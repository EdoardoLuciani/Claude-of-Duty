# Issue #458 CPU submission follow-up

Base: 948070c40e2b17c84883b69fe33805326a68bb28 (merged dependency-only PR #460).
Three.js: 0978e2b62e53654ebe1a2c3032ebee0a4981c701, unchanged dev tip at final check.
See docs/investigations/cpu-submission-458.md on analysis/458-cpu-submission.

73 successful production profiles / 131400 measured frames. Includes diagnostics,
pilots, and validation-only runs, NOT 73 acceptance runs. Six CDP profiles with
matching source maps and steady-render hotspot reports. Six standalone API probes
add 10800 frames. Source hashes, build HTML hashes, timing modes, fixture gates,
and health/activity/workload counters remain in raw outputs/manifests.

Primary uninstrumented confirmation: natural-720-{base,combo}-{1,2,3}.json.
CPU-affinity series (separate policy): pin-{360,720,1080}-{base,combo}-{1,2,3}.json.
Candidate: hoist-scope+lazy-resources. Ordinary scheduler: no repeated p50 win.
Do not pool pin/natural policies, diagnostics, pilots or validation captures.
Pilot index-loop win failed replication: match-720-{base,index-loops}-{1,2,3}.
Counter diagnostics: counts-*.json; inventory.json adds draw-visit categories.
GPU pass sums: gpu-{base,hoist-scope-lazy-resources}.json; not full GPU-frame time.
Final sampled stacks: cpu-final-*.cpuprofile, matching -maps and hotspots-final-*.
CDP session metrics include setup/warmup/export; not steady-frame timings.

API toy: batch-probe-{mesh,batch}-{1,2,3}.json. Static all-visible offscreen target,
512 draws in each mode, 16 geometries, same material, float readbacks identical.
Default managed headless browser, dev module build, observed ~17 ms rAF pacing
DESPITE requested unpaced launch flags. CPU duration comparison only, NOT an FPS
or production-combat gain. The later note wording in the checked-in tool makes
this caveat explicit; its measured browser-scene/loop code is unchanged.

visual-{base,hoist-scope-lazy-resources} have completed manifests and 7 successful
validation logs each: native buffer isolation, new texture/storage disposal/swap
readbacks, startup low/high/ultra, 5 render suites, strict arm-material audit.
Hero RGB identical. Pristine source hashes rechecked after restore/clean install.
Final clean install, 130 tests, build/typecheck/lint/format and profile failure
cleanup checks passed. Rejected prototypes were not left in application sources.

summary.json and binding-prototype.patch are derived aids; raw reports are the
source of truth. The prototype patch is NOT approved for shipping. No upstream
issue/PR opened. Earlier issue-458 dependency/indirect/upload evidence remains
separately on analysis/issue-458. #413 rare stalls are not claimed fixed.
