# #458 refresh / shadow dependency follow-up

27 successful production profiling runs, 48,600 measured frames. Hardware/protocol
and interpretation are documented in docs/investigations/refresh-policy-458.md.
No runtime optimization is committed. All native/application trial sources and
production builds are restored between conditions. No GPU jobs ran concurrently.

- census-1: first actual-return census; earlier collector without shader exports.
- shadow-constant-census, shadow-unlit-ao-census: exact-default-literal negative controls.
- census-2: canonical baseline, enhanced provenance and WGSL specimens.
- shadow-color-census: app-only shadow RGB specialization, unchanged refresh policy.
- natural-{360,720,1080}-{base,shadow-color}-{1,2,3}: 18 uninstrumented acceptance runs.
  Per-resolution order base1/candidate1, candidate2/base2, base3/candidate3.
- base-validation, shadow-color-validation: separate profiling/capture/validation jobs.
- gpu-{base,shadow-color}: separate sparse timestamp pass-sum diagnostics.
- failed-shadow-color-types/: failed build, zero profiling frames, restored pristine.

summary.json and summarize.mjs aggregate raw reports; run the latter with cwd set
to the repository (it loads the pinned pngjs dev dependency there). throughput.json
is the earlier table export. summary.log is the full aggregate, not new measurements.
shaders/ and specimen fields in the canonical two censuses preserve binding layouts,
update types and WGSL; beauty/prepass representative sources are byte-identical.
shader-{base,candidate}.ts and shadow-color.patch preserve the exact app control.
Measured source/lock/build hashes are in each manifest. Later manifests additionally
hash the diagnostic tools; tools-snapshot/ preserves their final source. Earlier
census metadata was less detailed, so census-2 is the canonical baseline.

Both validation jobs passed native buffer/resource readbacks, startup low/high/ultra,
five render suites and strict arms audit. Hero RGB comparison: zero changed pixels.
Clean npm ci, 132 smoke tests, build/typecheck/lint/format and profile failure tests
passed. Final verification logs are included. Rare #413 stalls are not resolved.
Oracle files are source-analysis advice, not measurements or a general Three bug.
Generated WGSL includes Three code; THREE-LICENSE and PROJECT-LICENSE are included.
