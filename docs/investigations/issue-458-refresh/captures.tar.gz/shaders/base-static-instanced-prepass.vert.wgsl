// Three.js r187dev - Node System

// directives


// structs


// uniforms

struct nodeUniform0Struct {
	value : array< mat4x4<f32> >
};
@binding( 13 ) @group( 1 )
var<storage, read> nodeUniform0 : nodeUniform0Struct;

struct nodeUniform1Struct {
	value : array< mat4x4<f32> >
};
@binding( 14 ) @group( 1 )
var<storage, read> nodeUniform1 : nodeUniform1Struct;

struct renderStruct {
	nodeUniform25 : mat4x4<f32>,
	nodeUniform27 : mat4x4<f32>,
	nodeUniform28 : mat4x4<f32>,
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	cameraPosition : vec3<f32>
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

struct objectStruct {
	nodeUniform4 : mat3x3<f32>,
	nodeUniform5 : mat4x4<f32>,
	nodeUniform6 : f32,
	nodeUniform7 : f32,
	nodeUniform12 : f32,
	nodeUniform16 : vec4<f32>,
	nodeUniform17 : f32,
	nodeUniform18 : vec3<f32>,
	nodeUniform20 : f32,
	nodeUniform21 : f32,
	nodeUniform22 : f32,
	nodeUniform23 : vec3<f32>,
	nodeUniform24 : f32,
	nodeUniform26 : mat4x4<f32>,
	nodeUniform29 : mat4x4<f32>
};
@binding( 0 ) @group( 1 )
var<uniform> object : objectStruct;

// varyings

struct VaryingsStruct {
	@location( 0 ) positionLocal : vec3<f32>,
	@location( 1 ) positionPrevious : vec3<f32>,
	@location( 2 ) v_positionView : vec3<f32>,
	@location( 3 ) v_normalWorldGeometry : vec3<f32>,
	@location( 4 ) v_normalViewGeometry : vec3<f32>,
	@location( 5 ) v_positionWorld : vec3<f32>,
	@location( 6 ) vInstanceColor : vec3<f32>,
	@location( 7 ) nodeVarying9 : vec4<f32>,
	@builtin( position ) builtinClipSpace : vec4<f32>
};
var<private> varyings : VaryingsStruct;

// vars
var<private> normalLocal : vec3<f32>;
var<private> normalViewGeometry : vec3<f32>;
var<private> modelViewMatrix : mat4x4<f32>;
var<private> v_modelViewProjection : vec4<f32>;
var<private> VERTEX_v_modelViewProjection : vec4<f32>;

// codes

fn tsl_inverse_mat3( m : mat3x3<f32> ) -> mat3x3<f32> {

	let a00 = m[ 0 ][ 0 ]; let a01 = m[ 0 ][ 1 ]; let a02 = m[ 0 ][ 2 ];
	let a10 = m[ 1 ][ 0 ]; let a11 = m[ 1 ][ 1 ]; let a12 = m[ 1 ][ 2 ];
	let a20 = m[ 2 ][ 0 ]; let a21 = m[ 2 ][ 1 ]; let a22 = m[ 2 ][ 2 ];

	let b01 = a22 * a11 - a12 * a21;
	let b11 = - a22 * a10 + a12 * a20;
	let b21 = a21 * a10 - a11 * a20;

	let det = a00 * b01 + a01 * b11 + a02 * b21;

	return mat3x3<f32>(
		b01, ( - a22 * a01 + a02 * a21 ), ( a12 * a01 - a02 * a11 ),
		b11, ( a22 * a00 - a02 * a20 ), ( - a12 * a00 + a02 * a10 ),
		b21, ( - a21 * a00 + a01 * a20 ), ( a11 * a00 - a01 * a10 )
	) * ( 1.0 / det );

}



@vertex
fn main( @builtin( instance_index ) instanceIndex : u32,
	@location( 0 ) position : vec3<f32>,
	@location( 1 ) normal : vec3<f32>,
	@location( 2 ) color : vec3<f32>,
	@location( 3 ) nodeAttribute2 : vec3<f32> ) -> VaryingsStruct {

	// flow
	// code

	varyings.positionLocal = position;
	varyings.positionLocal = ( nodeUniform0.value[ instanceIndex ] * vec4<f32>( varyings.positionLocal, 1.0 ) ).xyz;
	varyings.positionPrevious = position;
	varyings.positionPrevious = ( nodeUniform1.value[ instanceIndex ] * vec4<f32>( varyings.positionPrevious, 1.0 ) ).xyz;
	normalLocal = normal;
	normalLocal = normalize( ( transpose( tsl_inverse_mat3( mat3x3<f32>( nodeUniform0.value[ instanceIndex ][ 0 ].xyz, nodeUniform0.value[ instanceIndex ][ 1 ].xyz, nodeUniform0.value[ instanceIndex ][ 2 ].xyz ) ) ) * normalLocal ) );
	varyings.vInstanceColor = nodeAttribute2;
	let nodeConst0 = normalize( ( render.cameraViewMatrix * vec4<f32>( ( object.nodeUniform4 * normalLocal ), 0.0 ) ).xyz );
	varyings.v_normalViewGeometry = nodeConst0;
	normalViewGeometry = normalize( varyings.v_normalViewGeometry );
	varyings.v_normalWorldGeometry = normalize( ( vec4<f32>( normalViewGeometry, 0.0 ) * render.cameraViewMatrix ).xyz );
	varyings.v_positionWorld = ( object.nodeUniform5 * vec4<f32>( varyings.positionLocal, 1.0 ) ).xyz;
	varyings.nodeVarying9 = vec4<f32>( color, 1.0 );
	modelViewMatrix = ( render.cameraViewMatrix * object.nodeUniform5 );
	varyings.v_positionView = ( modelViewMatrix * vec4<f32>( varyings.positionLocal, 1.0 ) ).xyz;
	let VERTEX_nodeConst41 = ( render.cameraProjectionMatrix * vec4<f32>( varyings.v_positionView, 1.0 ) );
	VERTEX_v_modelViewProjection = VERTEX_nodeConst41;

	// result

	varyings.builtinClipSpace = VERTEX_v_modelViewProjection;

	return varyings;

}
