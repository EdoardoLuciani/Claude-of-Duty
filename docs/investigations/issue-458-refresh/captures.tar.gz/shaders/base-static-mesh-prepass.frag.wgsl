// Three.js r187dev - Node System

// global
diagnostic( off, derivative_uniformity );


// directives


// structs

struct StructType0 {
	color : vec3<f32>,
	opacity : f32,
	normal : vec3<f32>,
	rough : f32,
	metal : f32,
	ao : f32
};

struct OutputType {
	@location( 0 ) m0 : vec4<f32>,
	@location( 1 ) m1 : vec4<f32>,
	@location( 2 ) m2 : vec4<f32>,
	
};
var<private> output : OutputType;

// uniforms
@binding( 1 ) @group( 1 ) var nodeUniform6_sampler : sampler;
@binding( 2 ) @group( 1 ) var nodeUniform6 : texture_2d<f32>;
@binding( 3 ) @group( 1 ) var nodeUniform7_sampler : sampler;
@binding( 4 ) @group( 1 ) var nodeUniform7 : texture_2d<f32>;
@binding( 5 ) @group( 1 ) var nodeUniform8_sampler : sampler;
@binding( 6 ) @group( 1 ) var nodeUniform8 : texture_2d<f32>;
@binding( 7 ) @group( 1 ) var nodeUniform10_sampler : sampler;
@binding( 8 ) @group( 1 ) var nodeUniform10 : texture_2d<f32>;
@binding( 9 ) @group( 1 ) var nodeUniform11_sampler : sampler;
@binding( 10 ) @group( 1 ) var nodeUniform11 : texture_2d<f32>;
@binding( 11 ) @group( 1 ) var nodeUniform12_sampler : sampler;
@binding( 12 ) @group( 1 ) var nodeUniform12 : texture_2d<f32>;

struct objectStruct {
	nodeUniform1 : mat3x3<f32>,
	nodeUniform2 : mat4x4<f32>,
	nodeUniform3 : f32,
	nodeUniform4 : f32,
	nodeUniform9 : f32,
	nodeUniform13 : vec4<f32>,
	nodeUniform14 : f32,
	nodeUniform15 : vec3<f32>,
	nodeUniform17 : f32,
	nodeUniform18 : f32,
	nodeUniform19 : f32,
	nodeUniform20 : vec3<f32>,
	nodeUniform21 : f32,
	nodeUniform23 : mat4x4<f32>,
	nodeUniform26 : mat4x4<f32>
};
@binding( 0 ) @group( 1 )
var<uniform> object : objectStruct;

struct renderStruct {
	nodeUniform22 : mat4x4<f32>,
	nodeUniform24 : mat4x4<f32>,
	nodeUniform25 : mat4x4<f32>,
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	cameraPosition : vec3<f32>
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

// vars
var<private> DiffuseColor : vec4<f32>;
var<private> nodeVar0 : vec3<f32>;
var<private> nodeVar1 : f32;
var<private> nodeVar2 : vec3<f32>;
var<private> normalWorldGeometry : vec3<f32>;
var<private> nodeVar3 : f32;
var<private> nodeVar4 : vec3<f32>;
var<private> nodeVar5 : vec3<f32>;
var<private> nodeVar6 : vec3<f32>;
var<private> nodeVar7 : vec2<f32>;
var<private> nodeVar8 : vec2<f32>;
var<private> nodeVar9 : vec2<f32>;
var<private> nodeVar10 : vec2<f32>;
var<private> nodeVar11 : vec2<f32>;
var<private> nodeVar12 : f32;
var<private> nodeVar13 : f32;
var<private> nodeVar14 : vec2<f32>;
var<private> nodeVar15 : f32;
var<private> nodeVar16 : vec4<f32>;
var<private> nodeVar17 : f32;
var<private> nodeVar18 : vec4<f32>;
var<private> nodeVar19 : vec4<f32>;
var<private> nodeVar20 : vec4<f32>;
var<private> nodeVar21 : vec4<f32>;
var<private> nodeVar22 : vec4<f32>;
var<private> nodeVar23 : vec3<f32>;
var<private> nodeVar24 : vec4<f32>;
var<private> nodeVar25 : vec3<f32>;
var<private> nodeVar26 : vec4<f32>;
var<private> nodeVar27 : f32;
var<private> nodeVar28 : vec4<f32>;
var<private> nodeVar29 : f32;
var<private> nodeVar30 : vec4<f32>;
var<private> nodeVar31 : vec4<f32>;
var<private> nodeVar32 : vec3<f32>;
var<private> nodeVar33 : vec4<f32>;
var<private> nodeVar34 : vec3<f32>;
var<private> nodeVar35 : f32;
var<private> nodeVar36 : vec4<f32>;
var<private> nodeVar37 : vec2<f32>;
var<private> nodeVar38 : vec4<f32>;
var<private> nodeVar39 : vec4<f32>;
var<private> nodeVar40 : vec3<f32>;
var<private> nodeVar41 : vec4<f32>;
var<private> nodeVar42 : vec4<f32>;
var<private> nodeVar43 : vec3<f32>;
var<private> nodeVar44 : vec3<f32>;
var<private> nodeVar45 : f32;
var<private> nodeVar46 : vec3<f32>;
var<private> nodeVar47 : f32;
var<private> nodeVar48 : f32;
var<private> nodeVar49 : f32;
var<private> nodeVar50 : f32;
var<private> nodeVar51 : vec3<f32>;
var<private> nodeVar52 : vec3<f32>;
var<private> nodeVar53 : vec3<f32>;
var<private> nodeVar54 : vec3<f32>;
var<private> nodeVar55 : vec3<f32>;
var<private> nodeVar56 : f32;
var<private> nodeVar57 : f32;
var<private> nodeVar58 : vec4<f32>;
var<private> nodeVar59 : vec4<f32>;
var<private> nodeVar60 : f32;
var<private> nodeVar61 : vec3<f32>;
var<private> nodeVar62 : vec3<f32>;
var<private> nodeVar63 : vec3<f32>;
var<private> nodeVar64 : vec3<f32>;
var<private> nodeVar65 : vec3<f32>;
var<private> nodeVar66 : vec3<f32>;
var<private> nodeVar67 : vec3<f32>;
var<private> nodeVar68 : StructType0;
var<private> AmbientOcclusion : f32;
var<private> Metalness : f32;
var<private> Roughness : f32;
var<private> normalViewGeometry : vec3<f32>;
var<private> SpecularColor : vec3<f32>;
var<private> SpecularColorBlended : vec3<f32>;
var<private> SpecularF90 : f32;
var<private> DiffuseContribution : vec3<f32>;
var<private> EmissiveColor : vec3<f32>;
var<private> Output : vec4<f32>;
var<private> normalView : vec3<f32>;
var<private> modelViewMatrix : mat4x4<f32>;

// codes


@fragment
fn main( @location( 0 ) v_positionView : vec3<f32>,
	@location( 1 ) positionLocal : vec3<f32>,
	@location( 2 ) v_normalWorldGeometry : vec3<f32>,
	@location( 3 ) v_normalViewGeometry : vec3<f32>,
	@location( 4 ) v_positionWorld : vec3<f32>,
	@location( 5 ) positionPrevious : vec3<f32>,
	@location( 6 ) nodeVarying8 : vec4<f32>,
	@builtin( front_facing ) isFront : bool ) -> OutputType {

	// flow
	// code


	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = ( - nodeConst1 );

	}

	let nodeConst2 = pow( abs( nodeVar2 ), vec3<f32>( 5.0, 5.0, 5.0 ) );
	let nodeConst3 = ( nodeConst2 / vec3<f32>( max( ( ( nodeConst2.x + nodeConst2.y ) + nodeConst2.z ), 0.0001 ) ) );

	if ( ( ( nodeConst3.x > nodeConst3.y ) && ( nodeConst3.x > nodeConst3.z ) ) ) {

		nodeVar1 = 0.0;

	} else {


		if ( ( nodeConst3.y > nodeConst3.z ) ) {

			nodeVar3 = 1.0;

		} else {

			nodeVar3 = 2.0;

		}

		nodeVar1 = nodeVar3;

	}


	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar0 = vec3<f32>( 0.0, 0.0, ( - nodeConst4 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar4 = vec3<f32>( 1.0, 0.0, 0.0 );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar4 = vec3<f32>( nodeConst5, 0.0, 0.0 );

		}

		nodeVar0 = nodeVar4;

	}

	nodeVar5 = normalize( ( nodeVar0 - ( nodeVar2 * vec3<f32>( dot( nodeVar0, nodeVar2 ) ) ) ) );
	nodeVar6 = cross( nodeVar2, nodeVar5 );

	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar7 = ( ( vec2<f32>( ( ( - v_positionWorld.z ) * nodeConst4 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform3 ) ) + vec2<f32>( 0.0, 0.0 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar8 = ( ( vec2<f32>( v_positionWorld.x, ( ( - v_positionWorld.z ) * ( ( step( 0.0, nodeVar2.y ) * 2.0 ) - 1.0 ) ) ) * vec2<f32>( object.nodeUniform3 ) ) + vec2<f32>( 0.0, 0.0 ) );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar8 = ( ( vec2<f32>( ( v_positionWorld.x * nodeConst5 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform3 ) ) + vec2<f32>( 0.0, 0.0 ) );

		}

		nodeVar7 = nodeVar8;

	}

	nodeVar9 = nodeVar7;
	nodeVar10 = dpdx( nodeVar7 );
	nodeVar11 = - dpdy( nodeVar7 );
	let nodeConst6 = ( object.nodeUniform4 * object.nodeUniform3 );
	let nodeConst7 = length( ( render.cameraPosition - v_positionWorld ) );
	let nodeConst8 = ( 1.0 - smoothstep( 6.0, 14.0, nodeConst7 ) );

	if ( ( ( nodeConst6 > 0.0 ) && ( nodeConst8 > 0.001 ) ) ) {

		let nodeConst9 = normalize( ( render.cameraPosition - v_positionWorld ) );
		let nodeConst10 = normalize( vec3<f32>( dot( nodeConst9, nodeVar5 ), dot( nodeConst9, nodeVar6 ), dot( nodeConst9, nodeVar2 ) ) );
		nodeVar12 = max( ( mix( 16.0, 8.0, clamp( abs( nodeConst10.z ), 0.0, 1.0 ) ) * nodeConst8 ), 4.0 );
		nodeVar13 = ( 1.0 / nodeVar12 );
		nodeVar14 = ( ( ( ( nodeConst10.xy / vec2<f32>( max( abs( nodeConst10.z ), 0.3 ) ) ) * vec2<f32>( nodeConst6 ) ) * vec2<f32>( nodeConst8 ) ) * vec2<f32>( nodeVar13 ) );
		nodeVar15 = 0.0;
		nodeVar16 = textureSampleGrad( nodeUniform6, nodeUniform6_sampler, nodeVar9, nodeVar10, nodeVar11 );
		nodeVar17 = ( 1.0 - nodeVar16.w );

		for ( var i : i32 = 0; i < 48; i ++ ) {


			if ( ( ( nodeVar15 >= nodeVar17 ) || ( f32( i ) >= nodeVar12 ) ) ) {

				break;
				

			}

			nodeVar9 = ( nodeVar9 - nodeVar14 );
			nodeVar18 = textureSampleGrad( nodeUniform6, nodeUniform6_sampler, nodeVar9, nodeVar10, nodeVar11 );
			nodeVar17 = ( 1.0 - nodeVar18.w );
			nodeVar15 = ( nodeVar15 + nodeVar13 );

		}

		let nodeConst11 = ( nodeVar9 + nodeVar14 );
		let nodeConst12 = ( nodeVar17 - nodeVar15 );
		nodeVar19 = textureSampleGrad( nodeUniform6, nodeUniform6_sampler, nodeConst11, nodeVar10, nodeVar11 );
		nodeVar9 = mix( nodeVar9, nodeConst11, clamp( ( ( - nodeConst12 ) / max( ( ( ( ( 1.0 - nodeVar19.w ) - nodeVar15 ) + nodeVar13 ) - nodeConst12 ), 0.0001 ) ), 0.0, 1.0 ) );
		

	}

	nodeVar20 = textureSample( nodeUniform6, nodeUniform6_sampler, nodeVar9 );
	nodeVar21 = nodeVar20;
	nodeVar22 = textureSample( nodeUniform7, nodeUniform7_sampler, nodeVar9 );
	nodeVar23 = nodeVar22.xyz;
	nodeVar24 = textureSample( nodeUniform8, nodeUniform8_sampler, nodeVar9 );
	nodeVar25 = normalize( vec3<f32>( ( ( ( nodeVar24.x * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( ( nodeVar24.y * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( nodeVar24.z * 2.0 ) - 1.0 ) ) );
	nodeVar26 = textureSample( nodeUniform10, nodeUniform10_sampler, ( ( ( v_positionWorld.xz + vec2<f32>( ( v_positionWorld.y * 0.7 ) ) ) * vec2<f32>( 0.42500000000000004 ) ) + vec2<f32>( 0.21 ) ) );
	let nodeConst13 = ( clamp( ( ( nodeVar26.y - 0.36 ) * 2.4 ), 0.0, 1.0 ) * 0.8 );
	nodeVar27 = ( ( 1.0 - nodeConst13 ) + ( nodeVar21.w * 0.6 ) );
	let nodeConst14 = ( ( vec2<f32>( ( ( nodeVar9.x * 0.803 ) - ( nodeVar9.y * 0.596 ) ), ( ( nodeVar9.x * 0.596 ) + ( nodeVar9.y * 0.803 ) ) ) * vec2<f32>( 0.617 ) ) + vec2<f32>( 0.37, 0.71 ) );
	nodeVar28 = textureSample( nodeUniform6, nodeUniform6_sampler, nodeConst14 );
	nodeVar29 = ( nodeConst13 + ( nodeVar28.w * 0.6 ) );
	let nodeConst15 = ( max( nodeVar27, nodeVar29 ) - 0.18 );
	nodeVar27 = max( ( nodeVar27 - nodeConst15 ), 0.0 );
	nodeVar29 = max( ( nodeVar29 - nodeConst15 ), 0.0 );
	let nodeConst16 = ( 1.0 / max( ( nodeVar27 + nodeVar29 ), 0.0001 ) );
	nodeVar21 = ( ( ( nodeVar21 * vec4<f32>( nodeVar27 ) ) + ( nodeVar28 * vec4<f32>( nodeVar29 ) ) ) * vec4<f32>( nodeConst16 ) );
	nodeVar30 = textureSample( nodeUniform7, nodeUniform7_sampler, nodeConst14 );
	nodeVar23 = ( ( ( nodeVar23 * vec3<f32>( nodeVar27 ) ) + ( nodeVar30.xyz * vec3<f32>( nodeVar29 ) ) ) * vec3<f32>( nodeConst16 ) );
	nodeVar31 = textureSample( nodeUniform8, nodeUniform8_sampler, nodeConst14 );
	nodeVar25 = normalize( ( ( nodeVar25 * vec3<f32>( nodeVar27 ) ) + ( normalize( vec3<f32>( ( ( ( nodeVar31.x * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( ( nodeVar31.y * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( nodeVar31.z * 2.0 ) - 1.0 ) ) ) * vec3<f32>( nodeVar29 ) ) ) );
	nodeVar32 = ( ( ( nodeVar5 * vec3<f32>( nodeVar25.x ) ) + ( nodeVar6 * vec3<f32>( nodeVar25.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeVar25.z ) ) );
	let nodeConst17 = ( nodeVar9 * vec2<f32>( 8.461538461538462 ) );
	nodeVar33 = textureSample( nodeUniform11, nodeUniform11_sampler, nodeConst17 );
	let nodeConst18 = ( ( nodeVar33.w - 0.5 ) * 2.0 );
	let nodeConst19 = ( 1.0 - smoothstep( 10.8, 24.0, nodeConst7 ) );
	nodeVar34 = ( nodeVar21.xyz * vec3<f32>( ( 1.0 + ( ( ( ( nodeConst18 * 0.95 ) + ( ( nodeVar33.x - 0.5 ) * 1.25 ) ) * 0.54 ) * nodeConst19 ) ) ) );
	nodeVar21.x = nodeVar34[ 0 ];
	nodeVar21.y = nodeVar34[ 1 ];
	nodeVar21.z = nodeVar34[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( max( ( - nodeConst18 ), 0.0 ) * 0.162 ) * nodeConst19 ) ) );
	nodeVar35 = clamp( ( nodeVar21.w + ( ( nodeConst18 * 0.16 ) * nodeConst19 ) ), 0.0, 1.0 );
	nodeVar36 = textureSample( nodeUniform12, nodeUniform12_sampler, nodeConst17 );
	let nodeConst20 = ( ( nodeVar36.xyz * vec3<f32>( 2.0 ) ) - vec3<f32>( 1.0 ) );
	let nodeConst21 = ( ( ( nodeVar5 * vec3<f32>( nodeConst20.x ) ) + ( nodeVar6 * vec3<f32>( nodeConst20.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeConst20.z ) ) );
	nodeVar32 = normalize( ( nodeVar32 + ( ( ( nodeConst21 - ( nodeVar2 * vec3<f32>( dot( nodeConst21, nodeVar2 ) ) ) ) * vec3<f32>( 0.95 ) ) * vec3<f32>( nodeConst19 ) ) ) );

	if ( ( step( 0.62, abs( nodeVar2.y ) ) > 0.5 ) ) {

		nodeVar37 = v_positionWorld.xz;

	} else {

		nodeVar37 = vec2<f32>( ( v_positionWorld.x + ( v_positionWorld.z * 0.63 ) ), v_positionWorld.y );

	}

	nodeVar38 = textureSample( nodeUniform10, nodeUniform10_sampler, ( nodeVar37 * vec2<f32>( 0.085 ) ) );
	nodeVar39 = textureSample( nodeUniform10, nodeUniform10_sampler, ( ( nodeVar37 * vec2<f32>( 0.017935 ) ) + vec2<f32>( 0.37 ) ) );
	nodeVar40 = ( nodeVar21.xyz * vec3<f32>( mix( 1.0, ( ( clamp( ( ( ( ( ( nodeVar38.x * 0.55 ) + ( nodeVar39.z * 0.45 ) ) - 0.5 ) * 2.15 ) + 0.5 ), 0.0, 1.0 ) * 0.92 ) + 0.55 ), 0.72 ) ) );
	nodeVar21.x = nodeVar40[ 0 ];
	nodeVar21.y = nodeVar40[ 1 ];
	nodeVar21.z = nodeVar40[ 2 ];
	let nodeConst22 = ( nodeVar37 * vec2<f32>( 0.026 ) );
	nodeVar41 = textureSample( nodeUniform10, nodeUniform10_sampler, nodeConst22 );
	nodeVar42 = textureSample( nodeUniform10, nodeUniform10_sampler, ( ( nodeConst22 * vec2<f32>( 0.37 ) ) + vec2<f32>( 0.61 ) ) );
	let nodeConst23 = clamp( ( ( ( ( nodeVar41.x * 0.62 ) + ( nodeVar42.z * 0.38 ) ) - 0.5 ) * 2.3 ), -1.0, 1.0 );
	nodeVar43 = ( nodeVar21.xyz * vec3<f32>( ( ( nodeConst23 * 0.15 ) + 1.0 ) ) );
	nodeVar21.x = nodeVar43[ 0 ];
	nodeVar21.y = nodeVar43[ 1 ];
	nodeVar21.z = nodeVar43[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y - ( nodeConst23 * 0.0825 ) ), 0.0, 1.0 );
	nodeVar44 = ( nodeVar21.xyz * mix( vec3<f32>( 1.0, 1.0, 1.0 ), vec3<f32>( 1.05, 1.0, 0.93 ), ( ( nodeVar39.x - 0.5 ) * 0.5 ) ) );
	nodeVar21.x = nodeVar44[ 0 ];
	nodeVar21.y = nodeVar44[ 1 ];
	nodeVar21.z = nodeVar44[ 2 ];
	nodeVar23.y = clamp( ( ( ( nodeVar23.y + ( ( nodeVar38.y - 0.5 ) * 0.26 ) ) + ( ( nodeVar38.w - 0.5 ) * 0.16 ) ) - ( ( nodeConst18 * 0.07 ) * nodeConst19 ) ), 0.0, 1.0 );

	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar46 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar46 = ( - nodeConst1 );

	}

	let nodeConst24 = ( ( v_positionWorld.z * nodeVar46.x ) - ( v_positionWorld.x * nodeVar46.z ) );
	let nodeConst25 = ( ( vec2<f32>( nodeConst24, v_positionWorld.y ) / vec2<f32>( 2.2 ) ) + ( ( nodeVar39.xy - vec2<f32>( 0.5 ) ) * vec2<f32>( 0.35 ) ) );
	let nodeConst26 = floor( nodeConst25 );
	nodeVar47 = fract( ( ( ( ( nodeConst26.x * 5.51 ) + ( nodeConst26.y * 17.29 ) ) + 53.9 ) * 0.1031 ) );
	nodeVar47 = ( nodeVar47 * ( nodeVar47 + 33.33 ) );
	nodeVar47 = ( nodeVar47 * ( nodeVar47 + nodeVar47 ) );
	let nodeConst27 = fract( nodeVar47 );
	let nodeConst28 = ( nodeConst27 > 0.48 );

	if ( nodeConst28 ) {

		nodeVar45 = 1.0;

	} else {

		nodeVar45 = -1.0;

	}

	nodeVar48 = fract( ( ( ( ( nodeConst26.x * 3.17 ) + ( nodeConst26.y * 9.41 ) ) + 21.3 ) * 0.1031 ) );
	nodeVar48 = ( nodeVar48 * ( nodeVar48 + 33.33 ) );
	nodeVar48 = ( nodeVar48 * ( nodeVar48 + nodeVar48 ) );
	let nodeConst29 = fract( nodeVar48 );
	nodeVar49 = fract( ( ( ( ( nodeConst26.x * 11.93 ) + ( nodeConst26.y * 4.73 ) ) + 37.7 ) * 0.1031 ) );
	nodeVar49 = ( nodeVar49 * ( nodeVar49 + 33.33 ) );
	nodeVar49 = ( nodeVar49 * ( nodeVar49 + nodeVar49 ) );
	let nodeConst30 = fract( nodeVar49 );
	let nodeConst31 = vec2<f32>( ( ( nodeConst29 * 0.3 ) + 0.05 ), ( ( nodeConst30 * 0.3 ) + 0.05 ) );
	let nodeConst32 = ( ( nodeConst29 * 0.03 ) + 0.028 );
	let nodeConst33 = ( nodeConst25 - nodeConst26 );
	let nodeConst34 = smoothstep( nodeConst31, ( nodeConst31 + vec2<f32>( nodeConst32 ) ), nodeConst33 );
	let nodeConst35 = vec2<f32>( ( ( - ( nodeConst30 * 0.26 ) ) + 0.95 ), ( ( - ( nodeConst27 * 0.26 ) ) + 0.95 ) );
	let nodeConst36 = ( vec2<f32>( 1.0 ) - smoothstep( ( nodeConst35 - vec2<f32>( nodeConst32 ) ), nodeConst35, nodeConst33 ) );
	nodeVar50 = fract( ( ( ( ( nodeConst26.x * 7.31 ) + ( nodeConst26.y * 13.77 ) ) + 5.1 ) * 0.1031 ) );
	nodeVar50 = ( nodeVar50 * ( nodeVar50 + 33.33 ) );
	nodeVar50 = ( nodeVar50 * ( nodeVar50 + nodeVar50 ) );
	let nodeConst37 = ( 1.0 - smoothstep( 0.34, 0.72, abs( nodeVar46.y ) ) );
	let nodeConst38 = ( ( ( ( ( nodeConst34.x * nodeConst34.y ) * nodeConst36.x ) * nodeConst36.y ) * step( 0.6599999999999999, fract( nodeVar50 ) ) ) * nodeConst37 );
	nodeVar51 = ( nodeVar21.xyz * vec3<f32>( ( 1.0 + ( ( nodeVar45 * 0.175 ) * nodeConst38 ) ) ) );
	nodeVar21.x = nodeVar51[ 0 ];
	nodeVar21.y = nodeVar51[ 1 ];
	nodeVar21.z = nodeVar51[ 2 ];

	if ( nodeConst28 ) {

		nodeVar52 = vec3<f32>( 0.975, 0.988, 1.02 );

	} else {

		nodeVar52 = vec3<f32>( 1.03, 1.008, 0.968 );

	}

	nodeVar53 = ( nodeVar21.xyz * mix( vec3<f32>( 1.0, 1.0, 1.0 ), nodeVar52, nodeConst38 ) );
	nodeVar21.x = nodeVar53[ 0 ];
	nodeVar21.y = nodeVar53[ 1 ];
	nodeVar21.z = nodeVar53[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst38 * -0.1 ) ), 0.0, 1.0 );
	let nodeConst39 = ( ( nodeConst38 * ( 1.0 - nodeConst38 ) ) * 4.0 );
	nodeVar54 = ( nodeVar21.xyz * vec3<f32>( ( ( nodeConst39 * 0.13 ) + 1.0 ) ) );
	nodeVar21.x = nodeVar54[ 0 ];
	nodeVar21.y = nodeVar54[ 1 ];
	nodeVar21.z = nodeVar54[ 2 ];
	nodeVar35 = clamp( ( ( nodeVar35 + ( nodeConst38 * 0.07 ) ) + ( nodeConst39 * 0.05 ) ), 0.0, 1.0 );
	let nodeConst40 = ( ( pow( clamp( nodeVar46.y, 0.0, 1.0 ), 2.0 ) * object.nodeUniform13.x ) * smoothstep( 0.3, 0.8, ( ( nodeVar38.z * 0.7 ) + ( nodeVar39.y * 0.5 ) ) ) );
	nodeVar55 = mix( nodeVar21.xyz, vec3<f32>( 0.33245153633549385, 0.2541520943200296, 0.1499597898006365 ), ( nodeConst40 * 0.75 ) );
	nodeVar21.x = nodeVar55[ 0 ];
	nodeVar21.y = nodeVar55[ 1 ];
	nodeVar21.z = nodeVar55[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst40 * 0.3 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst40 * 0.85 ) ) );
	let nodeConst41 = ( nodeConst24 * 1.55 );
	let nodeConst42 = floor( nodeConst41 );
	nodeVar56 = fract( ( ( ( nodeConst42 * 2.71 ) + 11.7 ) * 0.1031 ) );
	nodeVar56 = ( nodeVar56 * ( nodeVar56 + 33.33 ) );
	nodeVar56 = ( nodeVar56 * ( nodeVar56 + nodeVar56 ) );
	let nodeConst43 = fract( nodeVar56 );
	nodeVar57 = fract( ( ( ( nodeConst42 * 1.37 ) + 3.1 ) * 0.1031 ) );
	nodeVar57 = ( nodeVar57 * ( nodeVar57 + 33.33 ) );
	nodeVar57 = ( nodeVar57 * ( nodeVar57 + nodeVar57 ) );
	let nodeConst44 = fract( nodeVar57 );
	let nodeConst45 = ( ( nodeConst43 * 1.2 ) + ( nodeConst44 * 0.5 ) );
	nodeVar58 = textureSample( nodeUniform10, nodeUniform10_sampler, vec2<f32>( ( nodeConst24 * 0.46 ), ( v_positionWorld.y * 0.155 ) ) );
	let nodeConst46 = ( ( ( ( ( floor( ( ( v_positionWorld.y + nodeConst45 ) / 2.85 ) ) + 1.0 ) * 2.85 ) - nodeConst45 ) + ( ( nodeVar58.w - 0.5 ) * 0.2 ) ) - v_positionWorld.y );
	nodeVar59 = textureSample( nodeUniform10, nodeUniform10_sampler, vec2<f32>( ( ( nodeConst24 * 1.35 ) + 0.4 ), ( v_positionWorld.y * 0.42 ) ) );
	nodeVar60 = clamp( ( ( ( nodeConst37 * clamp( ( ( smoothstep( 0.0, 0.15, nodeConst46 ) * ( 1.0 - smoothstep( 0.15, 1.65, nodeConst46 ) ) ) * ( ( ( smoothstep( 0.3, 0.62, nodeConst44 ) * ( ( nodeConst43 * 0.45 ) + 0.55 ) ) * pow( sin( ( fract( nodeConst41 ) * 3.14159265 ) ), 2.0 ) ) * ( ( nodeConst44 * 0.45 ) + 0.8 ) ) ), 0.0, 1.0 ) ) * clamp( ( object.nodeUniform13.y * 2.2 ), 0.0, 1.15 ) ) * smoothstep( 0.3, 0.66, ( ( nodeVar58.w * 0.72 ) + ( nodeVar59.y * 0.38 ) ) ) ), 0.0, 1.0 );
	nodeVar60 = clamp( ( ( nodeVar60 * ( ( clamp( ( ( nodeVarying8.y * 1.5 ) + ( nodeVarying8.z * 0.6 ) ), 0.0, 1.0 ) * 0.75 ) + 0.45 ) ) + ( ( smoothstep( 0.58, 0.98, nodeVarying8.y ) * nodeConst37 ) * ( ( smoothstep( 0.2, 0.7, ( ( nodeVar58.w * 0.6 ) + ( nodeVar59.y * 0.55 ) ) ) * 0.45 ) + 0.55 ) ) ), 0.0, 1.0 );
	nodeVar60 = ( nodeVar60 * step( 0.0001, object.nodeUniform13.y ) );
	nodeVar61 = mix( nodeVar21.xyz, mix( mix( ( nodeVar21.xyz * vec3<f32>( 0.72 ) ), vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), 0.26 ), mix( ( nodeVar21.xyz * vec3<f32>( 0.94 ) ), vec3<f32>( 0.15292615198613213, 0.04231141061442144, 0.011612245176281512 ), 0.5 ), ( clamp( ( ( step( 0.86, nodeConst43 ) * 0.9 ) + ( nodeVar23.z * 0.5 ) ), 0.0, 1.0 ) * ( ( ( 1.0 - smoothstep( 0.1, 0.9, nodeConst46 ) ) * 0.7 ) + 0.3 ) ) ), nodeVar60 );
	nodeVar21.x = nodeVar61[ 0 ];
	nodeVar21.y = nodeVar61[ 1 ];
	nodeVar21.z = nodeVar61[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeVar60 * 0.09 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeVar60 * 0.35 ) ) );
	let nodeConst47 = ( v_positionWorld.y - object.nodeUniform14 );
	let nodeConst48 = ( 1.0 - smoothstep( 0.02, 0.22, nodeConst47 ) );
	let nodeConst49 = ( ( ( nodeConst37 * max( nodeConst48, ( pow( ( 1.0 - smoothstep( 0.1, max( object.nodeUniform13.z, 0.101 ), nodeConst47 ) ), 2.0 ) * 0.85 ) ) ) * step( 0.0001, object.nodeUniform13.z ) ) * ( ( smoothstep( 0.25, 0.72, ( ( nodeVar38.z * 0.7 ) + ( nodeVar39.y * 0.4 ) ) ) * 0.45 ) + 0.55 ) );
	nodeVar62 = mix( ( nodeVar21.xyz * vec3<f32>( ( 1.0 - ( nodeConst49 * 0.35 ) ) ) ), mix( vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), ( vec3<f32>( 0.33245153633549385, 0.2541520943200296, 0.1499597898006365 ) * vec3<f32>( 0.9 ) ), 0.35 ), ( nodeConst49 * 0.42 ) );
	nodeVar21.x = nodeVar62[ 0 ];
	nodeVar21.y = nodeVar62[ 1 ];
	nodeVar21.z = nodeVar62[ 2 ];
	nodeVar23.y = clamp( ( ( nodeVar23.y + ( nodeConst49 * 0.16 ) ) - ( ( ( nodeConst48 * nodeConst37 ) * 0.1 ) * step( 0.0001, object.nodeUniform13.z ) ) ), 0.0, 1.0 );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeConst49 * 0.18 ) ) );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst49 * 0.7 ) ) );
	let nodeConst50 = ( ( ( ( nodeVar38.x * 0.6 ) + ( nodeVar39.z * 0.7 ) ) * 0.18 ) + 0.26 );
	let nodeConst51 = ( clamp( ( pow( ( nodeConst37 * ( 1.0 - smoothstep( ( nodeConst50 * 0.25 ), nodeConst50, nodeConst47 ) ) ), 2.0 ) * ( ( smoothstep( 0.2, 0.8, nodeVar39.y ) * 0.5 ) + 0.7 ) ), 0.0, 1.0 ) * step( 0.0001, object.nodeUniform13.z ) );
	nodeVar63 = mix( nodeVar21.xyz, vec3<f32>( 0.33245153633549385, 0.2541520943200296, 0.1499597898006365 ), ( nodeConst51 * 0.46 ) );
	nodeVar21.x = nodeVar63[ 0 ];
	nodeVar21.y = nodeVar63[ 1 ];
	nodeVar21.z = nodeVar63[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst51 * 0.07 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst51 * 0.9 ) ) );
	let nodeConst52 = ( 1.0 - nodeVar35 );
	nodeVar64 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), ( pow( nodeConst52, 2.0 ) * object.nodeUniform13.w ) );
	nodeVar21.x = nodeVar64[ 0 ];
	nodeVar21.y = nodeVar64[ 1 ];
	nodeVar21.z = nodeVar64[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( nodeConst52 * object.nodeUniform13.w ) * 0.5 ) ) );
	let nodeConst53 = clamp( ( ( ( nodeVarying8.x * 0.5 ) * ( ( smoothstep( 0.3, 0.8, nodeVar35 ) * 0.45 ) + 0.55 ) ) * ( ( smoothstep( 0.25, 0.85, ( ( nodeVar38.z * 0.65 ) + ( nodeVar39.w * 0.55 ) ) ) * 1.15 ) + 0.25 ) ), 0.0, 1.0 );
	nodeVar65 = mix( nodeVar21.xyz, vec3<f32>( 0.43415363616478553, 0.3813260114221238, 0.2874408377161099 ), ( nodeConst53 * 0.5 ) );
	nodeVar21.x = nodeVar65[ 0 ];
	nodeVar21.y = nodeVar65[ 1 ];
	nodeVar21.z = nodeVar65[ 2 ];
	nodeVar23.y = mix( nodeVar23.y, 0.42, nodeConst53 );
	nodeVar23.z = mix( nodeVar23.z, 0.0, nodeConst53 );
	let nodeConst54 = ( ( ( nodeVarying8.y * 0.7 ) * ( ( nodeConst52 * 0.65 ) + 0.35 ) ) * ( ( nodeVar39.y * 0.9 ) + 0.45 ) );
	nodeVar66 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), ( nodeConst54 * 0.8 ) );
	nodeVar21.x = nodeVar66[ 0 ];
	nodeVar21.y = nodeVar66[ 1 ];
	nodeVar21.z = nodeVar66[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst54 * 0.22 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst54 * 0.8 ) ) );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeVarying8.z * 0.5 ) ) );
	nodeVar67 = ( nodeVar21.xyz * object.nodeUniform15 );
	nodeVar21.x = nodeVar67[ 0 ];
	nodeVar21.y = nodeVar67[ 1 ];
	nodeVar21.z = nodeVar67[ 2 ];
	nodeVar68 = StructType0( nodeVar21.xyz, nodeVar21.w, normalize( ( render.cameraViewMatrix * vec4<f32>( nodeVar32, 0.0 ) ).xyz ), clamp( ( ( nodeVar23.y * 0.97 ) + -0.02 ), 0.26, 1.0 ), clamp( nodeVar23.z, 0.0, 1.0 ), ( 1.0 + ( ( nodeVar23.x - 1.0 ) * 1.0 ) ) );
	DiffuseColor = vec4<f32>( nodeVar68.color, 1.0 );
	DiffuseColor.w = ( DiffuseColor.w * object.nodeUniform17 );
	DiffuseColor.w = 1.0;
	AmbientOcclusion = nodeVar68.ao;
	let nodeConst55 = ( nodeVar68.metal * object.nodeUniform18 );
	Metalness = nodeConst55;
	normalViewGeometry = normalize( v_normalViewGeometry );
	let nodeConst56 = max( abs( dpdx( normalViewGeometry ) ), abs( - dpdy( normalViewGeometry ) ) );
	Roughness = min( ( max( ( nodeVar68.rough * object.nodeUniform19 ), 0.045 ) + max( max( nodeConst56.x, nodeConst56.y ), nodeConst56.z ) ), 1.0 );
	SpecularColor = vec3<f32>( 0.04, 0.04, 0.04 );
	SpecularColorBlended = mix( vec3<f32>( 0.04, 0.04, 0.04 ), DiffuseColor.xyz, Metalness );
	SpecularF90 = 1.0;
	DiffuseContribution = ( DiffuseColor.xyz * vec3<f32>( ( 1.0 - nodeConst55 ) ) );
	EmissiveColor = ( object.nodeUniform20 * vec3<f32>( object.nodeUniform21 ) );
	Output = max( vec4<f32>( ( vec3<f32>( 0.0, 0.0, 0.0 ) + EmissiveColor ), DiffuseColor.w ), vec4<f32>( 0.0 ) );
	normalView = nodeVar68.normal;
	output.m0 = vec4<f32>( normalView, 1.0 );
	let nodeConst57 = ( - v_positionView.z );
	output.m1 = vec4<f32>( nodeConst57 );
	modelViewMatrix = ( render.cameraViewMatrix * object.nodeUniform23 );
	let nodeConst58 = ( ( render.nodeUniform22 * modelViewMatrix ) * vec4<f32>( positionLocal, 1.0 ) );
	let nodeConst59 = ( ( render.nodeUniform24 * ( render.nodeUniform25 * object.nodeUniform26 ) ) * vec4<f32>( positionPrevious, 1.0 ) );
	let nodeConst60 = ( ( nodeConst58.xy / vec2<f32>( nodeConst58.w ) ) - ( nodeConst59.xy / vec2<f32>( nodeConst59.w ) ) );
	output.m2 = vec4<f32>( vec3<f32>( nodeConst60, 0.0 ), 1.0 );

	// result

	return output;

}
