// Three.js r187dev - Node System

// directives


// structs


// uniforms

struct nodeUniform0Struct {
	value : array< mat4x4<f32> >
};
@binding( 29 ) @group( 2 )
var<storage, read> nodeUniform0 : nodeUniform0Struct;

struct renderStruct {
	nodeUniform98 : vec3<f32>,
	nodeUniform99 : vec3<f32>,
	nodeUniform100 : vec3<f32>,
	nodeUniform93 : f32,
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	cameraWorldMatrix : mat4x4<f32>,
	clusteredCameraNear : f32,
	clusteredCameraFar : f32,
	clusteredCameraViewMatrix : mat4x4<f32>,
	nodeUniform22 : vec2<f32>,
	cameraPosition : vec3<f32>,
	nodeUniform30 : vec3<f32>,
	nodeUniform72 : vec3<f32>,
	nodeUniform82 : f32,
	nodeUniform83 : f32,
	nodeUniform86 : f32,
	nodeUniform87 : f32,
	nodeUniform74 : vec3<f32>,
	shadowFar : f32,
	nodeUniform32 : f32,
	nodeUniform34 : mat4x4<f32>,
	nodeUniform35 : f32,
	nodeUniform36 : f32,
	nodeUniform37 : f32,
	nodeUniform38 : f32,
	nodeUniform39 : vec2<f32>,
	nodeUniform40 : f32,
	nodeUniform41 : f32,
	nodeUniform43 : f32,
	nodeUniform44 : vec2<f32>,
	nodeUniform45 : f32,
	nodeUniform46 : mat4x4<f32>,
	nodeUniform47 : f32,
	nodeUniform48 : f32,
	nodeUniform49 : f32,
	nodeUniform50 : f32,
	nodeUniform51 : vec2<f32>,
	nodeUniform52 : f32,
	nodeUniform53 : f32,
	nodeUniform55 : f32,
	nodeUniform56 : vec2<f32>,
	nodeUniform57 : f32,
	nodeUniform58 : mat4x4<f32>,
	nodeUniform59 : f32,
	nodeUniform60 : f32,
	nodeUniform61 : f32,
	nodeUniform62 : f32,
	nodeUniform63 : vec2<f32>,
	nodeUniform64 : f32,
	nodeUniform65 : f32,
	nodeUniform67 : f32,
	nodeUniform68 : vec2<f32>,
	nodeUniform69 : f32,
	nodeUniform73 : vec3<f32>,
	nodeUniform75 : mat4x4<f32>,
	nodeUniform76 : f32,
	nodeUniform77 : f32,
	nodeUniform79 : f32,
	nodeUniform80 : vec2<f32>,
	nodeUniform81 : f32
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

struct objectStruct {
	nodeUniform3 : mat3x3<f32>,
	nodeUniform4 : mat4x4<f32>,
	nodeUniform5 : f32,
	nodeUniform6 : f32,
	nodeUniform11 : f32,
	nodeUniform15 : vec4<f32>,
	nodeUniform16 : f32,
	nodeUniform17 : vec3<f32>,
	nodeUniform19 : f32,
	nodeUniform21 : mat3x3<f32>,
	nodeUniform23 : f32,
	nodeUniform24 : f32,
	nodeUniform25 : vec3<f32>,
	nodeUniform26 : f32,
	nodeUniform89 : mat4x4<f32>,
	nodeUniform91 : f32,
	nodeUniform92 : f32,
	nodeUniform94 : i32,
	nodeUniform96 : vec4<f32>,
	nodeUniform102 : vec2<f32>
};
@binding( 0 ) @group( 2 )
var<uniform> object : objectStruct;

// varyings

struct VaryingsStruct {
	@location( 0 ) v_positionView : vec3<f32>,
	@location( 1 ) v_normalWorldGeometry : vec3<f32>,
	@location( 2 ) v_normalViewGeometry : vec3<f32>,
	@location( 3 ) v_positionWorld : vec3<f32>,
	@location( 4 ) v_positionViewDirection : vec3<f32>,
	@location( 5 ) vInstanceColor : vec3<f32>,
	@location( 6 ) nodeVarying9 : vec4<f32>,
	@builtin( position ) builtinClipSpace : vec4<f32>
};
var<private> varyings : VaryingsStruct;

// vars
var<private> normalLocal : vec3<f32>;
var<private> normalViewGeometry : vec3<f32>;
var<private> modelViewMatrix : mat4x4<f32>;
var<private> positionLocal : vec3<f32>;
var<private> v_modelViewProjection : vec4<f32>;
var<private> VERTEX_v_modelViewProjection : vec4<f32>;

// codes

fn tsl_inverse_mat3( m : mat3x3<f32> ) -> mat3x3<f32> {

	let a00 = m[ 0 ][ 0 ]; let a01 = m[ 0 ][ 1 ]; let a02 = m[ 0 ][ 2 ];
	let a10 = m[ 1 ][ 0 ]; let a11 = m[ 1 ][ 1 ]; let a12 = m[ 1 ][ 2 ];
	let a20 = m[ 2 ][ 0 ]; let a21 = m[ 2 ][ 1 ]; let a22 = m[ 2 ][ 2 ];

	let b01 = a22 * a11 - a12 * a21;
	let b11 = - a22 * a10 + a12 * a20;
	let b21 = a21 * a10 - a11 * a20;

	let det = a00 * b01 + a01 * b11 + a02 * b21;

	return mat3x3<f32>(
		b01, ( - a22 * a01 + a02 * a21 ), ( a12 * a01 - a02 * a11 ),
		b11, ( a22 * a00 - a02 * a20 ), ( - a12 * a00 + a02 * a10 ),
		b21, ( - a21 * a00 + a01 * a20 ), ( a11 * a00 - a01 * a10 )
	) * ( 1.0 / det );

}



@vertex
fn main( @builtin( instance_index ) instanceIndex : u32,
	@location( 0 ) position : vec3<f32>,
	@location( 1 ) normal : vec3<f32>,
	@location( 2 ) color : vec3<f32>,
	@location( 3 ) nodeAttribute1 : vec3<f32> ) -> VaryingsStruct {

	// flow
	// code

	positionLocal = position;
	positionLocal = ( nodeUniform0.value[ instanceIndex ] * vec4<f32>( positionLocal, 1.0 ) ).xyz;
	normalLocal = normal;
	normalLocal = normalize( ( transpose( tsl_inverse_mat3( mat3x3<f32>( nodeUniform0.value[ instanceIndex ][ 0 ].xyz, nodeUniform0.value[ instanceIndex ][ 1 ].xyz, nodeUniform0.value[ instanceIndex ][ 2 ].xyz ) ) ) * normalLocal ) );
	varyings.vInstanceColor = nodeAttribute1;
	let nodeConst0 = normalize( ( render.cameraViewMatrix * vec4<f32>( ( object.nodeUniform3 * normalLocal ), 0.0 ) ).xyz );
	varyings.v_normalViewGeometry = nodeConst0;
	normalViewGeometry = normalize( varyings.v_normalViewGeometry );
	varyings.v_normalWorldGeometry = normalize( ( vec4<f32>( normalViewGeometry, 0.0 ) * render.cameraViewMatrix ).xyz );
	varyings.v_positionWorld = ( object.nodeUniform4 * vec4<f32>( positionLocal, 1.0 ) ).xyz;
	varyings.nodeVarying9 = vec4<f32>( color, 1.0 );
	modelViewMatrix = ( render.cameraViewMatrix * object.nodeUniform4 );
	varyings.v_positionView = ( modelViewMatrix * vec4<f32>( positionLocal, 1.0 ) ).xyz;
	varyings.v_positionViewDirection = ( - varyings.v_positionView );
	let VERTEX_nodeConst130 = ( render.cameraProjectionMatrix * vec4<f32>( varyings.v_positionView, 1.0 ) );
	VERTEX_v_modelViewProjection = VERTEX_nodeConst130;

	// result

	varyings.builtinClipSpace = VERTEX_v_modelViewProjection;

	return varyings;

}
