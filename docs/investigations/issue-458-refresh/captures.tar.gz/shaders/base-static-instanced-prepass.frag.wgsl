// Three.js r187dev - Node System

// global
diagnostic( off, derivative_uniformity );


// directives


// structs

struct StructType0 {
	color : vec3<f32>,
	opacity : f32,
	normal : vec3<f32>,
	rough : f32,
	metal : f32,
	ao : f32
};

struct OutputType {
	@location( 0 ) m0 : vec4<f32>,
	@location( 1 ) m1 : vec4<f32>,
	@location( 2 ) m2 : vec4<f32>,
	
};
var<private> output : OutputType;

// uniforms
@binding( 1 ) @group( 1 ) var nodeUniform9_sampler : sampler;
@binding( 2 ) @group( 1 ) var nodeUniform9 : texture_2d<f32>;
@binding( 3 ) @group( 1 ) var nodeUniform10_sampler : sampler;
@binding( 4 ) @group( 1 ) var nodeUniform10 : texture_2d<f32>;
@binding( 5 ) @group( 1 ) var nodeUniform11_sampler : sampler;
@binding( 6 ) @group( 1 ) var nodeUniform11 : texture_2d<f32>;
@binding( 7 ) @group( 1 ) var nodeUniform13_sampler : sampler;
@binding( 8 ) @group( 1 ) var nodeUniform13 : texture_2d<f32>;
@binding( 9 ) @group( 1 ) var nodeUniform14_sampler : sampler;
@binding( 10 ) @group( 1 ) var nodeUniform14 : texture_2d<f32>;
@binding( 11 ) @group( 1 ) var nodeUniform15_sampler : sampler;
@binding( 12 ) @group( 1 ) var nodeUniform15 : texture_2d<f32>;

struct objectStruct {
	nodeUniform4 : mat3x3<f32>,
	nodeUniform5 : mat4x4<f32>,
	nodeUniform6 : f32,
	nodeUniform7 : f32,
	nodeUniform12 : f32,
	nodeUniform16 : vec4<f32>,
	nodeUniform17 : f32,
	nodeUniform18 : vec3<f32>,
	nodeUniform20 : f32,
	nodeUniform21 : f32,
	nodeUniform22 : f32,
	nodeUniform23 : vec3<f32>,
	nodeUniform24 : f32,
	nodeUniform26 : mat4x4<f32>,
	nodeUniform29 : mat4x4<f32>
};
@binding( 0 ) @group( 1 )
var<uniform> object : objectStruct;

struct renderStruct {
	nodeUniform25 : mat4x4<f32>,
	nodeUniform27 : mat4x4<f32>,
	nodeUniform28 : mat4x4<f32>,
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	cameraPosition : vec3<f32>
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

// vars
var<private> DiffuseColor : vec4<f32>;
var<private> nodeVar0 : vec3<f32>;
var<private> nodeVar1 : f32;
var<private> nodeVar2 : vec3<f32>;
var<private> normalWorldGeometry : vec3<f32>;
var<private> nodeVar3 : f32;
var<private> nodeVar4 : vec3<f32>;
var<private> nodeVar5 : vec3<f32>;
var<private> nodeVar6 : vec3<f32>;
var<private> nodeVar7 : vec2<f32>;
var<private> nodeVar8 : vec2<f32>;
var<private> nodeVar9 : vec2<f32>;
var<private> nodeVar10 : vec2<f32>;
var<private> nodeVar11 : vec2<f32>;
var<private> nodeVar12 : f32;
var<private> nodeVar13 : f32;
var<private> nodeVar14 : vec2<f32>;
var<private> nodeVar15 : f32;
var<private> nodeVar16 : vec4<f32>;
var<private> nodeVar17 : f32;
var<private> nodeVar18 : vec4<f32>;
var<private> nodeVar19 : vec4<f32>;
var<private> nodeVar20 : vec4<f32>;
var<private> nodeVar21 : vec4<f32>;
var<private> nodeVar22 : vec4<f32>;
var<private> nodeVar23 : vec3<f32>;
var<private> nodeVar24 : vec4<f32>;
var<private> nodeVar25 : vec3<f32>;
var<private> nodeVar26 : vec3<f32>;
var<private> nodeVar27 : vec4<f32>;
var<private> nodeVar28 : vec3<f32>;
var<private> nodeVar29 : f32;
var<private> nodeVar30 : vec4<f32>;
var<private> nodeVar31 : vec2<f32>;
var<private> nodeVar32 : vec4<f32>;
var<private> nodeVar33 : vec4<f32>;
var<private> nodeVar34 : vec3<f32>;
var<private> nodeVar35 : vec3<f32>;
var<private> nodeVar36 : vec3<f32>;
var<private> nodeVar37 : vec3<f32>;
var<private> nodeVar38 : f32;
var<private> nodeVar39 : f32;
var<private> nodeVar40 : vec4<f32>;
var<private> nodeVar41 : vec4<f32>;
var<private> nodeVar42 : f32;
var<private> nodeVar43 : vec3<f32>;
var<private> nodeVar44 : vec3<f32>;
var<private> nodeVar45 : vec3<f32>;
var<private> nodeVar46 : vec3<f32>;
var<private> nodeVar47 : vec3<f32>;
var<private> nodeVar48 : vec3<f32>;
var<private> nodeVar49 : vec3<f32>;
var<private> nodeVar50 : StructType0;
var<private> AmbientOcclusion : f32;
var<private> Metalness : f32;
var<private> Roughness : f32;
var<private> normalViewGeometry : vec3<f32>;
var<private> SpecularColor : vec3<f32>;
var<private> SpecularColorBlended : vec3<f32>;
var<private> SpecularF90 : f32;
var<private> DiffuseContribution : vec3<f32>;
var<private> EmissiveColor : vec3<f32>;
var<private> Output : vec4<f32>;
var<private> normalView : vec3<f32>;
var<private> modelViewMatrix : mat4x4<f32>;

// codes


@fragment
fn main( @location( 0 ) positionLocal : vec3<f32>,
	@location( 1 ) positionPrevious : vec3<f32>,
	@location( 2 ) v_positionView : vec3<f32>,
	@location( 3 ) v_normalWorldGeometry : vec3<f32>,
	@location( 4 ) v_normalViewGeometry : vec3<f32>,
	@location( 5 ) v_positionWorld : vec3<f32>,
	@location( 6 ) vInstanceColor : vec3<f32>,
	@location( 7 ) nodeVarying9 : vec4<f32>,
	@builtin( front_facing ) isFront : bool ) -> OutputType {

	// flow
	// code


	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = ( - nodeConst1 );

	}

	let nodeConst2 = pow( abs( nodeVar2 ), vec3<f32>( 5.0, 5.0, 5.0 ) );
	let nodeConst3 = ( nodeConst2 / vec3<f32>( max( ( ( nodeConst2.x + nodeConst2.y ) + nodeConst2.z ), 0.0001 ) ) );

	if ( ( ( nodeConst3.x > nodeConst3.y ) && ( nodeConst3.x > nodeConst3.z ) ) ) {

		nodeVar1 = 0.0;

	} else {


		if ( ( nodeConst3.y > nodeConst3.z ) ) {

			nodeVar3 = 1.0;

		} else {

			nodeVar3 = 2.0;

		}

		nodeVar1 = nodeVar3;

	}


	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar0 = vec3<f32>( 0.0, 0.0, ( - nodeConst4 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar4 = vec3<f32>( 1.0, 0.0, 0.0 );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar4 = vec3<f32>( nodeConst5, 0.0, 0.0 );

		}

		nodeVar0 = nodeVar4;

	}

	nodeVar5 = normalize( ( nodeVar0 - ( nodeVar2 * vec3<f32>( dot( nodeVar0, nodeVar2 ) ) ) ) );
	nodeVar6 = cross( nodeVar2, nodeVar5 );

	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar7 = ( ( vec2<f32>( ( ( - v_positionWorld.z ) * nodeConst4 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform6 ) ) + vec2<f32>( 0.0, 0.0 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar8 = ( ( vec2<f32>( v_positionWorld.x, ( ( - v_positionWorld.z ) * ( ( step( 0.0, nodeVar2.y ) * 2.0 ) - 1.0 ) ) ) * vec2<f32>( object.nodeUniform6 ) ) + vec2<f32>( 0.0, 0.0 ) );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar8 = ( ( vec2<f32>( ( v_positionWorld.x * nodeConst5 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform6 ) ) + vec2<f32>( 0.0, 0.0 ) );

		}

		nodeVar7 = nodeVar8;

	}

	nodeVar9 = nodeVar7;
	nodeVar10 = dpdx( nodeVar7 );
	nodeVar11 = - dpdy( nodeVar7 );
	let nodeConst6 = ( object.nodeUniform7 * object.nodeUniform6 );
	let nodeConst7 = length( ( render.cameraPosition - v_positionWorld ) );
	let nodeConst8 = ( 1.0 - smoothstep( 6.0, 14.0, nodeConst7 ) );

	if ( ( ( nodeConst6 > 0.0 ) && ( nodeConst8 > 0.001 ) ) ) {

		let nodeConst9 = normalize( ( render.cameraPosition - v_positionWorld ) );
		let nodeConst10 = normalize( vec3<f32>( dot( nodeConst9, nodeVar5 ), dot( nodeConst9, nodeVar6 ), dot( nodeConst9, nodeVar2 ) ) );
		nodeVar12 = max( ( mix( 16.0, 8.0, clamp( abs( nodeConst10.z ), 0.0, 1.0 ) ) * nodeConst8 ), 4.0 );
		nodeVar13 = ( 1.0 / nodeVar12 );
		nodeVar14 = ( ( ( ( nodeConst10.xy / vec2<f32>( max( abs( nodeConst10.z ), 0.3 ) ) ) * vec2<f32>( nodeConst6 ) ) * vec2<f32>( nodeConst8 ) ) * vec2<f32>( nodeVar13 ) );
		nodeVar15 = 0.0;
		nodeVar16 = textureSampleGrad( nodeUniform9, nodeUniform9_sampler, nodeVar9, nodeVar10, nodeVar11 );
		nodeVar17 = ( 1.0 - nodeVar16.w );

		for ( var i : i32 = 0; i < 48; i ++ ) {


			if ( ( ( nodeVar15 >= nodeVar17 ) || ( f32( i ) >= nodeVar12 ) ) ) {

				break;
				

			}

			nodeVar9 = ( nodeVar9 - nodeVar14 );
			nodeVar18 = textureSampleGrad( nodeUniform9, nodeUniform9_sampler, nodeVar9, nodeVar10, nodeVar11 );
			nodeVar17 = ( 1.0 - nodeVar18.w );
			nodeVar15 = ( nodeVar15 + nodeVar13 );

		}

		let nodeConst11 = ( nodeVar9 + nodeVar14 );
		let nodeConst12 = ( nodeVar17 - nodeVar15 );
		nodeVar19 = textureSampleGrad( nodeUniform9, nodeUniform9_sampler, nodeConst11, nodeVar10, nodeVar11 );
		nodeVar9 = mix( nodeVar9, nodeConst11, clamp( ( ( - nodeConst12 ) / max( ( ( ( ( 1.0 - nodeVar19.w ) - nodeVar15 ) + nodeVar13 ) - nodeConst12 ), 0.0001 ) ), 0.0, 1.0 ) );
		

	}

	nodeVar20 = textureSample( nodeUniform9, nodeUniform9_sampler, nodeVar9 );
	nodeVar21 = nodeVar20;
	nodeVar22 = textureSample( nodeUniform10, nodeUniform10_sampler, nodeVar9 );
	nodeVar23 = nodeVar22.xyz;
	nodeVar24 = textureSample( nodeUniform11, nodeUniform11_sampler, nodeVar9 );
	nodeVar25 = normalize( vec3<f32>( ( ( ( nodeVar24.x * 2.0 ) - 1.0 ) * object.nodeUniform12 ), ( ( ( nodeVar24.y * 2.0 ) - 1.0 ) * object.nodeUniform12 ), ( ( nodeVar24.z * 2.0 ) - 1.0 ) ) );
	nodeVar26 = ( ( ( nodeVar5 * vec3<f32>( nodeVar25.x ) ) + ( nodeVar6 * vec3<f32>( nodeVar25.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeVar25.z ) ) );
	let nodeConst13 = ( nodeVar9 * vec2<f32>( 3.846153846153846 ) );
	nodeVar27 = textureSample( nodeUniform13, nodeUniform13_sampler, nodeConst13 );
	let nodeConst14 = ( ( nodeVar27.w - 0.5 ) * 2.0 );
	let nodeConst15 = ( 1.0 - smoothstep( 7.2, 16.0, nodeConst7 ) );
	nodeVar28 = ( nodeVar21.xyz * vec3<f32>( ( 1.0 + ( ( ( ( nodeConst14 * 0.95 ) + ( ( nodeVar27.x - 0.5 ) * 1.25 ) ) * 0.32 ) * nodeConst15 ) ) ) );
	nodeVar21.x = nodeVar28[ 0 ];
	nodeVar21.y = nodeVar28[ 1 ];
	nodeVar21.z = nodeVar28[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( max( ( - nodeConst14 ), 0.0 ) * 0.096 ) * nodeConst15 ) ) );
	nodeVar29 = clamp( ( nodeVar21.w + ( ( nodeConst14 * 0.16 ) * nodeConst15 ) ), 0.0, 1.0 );
	nodeVar30 = textureSample( nodeUniform14, nodeUniform14_sampler, nodeConst13 );
	let nodeConst16 = ( ( nodeVar30.xyz * vec3<f32>( 2.0 ) ) - vec3<f32>( 1.0 ) );
	let nodeConst17 = ( ( ( nodeVar5 * vec3<f32>( nodeConst16.x ) ) + ( nodeVar6 * vec3<f32>( nodeConst16.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeConst16.z ) ) );
	nodeVar26 = normalize( ( nodeVar26 + ( ( ( nodeConst17 - ( nodeVar2 * vec3<f32>( dot( nodeConst17, nodeVar2 ) ) ) ) * vec3<f32>( 0.6 ) ) * vec3<f32>( nodeConst15 ) ) ) );

	if ( ( step( 0.62, abs( nodeVar2.y ) ) > 0.5 ) ) {

		nodeVar31 = v_positionWorld.xz;

	} else {

		nodeVar31 = vec2<f32>( ( v_positionWorld.x + ( v_positionWorld.z * 0.63 ) ), v_positionWorld.y );

	}

	nodeVar32 = textureSample( nodeUniform15, nodeUniform15_sampler, ( nodeVar31 * vec2<f32>( 0.1 ) ) );
	nodeVar33 = textureSample( nodeUniform15, nodeUniform15_sampler, ( ( nodeVar31 * vec2<f32>( 0.0211 ) ) + vec2<f32>( 0.37 ) ) );
	nodeVar34 = ( nodeVar21.xyz * vec3<f32>( mix( 1.0, ( ( clamp( ( ( ( ( ( nodeVar32.x * 0.55 ) + ( nodeVar33.z * 0.45 ) ) - 0.5 ) * 1.0 ) + 0.5 ), 0.0, 1.0 ) * 0.92 ) + 0.55 ), 0.28 ) ) );
	nodeVar21.x = nodeVar34[ 0 ];
	nodeVar21.y = nodeVar34[ 1 ];
	nodeVar21.z = nodeVar34[ 2 ];
	nodeVar35 = ( nodeVar21.xyz * mix( vec3<f32>( 1.0, 1.0, 1.0 ), vec3<f32>( 1.05, 1.0, 0.93 ), ( ( nodeVar33.x - 0.5 ) * 0.35 ) ) );
	nodeVar21.x = nodeVar35[ 0 ];
	nodeVar21.y = nodeVar35[ 1 ];
	nodeVar21.z = nodeVar35[ 2 ];
	nodeVar23.y = clamp( ( ( ( nodeVar23.y + ( ( nodeVar32.y - 0.5 ) * 0.14 ) ) + ( ( nodeVar32.w - 0.5 ) * 0.16 ) ) - ( ( nodeConst14 * 0.07 ) * nodeConst15 ) ), 0.0, 1.0 );

	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar36 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar36 = ( - nodeConst1 );

	}

	let nodeConst18 = ( ( pow( clamp( nodeVar36.y, 0.0, 1.0 ), 2.0 ) * object.nodeUniform16.x ) * smoothstep( 0.3, 0.8, ( ( nodeVar32.z * 0.7 ) + ( nodeVar33.y * 0.5 ) ) ) );
	nodeVar37 = mix( nodeVar21.xyz, vec3<f32>( 0.14702726648767014, 0.11953842797895521, 0.08865558627723595 ), ( nodeConst18 * 0.75 ) );
	nodeVar21.x = nodeVar37[ 0 ];
	nodeVar21.y = nodeVar37[ 1 ];
	nodeVar21.z = nodeVar37[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst18 * 0.3 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst18 * 0.85 ) ) );
	let nodeConst19 = ( 1.0 - smoothstep( 0.34, 0.72, abs( nodeVar36.y ) ) );
	let nodeConst20 = ( ( v_positionWorld.z * nodeVar36.x ) - ( v_positionWorld.x * nodeVar36.z ) );
	let nodeConst21 = ( nodeConst20 * 1.55 );
	let nodeConst22 = floor( nodeConst21 );
	nodeVar38 = fract( ( ( ( nodeConst22 * 2.71 ) + 11.7 ) * 0.1031 ) );
	nodeVar38 = ( nodeVar38 * ( nodeVar38 + 33.33 ) );
	nodeVar38 = ( nodeVar38 * ( nodeVar38 + nodeVar38 ) );
	let nodeConst23 = fract( nodeVar38 );
	nodeVar39 = fract( ( ( ( nodeConst22 * 1.37 ) + 3.1 ) * 0.1031 ) );
	nodeVar39 = ( nodeVar39 * ( nodeVar39 + 33.33 ) );
	nodeVar39 = ( nodeVar39 * ( nodeVar39 + nodeVar39 ) );
	let nodeConst24 = fract( nodeVar39 );
	let nodeConst25 = ( ( nodeConst23 * 1.2 ) + ( nodeConst24 * 0.5 ) );
	nodeVar40 = textureSample( nodeUniform15, nodeUniform15_sampler, vec2<f32>( ( nodeConst20 * 0.46 ), ( v_positionWorld.y * 0.155 ) ) );
	let nodeConst26 = ( ( ( ( ( floor( ( ( v_positionWorld.y + nodeConst25 ) / 2.85 ) ) + 1.0 ) * 2.85 ) - nodeConst25 ) + ( ( nodeVar40.w - 0.5 ) * 0.2 ) ) - v_positionWorld.y );
	nodeVar41 = textureSample( nodeUniform15, nodeUniform15_sampler, vec2<f32>( ( ( nodeConst20 * 1.35 ) + 0.4 ), ( v_positionWorld.y * 0.42 ) ) );
	nodeVar42 = clamp( ( ( ( nodeConst19 * clamp( ( ( smoothstep( 0.0, 0.15, nodeConst26 ) * ( 1.0 - smoothstep( 0.15, 1.65, nodeConst26 ) ) ) * ( ( ( smoothstep( 0.3, 0.62, nodeConst24 ) * ( ( nodeConst23 * 0.45 ) + 0.55 ) ) * pow( sin( ( fract( nodeConst21 ) * 3.14159265 ) ), 2.0 ) ) * ( ( nodeConst24 * 0.45 ) + 0.8 ) ) ), 0.0, 1.0 ) ) * clamp( ( object.nodeUniform16.y * 2.2 ), 0.0, 1.15 ) ) * smoothstep( 0.3, 0.66, ( ( nodeVar40.w * 0.72 ) + ( nodeVar41.y * 0.38 ) ) ) ), 0.0, 1.0 );
	nodeVar42 = clamp( ( ( nodeVar42 * ( ( clamp( ( ( nodeVarying9.y * 1.5 ) + ( nodeVarying9.z * 0.6 ) ), 0.0, 1.0 ) * 0.75 ) + 0.45 ) ) + ( ( smoothstep( 0.58, 0.98, nodeVarying9.y ) * nodeConst19 ) * ( ( smoothstep( 0.2, 0.7, ( ( nodeVar40.w * 0.6 ) + ( nodeVar41.y * 0.55 ) ) ) * 0.45 ) + 0.55 ) ) ), 0.0, 1.0 );
	nodeVar42 = ( nodeVar42 * step( 0.0001, object.nodeUniform16.y ) );
	nodeVar43 = mix( nodeVar21.xyz, mix( mix( ( nodeVar21.xyz * vec3<f32>( 0.72 ) ), vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), 0.26 ), mix( ( nodeVar21.xyz * vec3<f32>( 0.94 ) ), vec3<f32>( 0.15292615198613213, 0.04231141061442144, 0.011612245176281512 ), 0.5 ), ( clamp( ( ( step( 0.86, nodeConst23 ) * 0.9 ) + ( nodeVar23.z * 0.5 ) ), 0.0, 1.0 ) * ( ( ( 1.0 - smoothstep( 0.1, 0.9, nodeConst26 ) ) * 0.7 ) + 0.3 ) ) ), nodeVar42 );
	nodeVar21.x = nodeVar43[ 0 ];
	nodeVar21.y = nodeVar43[ 1 ];
	nodeVar21.z = nodeVar43[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeVar42 * 0.09 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeVar42 * 0.35 ) ) );
	let nodeConst27 = ( v_positionWorld.y - object.nodeUniform17 );
	let nodeConst28 = ( 1.0 - smoothstep( 0.02, 0.22, nodeConst27 ) );
	let nodeConst29 = ( ( ( nodeConst19 * max( nodeConst28, ( pow( ( 1.0 - smoothstep( 0.1, max( object.nodeUniform16.z, 0.101 ), nodeConst27 ) ), 2.0 ) * 0.85 ) ) ) * step( 0.0001, object.nodeUniform16.z ) ) * ( ( smoothstep( 0.25, 0.72, ( ( nodeVar32.z * 0.7 ) + ( nodeVar33.y * 0.4 ) ) ) * 0.45 ) + 0.55 ) );
	nodeVar44 = mix( ( nodeVar21.xyz * vec3<f32>( ( 1.0 - ( nodeConst29 * 0.35 ) ) ) ), mix( vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), ( vec3<f32>( 0.14702726648767014, 0.11953842797895521, 0.08865558627723595 ) * vec3<f32>( 0.9 ) ), 0.35 ), ( nodeConst29 * 0.42 ) );
	nodeVar21.x = nodeVar44[ 0 ];
	nodeVar21.y = nodeVar44[ 1 ];
	nodeVar21.z = nodeVar44[ 2 ];
	nodeVar23.y = clamp( ( ( nodeVar23.y + ( nodeConst29 * 0.16 ) ) - ( ( ( nodeConst28 * nodeConst19 ) * 0.1 ) * step( 0.0001, object.nodeUniform16.z ) ) ), 0.0, 1.0 );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeConst29 * 0.18 ) ) );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst29 * 0.7 ) ) );
	let nodeConst30 = ( ( ( ( nodeVar32.x * 0.6 ) + ( nodeVar33.z * 0.7 ) ) * 0.18 ) + 0.26 );
	let nodeConst31 = ( clamp( ( pow( ( nodeConst19 * ( 1.0 - smoothstep( ( nodeConst30 * 0.25 ), nodeConst30, nodeConst27 ) ) ), 2.0 ) * ( ( smoothstep( 0.2, 0.8, nodeVar33.y ) * 0.5 ) + 0.7 ) ), 0.0, 1.0 ) * step( 0.0001, object.nodeUniform16.z ) );
	nodeVar45 = mix( nodeVar21.xyz, vec3<f32>( 0.14702726648767014, 0.11953842797895521, 0.08865558627723595 ), ( nodeConst31 * 0.46 ) );
	nodeVar21.x = nodeVar45[ 0 ];
	nodeVar21.y = nodeVar45[ 1 ];
	nodeVar21.z = nodeVar45[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst31 * 0.07 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst31 * 0.9 ) ) );
	let nodeConst32 = ( 1.0 - nodeVar29 );
	nodeVar46 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), ( pow( nodeConst32, 2.0 ) * object.nodeUniform16.w ) );
	nodeVar21.x = nodeVar46[ 0 ];
	nodeVar21.y = nodeVar46[ 1 ];
	nodeVar21.z = nodeVar46[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( nodeConst32 * object.nodeUniform16.w ) * 0.5 ) ) );
	let nodeConst33 = clamp( ( ( ( nodeVarying9.x * 0.5 ) * ( ( smoothstep( 0.3, 0.8, nodeVar29 ) * 0.45 ) + 0.55 ) ) * ( ( smoothstep( 0.25, 0.85, ( ( nodeVar32.z * 0.65 ) + ( nodeVar33.w * 0.55 ) ) ) * 1.15 ) + 0.25 ) ), 0.0, 1.0 );
	nodeVar47 = mix( nodeVar21.xyz, vec3<f32>( 0.2746773120495699, 0.2874408377161099, 0.3049873140591091 ), ( nodeConst33 * 0.9 ) );
	nodeVar21.x = nodeVar47[ 0 ];
	nodeVar21.y = nodeVar47[ 1 ];
	nodeVar21.z = nodeVar47[ 2 ];
	nodeVar23.y = mix( nodeVar23.y, 0.3, nodeConst33 );
	nodeVar23.z = mix( nodeVar23.z, 1.0, nodeConst33 );
	let nodeConst34 = ( ( ( nodeVarying9.y * 0.7 ) * ( ( nodeConst32 * 0.65 ) + 0.35 ) ) * ( ( nodeVar33.y * 0.9 ) + 0.45 ) );
	nodeVar48 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), ( nodeConst34 * 0.8 ) );
	nodeVar21.x = nodeVar48[ 0 ];
	nodeVar21.y = nodeVar48[ 1 ];
	nodeVar21.z = nodeVar48[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst34 * 0.22 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst34 * 0.8 ) ) );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeVarying9.z * 0.5 ) ) );
	nodeVar49 = ( nodeVar21.xyz * object.nodeUniform18 );
	nodeVar21.x = nodeVar49[ 0 ];
	nodeVar21.y = nodeVar49[ 1 ];
	nodeVar21.z = nodeVar49[ 2 ];
	nodeVar50 = StructType0( nodeVar21.xyz, nodeVar21.w, normalize( ( render.cameraViewMatrix * vec4<f32>( nodeVar26, 0.0 ) ).xyz ), clamp( ( ( nodeVar23.y * 0.92 ) + -0.03 ), 0.22, 1.0 ), clamp( nodeVar23.z, 0.0, 1.0 ), ( 1.0 + ( ( nodeVar23.x - 1.0 ) * 1.0 ) ) );
	DiffuseColor = ( vec4<f32>( vInstanceColor, 1.0 ) * vec4<f32>( nodeVar50.color, 1.0 ) );
	DiffuseColor.w = ( DiffuseColor.w * object.nodeUniform20 );
	DiffuseColor.w = 1.0;
	AmbientOcclusion = nodeVar50.ao;
	let nodeConst35 = ( nodeVar50.metal * object.nodeUniform21 );
	Metalness = nodeConst35;
	normalViewGeometry = normalize( v_normalViewGeometry );
	let nodeConst36 = max( abs( dpdx( normalViewGeometry ) ), abs( - dpdy( normalViewGeometry ) ) );
	Roughness = min( ( max( ( nodeVar50.rough * object.nodeUniform22 ), 0.045 ) + max( max( nodeConst36.x, nodeConst36.y ), nodeConst36.z ) ), 1.0 );
	SpecularColor = vec3<f32>( 0.04, 0.04, 0.04 );
	SpecularColorBlended = mix( vec3<f32>( 0.04, 0.04, 0.04 ), DiffuseColor.xyz, Metalness );
	SpecularF90 = 1.0;
	DiffuseContribution = ( DiffuseColor.xyz * vec3<f32>( ( 1.0 - nodeConst35 ) ) );
	EmissiveColor = ( object.nodeUniform23 * vec3<f32>( object.nodeUniform24 ) );
	Output = max( vec4<f32>( ( vec3<f32>( 0.0, 0.0, 0.0 ) + EmissiveColor ), DiffuseColor.w ), vec4<f32>( 0.0 ) );
	normalView = nodeVar50.normal;
	output.m0 = vec4<f32>( normalView, 1.0 );
	let nodeConst37 = ( - v_positionView.z );
	output.m1 = vec4<f32>( nodeConst37 );
	modelViewMatrix = ( render.cameraViewMatrix * object.nodeUniform26 );
	let nodeConst38 = ( ( render.nodeUniform25 * modelViewMatrix ) * vec4<f32>( positionLocal, 1.0 ) );
	let nodeConst39 = ( ( render.nodeUniform27 * ( render.nodeUniform28 * object.nodeUniform29 ) ) * vec4<f32>( positionPrevious, 1.0 ) );
	let nodeConst40 = ( ( nodeConst38.xy / vec2<f32>( nodeConst38.w ) ) - ( nodeConst39.xy / vec2<f32>( nodeConst39.w ) ) );
	output.m2 = vec4<f32>( vec3<f32>( nodeConst40, 0.0 ), 1.0 );

	// result

	return output;

}
