// Three.js r187dev - Node System

// directives


// structs


// uniforms

struct renderStruct {
	nodeUniform96 : vec3<f32>,
	nodeUniform97 : vec3<f32>,
	nodeUniform98 : vec3<f32>,
	nodeUniform91 : f32,
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	cameraWorldMatrix : mat4x4<f32>,
	clusteredCameraNear : f32,
	clusteredCameraFar : f32,
	clusteredCameraViewMatrix : mat4x4<f32>,
	nodeUniform20 : vec2<f32>,
	cameraPosition : vec3<f32>,
	nodeUniform28 : vec3<f32>,
	nodeUniform70 : vec3<f32>,
	nodeUniform80 : f32,
	nodeUniform81 : f32,
	nodeUniform84 : f32,
	nodeUniform85 : f32,
	nodeUniform72 : vec3<f32>,
	shadowFar : f32,
	nodeUniform30 : f32,
	nodeUniform32 : mat4x4<f32>,
	nodeUniform33 : f32,
	nodeUniform34 : f32,
	nodeUniform35 : f32,
	nodeUniform36 : f32,
	nodeUniform37 : vec2<f32>,
	nodeUniform38 : f32,
	nodeUniform39 : f32,
	nodeUniform41 : f32,
	nodeUniform42 : vec2<f32>,
	nodeUniform43 : f32,
	nodeUniform44 : mat4x4<f32>,
	nodeUniform45 : f32,
	nodeUniform46 : f32,
	nodeUniform47 : f32,
	nodeUniform48 : f32,
	nodeUniform49 : vec2<f32>,
	nodeUniform50 : f32,
	nodeUniform51 : f32,
	nodeUniform53 : f32,
	nodeUniform54 : vec2<f32>,
	nodeUniform55 : f32,
	nodeUniform56 : mat4x4<f32>,
	nodeUniform57 : f32,
	nodeUniform58 : f32,
	nodeUniform59 : f32,
	nodeUniform60 : f32,
	nodeUniform61 : vec2<f32>,
	nodeUniform62 : f32,
	nodeUniform63 : f32,
	nodeUniform65 : f32,
	nodeUniform66 : vec2<f32>,
	nodeUniform67 : f32,
	nodeUniform71 : vec3<f32>,
	nodeUniform73 : mat4x4<f32>,
	nodeUniform74 : f32,
	nodeUniform75 : f32,
	nodeUniform77 : f32,
	nodeUniform78 : vec2<f32>,
	nodeUniform79 : f32
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

struct objectStruct {
	nodeUniform1 : mat3x3<f32>,
	nodeUniform2 : mat4x4<f32>,
	nodeUniform3 : f32,
	nodeUniform4 : f32,
	nodeUniform9 : f32,
	nodeUniform13 : vec4<f32>,
	nodeUniform14 : f32,
	nodeUniform15 : vec3<f32>,
	nodeUniform17 : f32,
	nodeUniform19 : mat3x3<f32>,
	nodeUniform21 : f32,
	nodeUniform22 : f32,
	nodeUniform23 : vec3<f32>,
	nodeUniform24 : f32,
	nodeUniform87 : mat4x4<f32>,
	nodeUniform89 : f32,
	nodeUniform90 : f32,
	nodeUniform92 : i32,
	nodeUniform94 : vec4<f32>,
	nodeUniform100 : vec2<f32>
};
@binding( 0 ) @group( 2 )
var<uniform> object : objectStruct;

// varyings

struct VaryingsStruct {
	@location( 0 ) v_positionView : vec3<f32>,
	@location( 1 ) v_normalWorldGeometry : vec3<f32>,
	@location( 2 ) v_normalViewGeometry : vec3<f32>,
	@location( 3 ) v_positionWorld : vec3<f32>,
	@location( 4 ) v_positionViewDirection : vec3<f32>,
	@location( 5 ) nodeVarying8 : vec4<f32>,
	@builtin( position ) builtinClipSpace : vec4<f32>
};
var<private> varyings : VaryingsStruct;

// vars
var<private> normalLocal : vec3<f32>;
var<private> normalViewGeometry : vec3<f32>;
var<private> modelViewMatrix : mat4x4<f32>;
var<private> v_modelViewProjection : vec4<f32>;
var<private> positionLocal : vec3<f32>;
var<private> VERTEX_v_modelViewProjection : vec4<f32>;

// codes


@vertex
fn main( @location( 0 ) normal : vec3<f32>,
	@location( 1 ) position : vec3<f32>,
	@location( 2 ) color : vec3<f32> ) -> VaryingsStruct {

	// flow
	// code

	normalLocal = normal;
	let nodeConst0 = normalize( ( render.cameraViewMatrix * vec4<f32>( ( object.nodeUniform1 * normalLocal ), 0.0 ) ).xyz );
	varyings.v_normalViewGeometry = nodeConst0;
	normalViewGeometry = normalize( varyings.v_normalViewGeometry );
	varyings.v_normalWorldGeometry = normalize( ( vec4<f32>( normalViewGeometry, 0.0 ) * render.cameraViewMatrix ).xyz );
	positionLocal = position;
	varyings.v_positionWorld = ( object.nodeUniform2 * vec4<f32>( positionLocal, 1.0 ) ).xyz;
	varyings.nodeVarying8 = vec4<f32>( color, 1.0 );
	modelViewMatrix = ( render.cameraViewMatrix * object.nodeUniform2 );
	varyings.v_positionView = ( modelViewMatrix * vec4<f32>( positionLocal, 1.0 ) ).xyz;
	varyings.v_positionViewDirection = ( - varyings.v_positionView );
	let VERTEX_nodeConst150 = ( render.cameraProjectionMatrix * vec4<f32>( varyings.v_positionView, 1.0 ) );
	VERTEX_v_modelViewProjection = VERTEX_nodeConst150;

	// result

	varyings.builtinClipSpace = VERTEX_v_modelViewProjection;

	return varyings;

}
