// Three.js r187dev - Node System

// global
diagnostic( off, derivative_uniformity );


// directives


// structs

struct StructType0 {
	color : vec3<f32>,
	opacity : f32,
	normal : vec3<f32>,
	rough : f32,
	metal : f32,
	ao : f32
};

struct OutputStruct {
	@location( 0 ) color: vec4<f32>
};
var<private> output : OutputStruct;

// uniforms
@binding( 1 ) @group( 2 ) var nodeUniform6_sampler : sampler;
@binding( 2 ) @group( 2 ) var nodeUniform6 : texture_2d<f32>;
@binding( 3 ) @group( 2 ) var nodeUniform7_sampler : sampler;
@binding( 4 ) @group( 2 ) var nodeUniform7 : texture_2d<f32>;
@binding( 5 ) @group( 2 ) var nodeUniform8_sampler : sampler;
@binding( 6 ) @group( 2 ) var nodeUniform8 : texture_2d<f32>;
@binding( 7 ) @group( 2 ) var nodeUniform10_sampler : sampler;
@binding( 8 ) @group( 2 ) var nodeUniform10 : texture_2d<f32>;
@binding( 9 ) @group( 2 ) var nodeUniform11_sampler : sampler;
@binding( 10 ) @group( 2 ) var nodeUniform11 : texture_2d<f32>;
@binding( 11 ) @group( 2 ) var nodeUniform12_sampler : sampler;
@binding( 12 ) @group( 2 ) var nodeUniform12 : texture_2d<f32>;
@binding( 13 ) @group( 2 ) var nodeUniform18_sampler : sampler;
@binding( 14 ) @group( 2 ) var nodeUniform18 : texture_2d<f32>;
@binding( 15 ) @group( 2 ) var nodeUniform25_sampler : sampler;
@binding( 16 ) @group( 2 ) var nodeUniform25 : texture_2d<f32>;
@binding( 17 ) @group( 2 ) var nodeUniform40_sampler : sampler_comparison;
@binding( 18 ) @group( 2 ) var nodeUniform40 : texture_depth_2d;
@binding( 19 ) @group( 2 ) var nodeUniform52_sampler : sampler_comparison;
@binding( 20 ) @group( 2 ) var nodeUniform52 : texture_depth_2d;
@binding( 21 ) @group( 2 ) var nodeUniform64_sampler : sampler_comparison;
@binding( 22 ) @group( 2 ) var nodeUniform64 : texture_depth_2d;
@binding( 23 ) @group( 2 ) var nodeUniform76_sampler : sampler_comparison;
@binding( 24 ) @group( 2 ) var nodeUniform76 : texture_depth_2d;
@binding( 25 ) @group( 2 ) var nodeUniform86_sampler : sampler;
@binding( 26 ) @group( 2 ) var nodeUniform86 : texture_cube<f32>;
@binding( 28 ) @group( 2 ) var nodeUniform104 : texture_2d<f32>;

struct cascadesStruct {
	value : array< vec4<f32>, 3 >
};
@binding( 1 ) @group( 0 )
var<uniform> cascades : cascadesStruct;

struct nodeUniform93Struct {
	value : array< vec4<f32>, 10 >
};
@binding( 0 ) @group( 3 )
var<uniform> nodeUniform93 : nodeUniform93Struct;

struct nodeUniform95Struct {
	value : array< vec4<f32>, 10 >
};
@binding( 1 ) @group( 3 )
var<uniform> nodeUniform95 : nodeUniform95Struct;

struct lightIndexesStruct {
	value : array< vec4<i32> >
};
@binding( 27 ) @group( 2 )
var<storage, read> lightIndexes : lightIndexesStruct;

struct objectStruct {
	nodeUniform1 : mat3x3<f32>,
	nodeUniform2 : mat4x4<f32>,
	nodeUniform3 : f32,
	nodeUniform4 : f32,
	nodeUniform9 : f32,
	nodeUniform13 : vec4<f32>,
	nodeUniform14 : f32,
	nodeUniform15 : vec3<f32>,
	nodeUniform17 : f32,
	nodeUniform19 : mat3x3<f32>,
	nodeUniform21 : f32,
	nodeUniform22 : f32,
	nodeUniform23 : vec3<f32>,
	nodeUniform24 : f32,
	nodeUniform87 : mat4x4<f32>,
	nodeUniform89 : f32,
	nodeUniform90 : f32,
	nodeUniform92 : i32,
	nodeUniform94 : vec4<f32>,
	nodeUniform100 : vec2<f32>
};
@binding( 0 ) @group( 2 )
var<uniform> object : objectStruct;

struct renderStruct {
	nodeUniform96 : vec3<f32>,
	nodeUniform97 : vec3<f32>,
	nodeUniform98 : vec3<f32>,
	nodeUniform91 : f32,
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	cameraWorldMatrix : mat4x4<f32>,
	clusteredCameraNear : f32,
	clusteredCameraFar : f32,
	clusteredCameraViewMatrix : mat4x4<f32>,
	nodeUniform20 : vec2<f32>,
	cameraPosition : vec3<f32>,
	nodeUniform28 : vec3<f32>,
	nodeUniform70 : vec3<f32>,
	nodeUniform80 : f32,
	nodeUniform81 : f32,
	nodeUniform84 : f32,
	nodeUniform85 : f32,
	nodeUniform72 : vec3<f32>,
	shadowFar : f32,
	nodeUniform30 : f32,
	nodeUniform32 : mat4x4<f32>,
	nodeUniform33 : f32,
	nodeUniform34 : f32,
	nodeUniform35 : f32,
	nodeUniform36 : f32,
	nodeUniform37 : vec2<f32>,
	nodeUniform38 : f32,
	nodeUniform39 : f32,
	nodeUniform41 : f32,
	nodeUniform42 : vec2<f32>,
	nodeUniform43 : f32,
	nodeUniform44 : mat4x4<f32>,
	nodeUniform45 : f32,
	nodeUniform46 : f32,
	nodeUniform47 : f32,
	nodeUniform48 : f32,
	nodeUniform49 : vec2<f32>,
	nodeUniform50 : f32,
	nodeUniform51 : f32,
	nodeUniform53 : f32,
	nodeUniform54 : vec2<f32>,
	nodeUniform55 : f32,
	nodeUniform56 : mat4x4<f32>,
	nodeUniform57 : f32,
	nodeUniform58 : f32,
	nodeUniform59 : f32,
	nodeUniform60 : f32,
	nodeUniform61 : vec2<f32>,
	nodeUniform62 : f32,
	nodeUniform63 : f32,
	nodeUniform65 : f32,
	nodeUniform66 : vec2<f32>,
	nodeUniform67 : f32,
	nodeUniform71 : vec3<f32>,
	nodeUniform73 : mat4x4<f32>,
	nodeUniform74 : f32,
	nodeUniform75 : f32,
	nodeUniform77 : f32,
	nodeUniform78 : vec2<f32>,
	nodeUniform79 : f32
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

struct owLightPositionsStruct {
	nodeUniform26 : vec3<f32>,
	nodeUniform27 : vec3<f32>,
	nodeUniform68 : vec3<f32>,
	nodeUniform69 : vec3<f32>,
	nodeUniform82 : vec3<f32>,
	nodeUniform83 : vec3<f32>
};
@binding( 0 ) @group( 1 )
var<uniform> owLightPositions : owLightPositionsStruct;

// vars
var<private> DiffuseColor : vec4<f32>;
var<private> nodeVar0 : vec3<f32>;
var<private> nodeVar1 : f32;
var<private> nodeVar2 : vec3<f32>;
var<private> normalWorldGeometry : vec3<f32>;
var<private> nodeVar3 : f32;
var<private> nodeVar4 : vec3<f32>;
var<private> nodeVar5 : vec3<f32>;
var<private> nodeVar6 : vec3<f32>;
var<private> nodeVar7 : vec2<f32>;
var<private> nodeVar8 : vec2<f32>;
var<private> nodeVar9 : vec2<f32>;
var<private> nodeVar10 : vec2<f32>;
var<private> nodeVar11 : vec2<f32>;
var<private> nodeVar12 : f32;
var<private> nodeVar13 : f32;
var<private> nodeVar14 : vec2<f32>;
var<private> nodeVar15 : f32;
var<private> nodeVar16 : vec4<f32>;
var<private> nodeVar17 : f32;
var<private> nodeVar18 : vec4<f32>;
var<private> nodeVar19 : vec4<f32>;
var<private> nodeVar20 : vec4<f32>;
var<private> nodeVar21 : vec4<f32>;
var<private> nodeVar22 : vec4<f32>;
var<private> nodeVar23 : vec3<f32>;
var<private> nodeVar24 : vec4<f32>;
var<private> nodeVar25 : vec3<f32>;
var<private> nodeVar26 : vec4<f32>;
var<private> nodeVar27 : f32;
var<private> nodeVar28 : vec4<f32>;
var<private> nodeVar29 : f32;
var<private> nodeVar30 : vec4<f32>;
var<private> nodeVar31 : vec4<f32>;
var<private> nodeVar32 : vec3<f32>;
var<private> nodeVar33 : vec4<f32>;
var<private> nodeVar34 : vec3<f32>;
var<private> nodeVar35 : f32;
var<private> nodeVar36 : vec4<f32>;
var<private> nodeVar37 : vec2<f32>;
var<private> nodeVar38 : vec4<f32>;
var<private> nodeVar39 : vec4<f32>;
var<private> nodeVar40 : vec3<f32>;
var<private> nodeVar41 : vec4<f32>;
var<private> nodeVar42 : vec4<f32>;
var<private> nodeVar43 : vec3<f32>;
var<private> nodeVar44 : vec3<f32>;
var<private> nodeVar45 : f32;
var<private> nodeVar46 : vec3<f32>;
var<private> nodeVar47 : f32;
var<private> nodeVar48 : f32;
var<private> nodeVar49 : f32;
var<private> nodeVar50 : f32;
var<private> nodeVar51 : vec3<f32>;
var<private> nodeVar52 : vec3<f32>;
var<private> nodeVar53 : vec3<f32>;
var<private> nodeVar54 : vec3<f32>;
var<private> nodeVar55 : vec3<f32>;
var<private> nodeVar56 : f32;
var<private> nodeVar57 : f32;
var<private> nodeVar58 : vec4<f32>;
var<private> nodeVar59 : vec4<f32>;
var<private> nodeVar60 : f32;
var<private> nodeVar61 : vec3<f32>;
var<private> nodeVar62 : vec3<f32>;
var<private> nodeVar63 : vec3<f32>;
var<private> nodeVar64 : vec3<f32>;
var<private> nodeVar65 : vec3<f32>;
var<private> nodeVar66 : vec3<f32>;
var<private> nodeVar67 : vec3<f32>;
var<private> nodeVar68 : StructType0;
var<private> AmbientOcclusion : f32;
var<private> nodeVar69 : f32;
var<private> Metalness : f32;
var<private> Roughness : f32;
var<private> normalViewGeometry : vec3<f32>;
var<private> SpecularColor : vec3<f32>;
var<private> SpecularColorBlended : vec3<f32>;
var<private> SpecularF90 : f32;
var<private> DiffuseContribution : vec3<f32>;
var<private> EmissiveColor : vec3<f32>;
var<private> Output : vec4<f32>;
var<private> normalView : vec3<f32>;
var<private> positionViewDirection : vec3<f32>;
var<private> nodeVar70 : vec2<f32>;
var<private> singleScatteringDielectric : vec3<f32>;
var<private> multiScatteringDielectric : vec3<f32>;
var<private> directDiffuse : vec3<f32>;
var<private> directSpecular : vec3<f32>;
var<private> shadowPositionWorld : vec3<f32>;
var<private> shadowValue : vec4<f32>;
var<private> cascade : vec2<f32>;
var<private> linearDepth : f32;
var<private> nodeVar71 : f32;
var<private> normalWorld : vec3<f32>;
var<private> nodeVar72 : f32;
var<private> nodeVar73 : f32;
var<private> nodeVar74 : f32;
var<private> nodeVar75 : f32;
var<private> nodeVar76 : f32;
var<private> nodeVar77 : f32;
var<private> nodeVar78 : f32;
var<private> nodeVar79 : f32;
var<private> nodeVar80 : f32;
var<private> nodeVar81 : f32;
var<private> nodeVar82 : f32;
var<private> nodeVar83 : f32;
var<private> nodeVar84 : f32;
var<private> nodeVar85 : f32;
var<private> nodeVar86 : f32;
var<private> nodeVar87 : f32;
var<private> nodeVar88 : f32;
var<private> nodeVar89 : f32;
var<private> nodeVar90 : f32;
var<private> nodeVar91 : f32;
var<private> nodeVar92 : f32;
var<private> nodeVar93 : f32;
var<private> nodeVar94 : f32;
var<private> nodeVar95 : vec4<f32>;
var<private> nodeVar96 : vec3<f32>;
var<private> nodeVar97 : f32;
var<private> nodeVar98 : f32;
var<private> nodeVar99 : f32;
var<private> nodeVar100 : f32;
var<private> nodeVar101 : f32;
var<private> nodeVar102 : f32;
var<private> nodeVar103 : f32;
var<private> nodeVar104 : vec3<f32>;
var<private> radiance : vec3<f32>;
var<private> nodeVar105 : vec4<f32>;
var<private> iblIrradiance : vec3<f32>;
var<private> nodeVar106 : vec4<f32>;
var<private> nodeVar107 : f32;
var<private> ambientOcclusion : f32;
var<private> irradiance : vec3<f32>;
var<private> nodeVar108 : i32;
var<private> nodeVar109 : vec4<f32>;
var<private> nodeVar110 : vec4<f32>;
var<private> nodeVar111 : f32;
var<private> nodeVar112 : vec4<f32>;
var<private> nodeVar113 : vec3<f32>;
var<private> nodeVar114 : vec3<f32>;
var<private> indirectDiffuse : vec3<f32>;
var<private> singleScatteringMetallic : vec3<f32>;
var<private> multiScatteringMetallic : vec3<f32>;
var<private> nodeVar115 : vec3<f32>;
var<private> nodeVar116 : vec3<f32>;
var<private> indirectSpecular : vec3<f32>;
var<private> totalDiffuse : vec3<f32>;
var<private> totalSpecular : vec3<f32>;
var<private> outgoingLight : vec3<f32>;
var<private> nodeVar117 : f32;
var<private> nodeVar118 : f32;
var<private> nodeVar119 : f32;

// codes
fn fn28 ( position : vec2<f32> ) -> f32 {

	


	return fract( ( 52.9829189 * fract( dot( position, vec2<f32>( 0.06711056, 0.00583715 ) ) ) ) );

}


fn fn29 ( sampleIndex : i32, samplesCount : i32, phi : f32 ) -> vec2<f32> {

	

	let nodeConst0 = ( ( f32( sampleIndex ) * 2.399963229728653 ) + phi );

	return ( vec2<f32>( cos( nodeConst0 ), sin( nodeConst0 ) ) * vec2<f32>( sqrt( ( ( f32( sampleIndex ) + 0.5 ) / f32( samplesCount ) ) ) ) );

}


fn fn10 ( alpha : f32, dotNL : f32, dotNV : f32 ) -> f32 {

	

	let nodeConst0 = ( alpha * alpha );

	return ( 0.5 / max( ( ( dotNL * sqrt( ( nodeConst0 + ( ( 1.0 - nodeConst0 ) * ( dotNV * dotNV ) ) ) ) ) + ( dotNV * sqrt( ( nodeConst0 + ( ( 1.0 - nodeConst0 ) * ( dotNL * dotNL ) ) ) ) ) ), 0.000001 ) );

}


fn fn12 ( alpha : f32, dotNH : f32 ) -> f32 {

	

	let nodeConst0 = ( alpha * alpha );
	let nodeConst1 = ( 1.0 - ( ( dotNH * dotNH ) * ( 1.0 - nodeConst0 ) ) );

	return ( ( nodeConst0 / ( nodeConst1 * nodeConst1 ) ) * 0.3183098861837907 );

}


fn fn38 ( lightDistance : f32, cutoffDistance : f32, decayExponent : f32 ) -> f32 {

	var nodeVar0 : f32;


	if ( ( cutoffDistance > 0.0 ) ) {

		let nodeConst0 = ( 1.0 / max( pow( lightDistance, decayExponent ), 0.01 ) );
		let nodeConst1 = ( lightDistance / cutoffDistance );
		let nodeConst2 = clamp( ( 1.0 - ( ( ( nodeConst1 * nodeConst1 ) * nodeConst1 ) * nodeConst1 ) ), 0.0, 1.0 );
		nodeVar0 = ( nodeConst0 * ( nodeConst2 * nodeConst2 ) );

	} else {

		let nodeConst0 = ( 1.0 / max( pow( lightDistance, decayExponent ), 0.01 ) );
		nodeVar0 = nodeConst0;

	}


	return nodeVar0;

}




@fragment
fn main( @location( 0 ) v_positionView : vec3<f32>,
	@location( 1 ) v_normalWorldGeometry : vec3<f32>,
	@location( 2 ) v_normalViewGeometry : vec3<f32>,
	@location( 3 ) v_positionWorld : vec3<f32>,
	@location( 4 ) v_positionViewDirection : vec3<f32>,
	@location( 5 ) nodeVarying8 : vec4<f32>,
	@builtin( front_facing ) isFront : bool,
	@builtin( position ) fragCoord : vec4<f32> ) -> OutputStruct {

	// flow
	// code


	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = ( - nodeConst1 );

	}

	let nodeConst2 = pow( abs( nodeVar2 ), vec3<f32>( 5.0, 5.0, 5.0 ) );
	let nodeConst3 = ( nodeConst2 / vec3<f32>( max( ( ( nodeConst2.x + nodeConst2.y ) + nodeConst2.z ), 0.0001 ) ) );

	if ( ( ( nodeConst3.x > nodeConst3.y ) && ( nodeConst3.x > nodeConst3.z ) ) ) {

		nodeVar1 = 0.0;

	} else {


		if ( ( nodeConst3.y > nodeConst3.z ) ) {

			nodeVar3 = 1.0;

		} else {

			nodeVar3 = 2.0;

		}

		nodeVar1 = nodeVar3;

	}


	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar0 = vec3<f32>( 0.0, 0.0, ( - nodeConst4 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar4 = vec3<f32>( 1.0, 0.0, 0.0 );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar4 = vec3<f32>( nodeConst5, 0.0, 0.0 );

		}

		nodeVar0 = nodeVar4;

	}

	nodeVar5 = normalize( ( nodeVar0 - ( nodeVar2 * vec3<f32>( dot( nodeVar0, nodeVar2 ) ) ) ) );
	nodeVar6 = cross( nodeVar2, nodeVar5 );

	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar7 = ( ( vec2<f32>( ( ( - v_positionWorld.z ) * nodeConst4 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform3 ) ) + vec2<f32>( 0.0, 0.0 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar8 = ( ( vec2<f32>( v_positionWorld.x, ( ( - v_positionWorld.z ) * ( ( step( 0.0, nodeVar2.y ) * 2.0 ) - 1.0 ) ) ) * vec2<f32>( object.nodeUniform3 ) ) + vec2<f32>( 0.0, 0.0 ) );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar8 = ( ( vec2<f32>( ( v_positionWorld.x * nodeConst5 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform3 ) ) + vec2<f32>( 0.0, 0.0 ) );

		}

		nodeVar7 = nodeVar8;

	}

	nodeVar9 = nodeVar7;
	nodeVar10 = dpdx( nodeVar7 );
	nodeVar11 = - dpdy( nodeVar7 );
	let nodeConst6 = ( object.nodeUniform4 * object.nodeUniform3 );
	let nodeConst7 = length( ( render.cameraPosition - v_positionWorld ) );
	let nodeConst8 = ( 1.0 - smoothstep( 6.0, 14.0, nodeConst7 ) );

	if ( ( ( nodeConst6 > 0.0 ) && ( nodeConst8 > 0.001 ) ) ) {

		let nodeConst9 = normalize( ( render.cameraPosition - v_positionWorld ) );
		let nodeConst10 = normalize( vec3<f32>( dot( nodeConst9, nodeVar5 ), dot( nodeConst9, nodeVar6 ), dot( nodeConst9, nodeVar2 ) ) );
		nodeVar12 = max( ( mix( 16.0, 8.0, clamp( abs( nodeConst10.z ), 0.0, 1.0 ) ) * nodeConst8 ), 4.0 );
		nodeVar13 = ( 1.0 / nodeVar12 );
		nodeVar14 = ( ( ( ( nodeConst10.xy / vec2<f32>( max( abs( nodeConst10.z ), 0.3 ) ) ) * vec2<f32>( nodeConst6 ) ) * vec2<f32>( nodeConst8 ) ) * vec2<f32>( nodeVar13 ) );
		nodeVar15 = 0.0;
		nodeVar16 = textureSampleGrad( nodeUniform6, nodeUniform6_sampler, nodeVar9, nodeVar10, nodeVar11 );
		nodeVar17 = ( 1.0 - nodeVar16.w );

		for ( var i : i32 = 0; i < 48; i ++ ) {


			if ( ( ( nodeVar15 >= nodeVar17 ) || ( f32( i ) >= nodeVar12 ) ) ) {

				break;
				

			}

			nodeVar9 = ( nodeVar9 - nodeVar14 );
			nodeVar18 = textureSampleGrad( nodeUniform6, nodeUniform6_sampler, nodeVar9, nodeVar10, nodeVar11 );
			nodeVar17 = ( 1.0 - nodeVar18.w );
			nodeVar15 = ( nodeVar15 + nodeVar13 );

		}

		let nodeConst11 = ( nodeVar9 + nodeVar14 );
		let nodeConst12 = ( nodeVar17 - nodeVar15 );
		nodeVar19 = textureSampleGrad( nodeUniform6, nodeUniform6_sampler, nodeConst11, nodeVar10, nodeVar11 );
		nodeVar9 = mix( nodeVar9, nodeConst11, clamp( ( ( - nodeConst12 ) / max( ( ( ( ( 1.0 - nodeVar19.w ) - nodeVar15 ) + nodeVar13 ) - nodeConst12 ), 0.0001 ) ), 0.0, 1.0 ) );
		

	}

	nodeVar20 = textureSample( nodeUniform6, nodeUniform6_sampler, nodeVar9 );
	nodeVar21 = nodeVar20;
	nodeVar22 = textureSample( nodeUniform7, nodeUniform7_sampler, nodeVar9 );
	nodeVar23 = nodeVar22.xyz;
	nodeVar24 = textureSample( nodeUniform8, nodeUniform8_sampler, nodeVar9 );
	nodeVar25 = normalize( vec3<f32>( ( ( ( nodeVar24.x * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( ( nodeVar24.y * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( nodeVar24.z * 2.0 ) - 1.0 ) ) );
	nodeVar26 = textureSample( nodeUniform10, nodeUniform10_sampler, ( ( ( v_positionWorld.xz + vec2<f32>( ( v_positionWorld.y * 0.7 ) ) ) * vec2<f32>( 0.42500000000000004 ) ) + vec2<f32>( 0.21 ) ) );
	let nodeConst13 = ( clamp( ( ( nodeVar26.y - 0.36 ) * 2.4 ), 0.0, 1.0 ) * 0.8 );
	nodeVar27 = ( ( 1.0 - nodeConst13 ) + ( nodeVar21.w * 0.6 ) );
	let nodeConst14 = ( ( vec2<f32>( ( ( nodeVar9.x * 0.803 ) - ( nodeVar9.y * 0.596 ) ), ( ( nodeVar9.x * 0.596 ) + ( nodeVar9.y * 0.803 ) ) ) * vec2<f32>( 0.617 ) ) + vec2<f32>( 0.37, 0.71 ) );
	nodeVar28 = textureSample( nodeUniform6, nodeUniform6_sampler, nodeConst14 );
	nodeVar29 = ( nodeConst13 + ( nodeVar28.w * 0.6 ) );
	let nodeConst15 = ( max( nodeVar27, nodeVar29 ) - 0.18 );
	nodeVar27 = max( ( nodeVar27 - nodeConst15 ), 0.0 );
	nodeVar29 = max( ( nodeVar29 - nodeConst15 ), 0.0 );
	let nodeConst16 = ( 1.0 / max( ( nodeVar27 + nodeVar29 ), 0.0001 ) );
	nodeVar21 = ( ( ( nodeVar21 * vec4<f32>( nodeVar27 ) ) + ( nodeVar28 * vec4<f32>( nodeVar29 ) ) ) * vec4<f32>( nodeConst16 ) );
	nodeVar30 = textureSample( nodeUniform7, nodeUniform7_sampler, nodeConst14 );
	nodeVar23 = ( ( ( nodeVar23 * vec3<f32>( nodeVar27 ) ) + ( nodeVar30.xyz * vec3<f32>( nodeVar29 ) ) ) * vec3<f32>( nodeConst16 ) );
	nodeVar31 = textureSample( nodeUniform8, nodeUniform8_sampler, nodeConst14 );
	nodeVar25 = normalize( ( ( nodeVar25 * vec3<f32>( nodeVar27 ) ) + ( normalize( vec3<f32>( ( ( ( nodeVar31.x * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( ( nodeVar31.y * 2.0 ) - 1.0 ) * object.nodeUniform9 ), ( ( nodeVar31.z * 2.0 ) - 1.0 ) ) ) * vec3<f32>( nodeVar29 ) ) ) );
	nodeVar32 = ( ( ( nodeVar5 * vec3<f32>( nodeVar25.x ) ) + ( nodeVar6 * vec3<f32>( nodeVar25.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeVar25.z ) ) );
	let nodeConst17 = ( nodeVar9 * vec2<f32>( 8.461538461538462 ) );
	nodeVar33 = textureSample( nodeUniform11, nodeUniform11_sampler, nodeConst17 );
	let nodeConst18 = ( ( nodeVar33.w - 0.5 ) * 2.0 );
	let nodeConst19 = ( 1.0 - smoothstep( 10.8, 24.0, nodeConst7 ) );
	nodeVar34 = ( nodeVar21.xyz * vec3<f32>( ( 1.0 + ( ( ( ( nodeConst18 * 0.95 ) + ( ( nodeVar33.x - 0.5 ) * 1.25 ) ) * 0.54 ) * nodeConst19 ) ) ) );
	nodeVar21.x = nodeVar34[ 0 ];
	nodeVar21.y = nodeVar34[ 1 ];
	nodeVar21.z = nodeVar34[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( max( ( - nodeConst18 ), 0.0 ) * 0.162 ) * nodeConst19 ) ) );
	nodeVar35 = clamp( ( nodeVar21.w + ( ( nodeConst18 * 0.16 ) * nodeConst19 ) ), 0.0, 1.0 );
	nodeVar36 = textureSample( nodeUniform12, nodeUniform12_sampler, nodeConst17 );
	let nodeConst20 = ( ( nodeVar36.xyz * vec3<f32>( 2.0 ) ) - vec3<f32>( 1.0 ) );
	let nodeConst21 = ( ( ( nodeVar5 * vec3<f32>( nodeConst20.x ) ) + ( nodeVar6 * vec3<f32>( nodeConst20.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeConst20.z ) ) );
	nodeVar32 = normalize( ( nodeVar32 + ( ( ( nodeConst21 - ( nodeVar2 * vec3<f32>( dot( nodeConst21, nodeVar2 ) ) ) ) * vec3<f32>( 0.95 ) ) * vec3<f32>( nodeConst19 ) ) ) );

	if ( ( step( 0.62, abs( nodeVar2.y ) ) > 0.5 ) ) {

		nodeVar37 = v_positionWorld.xz;

	} else {

		nodeVar37 = vec2<f32>( ( v_positionWorld.x + ( v_positionWorld.z * 0.63 ) ), v_positionWorld.y );

	}

	nodeVar38 = textureSample( nodeUniform10, nodeUniform10_sampler, ( nodeVar37 * vec2<f32>( 0.085 ) ) );
	nodeVar39 = textureSample( nodeUniform10, nodeUniform10_sampler, ( ( nodeVar37 * vec2<f32>( 0.017935 ) ) + vec2<f32>( 0.37 ) ) );
	nodeVar40 = ( nodeVar21.xyz * vec3<f32>( mix( 1.0, ( ( clamp( ( ( ( ( ( nodeVar38.x * 0.55 ) + ( nodeVar39.z * 0.45 ) ) - 0.5 ) * 2.15 ) + 0.5 ), 0.0, 1.0 ) * 0.92 ) + 0.55 ), 0.72 ) ) );
	nodeVar21.x = nodeVar40[ 0 ];
	nodeVar21.y = nodeVar40[ 1 ];
	nodeVar21.z = nodeVar40[ 2 ];
	let nodeConst22 = ( nodeVar37 * vec2<f32>( 0.026 ) );
	nodeVar41 = textureSample( nodeUniform10, nodeUniform10_sampler, nodeConst22 );
	nodeVar42 = textureSample( nodeUniform10, nodeUniform10_sampler, ( ( nodeConst22 * vec2<f32>( 0.37 ) ) + vec2<f32>( 0.61 ) ) );
	let nodeConst23 = clamp( ( ( ( ( nodeVar41.x * 0.62 ) + ( nodeVar42.z * 0.38 ) ) - 0.5 ) * 2.3 ), -1.0, 1.0 );
	nodeVar43 = ( nodeVar21.xyz * vec3<f32>( ( ( nodeConst23 * 0.15 ) + 1.0 ) ) );
	nodeVar21.x = nodeVar43[ 0 ];
	nodeVar21.y = nodeVar43[ 1 ];
	nodeVar21.z = nodeVar43[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y - ( nodeConst23 * 0.0825 ) ), 0.0, 1.0 );
	nodeVar44 = ( nodeVar21.xyz * mix( vec3<f32>( 1.0, 1.0, 1.0 ), vec3<f32>( 1.05, 1.0, 0.93 ), ( ( nodeVar39.x - 0.5 ) * 0.5 ) ) );
	nodeVar21.x = nodeVar44[ 0 ];
	nodeVar21.y = nodeVar44[ 1 ];
	nodeVar21.z = nodeVar44[ 2 ];
	nodeVar23.y = clamp( ( ( ( nodeVar23.y + ( ( nodeVar38.y - 0.5 ) * 0.26 ) ) + ( ( nodeVar38.w - 0.5 ) * 0.16 ) ) - ( ( nodeConst18 * 0.07 ) * nodeConst19 ) ), 0.0, 1.0 );

	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar46 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar46 = ( - nodeConst1 );

	}

	let nodeConst24 = ( ( v_positionWorld.z * nodeVar46.x ) - ( v_positionWorld.x * nodeVar46.z ) );
	let nodeConst25 = ( ( vec2<f32>( nodeConst24, v_positionWorld.y ) / vec2<f32>( 2.2 ) ) + ( ( nodeVar39.xy - vec2<f32>( 0.5 ) ) * vec2<f32>( 0.35 ) ) );
	let nodeConst26 = floor( nodeConst25 );
	nodeVar47 = fract( ( ( ( ( nodeConst26.x * 5.51 ) + ( nodeConst26.y * 17.29 ) ) + 53.9 ) * 0.1031 ) );
	nodeVar47 = ( nodeVar47 * ( nodeVar47 + 33.33 ) );
	nodeVar47 = ( nodeVar47 * ( nodeVar47 + nodeVar47 ) );
	let nodeConst27 = fract( nodeVar47 );
	let nodeConst28 = ( nodeConst27 > 0.48 );

	if ( nodeConst28 ) {

		nodeVar45 = 1.0;

	} else {

		nodeVar45 = -1.0;

	}

	nodeVar48 = fract( ( ( ( ( nodeConst26.x * 3.17 ) + ( nodeConst26.y * 9.41 ) ) + 21.3 ) * 0.1031 ) );
	nodeVar48 = ( nodeVar48 * ( nodeVar48 + 33.33 ) );
	nodeVar48 = ( nodeVar48 * ( nodeVar48 + nodeVar48 ) );
	let nodeConst29 = fract( nodeVar48 );
	nodeVar49 = fract( ( ( ( ( nodeConst26.x * 11.93 ) + ( nodeConst26.y * 4.73 ) ) + 37.7 ) * 0.1031 ) );
	nodeVar49 = ( nodeVar49 * ( nodeVar49 + 33.33 ) );
	nodeVar49 = ( nodeVar49 * ( nodeVar49 + nodeVar49 ) );
	let nodeConst30 = fract( nodeVar49 );
	let nodeConst31 = vec2<f32>( ( ( nodeConst29 * 0.3 ) + 0.05 ), ( ( nodeConst30 * 0.3 ) + 0.05 ) );
	let nodeConst32 = ( ( nodeConst29 * 0.03 ) + 0.028 );
	let nodeConst33 = ( nodeConst25 - nodeConst26 );
	let nodeConst34 = smoothstep( nodeConst31, ( nodeConst31 + vec2<f32>( nodeConst32 ) ), nodeConst33 );
	let nodeConst35 = vec2<f32>( ( ( - ( nodeConst30 * 0.26 ) ) + 0.95 ), ( ( - ( nodeConst27 * 0.26 ) ) + 0.95 ) );
	let nodeConst36 = ( vec2<f32>( 1.0 ) - smoothstep( ( nodeConst35 - vec2<f32>( nodeConst32 ) ), nodeConst35, nodeConst33 ) );
	nodeVar50 = fract( ( ( ( ( nodeConst26.x * 7.31 ) + ( nodeConst26.y * 13.77 ) ) + 5.1 ) * 0.1031 ) );
	nodeVar50 = ( nodeVar50 * ( nodeVar50 + 33.33 ) );
	nodeVar50 = ( nodeVar50 * ( nodeVar50 + nodeVar50 ) );
	let nodeConst37 = ( 1.0 - smoothstep( 0.34, 0.72, abs( nodeVar46.y ) ) );
	let nodeConst38 = ( ( ( ( ( nodeConst34.x * nodeConst34.y ) * nodeConst36.x ) * nodeConst36.y ) * step( 0.6599999999999999, fract( nodeVar50 ) ) ) * nodeConst37 );
	nodeVar51 = ( nodeVar21.xyz * vec3<f32>( ( 1.0 + ( ( nodeVar45 * 0.175 ) * nodeConst38 ) ) ) );
	nodeVar21.x = nodeVar51[ 0 ];
	nodeVar21.y = nodeVar51[ 1 ];
	nodeVar21.z = nodeVar51[ 2 ];

	if ( nodeConst28 ) {

		nodeVar52 = vec3<f32>( 0.975, 0.988, 1.02 );

	} else {

		nodeVar52 = vec3<f32>( 1.03, 1.008, 0.968 );

	}

	nodeVar53 = ( nodeVar21.xyz * mix( vec3<f32>( 1.0, 1.0, 1.0 ), nodeVar52, nodeConst38 ) );
	nodeVar21.x = nodeVar53[ 0 ];
	nodeVar21.y = nodeVar53[ 1 ];
	nodeVar21.z = nodeVar53[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst38 * -0.1 ) ), 0.0, 1.0 );
	let nodeConst39 = ( ( nodeConst38 * ( 1.0 - nodeConst38 ) ) * 4.0 );
	nodeVar54 = ( nodeVar21.xyz * vec3<f32>( ( ( nodeConst39 * 0.13 ) + 1.0 ) ) );
	nodeVar21.x = nodeVar54[ 0 ];
	nodeVar21.y = nodeVar54[ 1 ];
	nodeVar21.z = nodeVar54[ 2 ];
	nodeVar35 = clamp( ( ( nodeVar35 + ( nodeConst38 * 0.07 ) ) + ( nodeConst39 * 0.05 ) ), 0.0, 1.0 );
	let nodeConst40 = ( ( pow( clamp( nodeVar46.y, 0.0, 1.0 ), 2.0 ) * object.nodeUniform13.x ) * smoothstep( 0.3, 0.8, ( ( nodeVar38.z * 0.7 ) + ( nodeVar39.y * 0.5 ) ) ) );
	nodeVar55 = mix( nodeVar21.xyz, vec3<f32>( 0.33245153633549385, 0.2541520943200296, 0.1499597898006365 ), ( nodeConst40 * 0.75 ) );
	nodeVar21.x = nodeVar55[ 0 ];
	nodeVar21.y = nodeVar55[ 1 ];
	nodeVar21.z = nodeVar55[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst40 * 0.3 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst40 * 0.85 ) ) );
	let nodeConst41 = ( nodeConst24 * 1.55 );
	let nodeConst42 = floor( nodeConst41 );
	nodeVar56 = fract( ( ( ( nodeConst42 * 2.71 ) + 11.7 ) * 0.1031 ) );
	nodeVar56 = ( nodeVar56 * ( nodeVar56 + 33.33 ) );
	nodeVar56 = ( nodeVar56 * ( nodeVar56 + nodeVar56 ) );
	let nodeConst43 = fract( nodeVar56 );
	nodeVar57 = fract( ( ( ( nodeConst42 * 1.37 ) + 3.1 ) * 0.1031 ) );
	nodeVar57 = ( nodeVar57 * ( nodeVar57 + 33.33 ) );
	nodeVar57 = ( nodeVar57 * ( nodeVar57 + nodeVar57 ) );
	let nodeConst44 = fract( nodeVar57 );
	let nodeConst45 = ( ( nodeConst43 * 1.2 ) + ( nodeConst44 * 0.5 ) );
	nodeVar58 = textureSample( nodeUniform10, nodeUniform10_sampler, vec2<f32>( ( nodeConst24 * 0.46 ), ( v_positionWorld.y * 0.155 ) ) );
	let nodeConst46 = ( ( ( ( ( floor( ( ( v_positionWorld.y + nodeConst45 ) / 2.85 ) ) + 1.0 ) * 2.85 ) - nodeConst45 ) + ( ( nodeVar58.w - 0.5 ) * 0.2 ) ) - v_positionWorld.y );
	nodeVar59 = textureSample( nodeUniform10, nodeUniform10_sampler, vec2<f32>( ( ( nodeConst24 * 1.35 ) + 0.4 ), ( v_positionWorld.y * 0.42 ) ) );
	nodeVar60 = clamp( ( ( ( nodeConst37 * clamp( ( ( smoothstep( 0.0, 0.15, nodeConst46 ) * ( 1.0 - smoothstep( 0.15, 1.65, nodeConst46 ) ) ) * ( ( ( smoothstep( 0.3, 0.62, nodeConst44 ) * ( ( nodeConst43 * 0.45 ) + 0.55 ) ) * pow( sin( ( fract( nodeConst41 ) * 3.14159265 ) ), 2.0 ) ) * ( ( nodeConst44 * 0.45 ) + 0.8 ) ) ), 0.0, 1.0 ) ) * clamp( ( object.nodeUniform13.y * 2.2 ), 0.0, 1.15 ) ) * smoothstep( 0.3, 0.66, ( ( nodeVar58.w * 0.72 ) + ( nodeVar59.y * 0.38 ) ) ) ), 0.0, 1.0 );
	nodeVar60 = clamp( ( ( nodeVar60 * ( ( clamp( ( ( nodeVarying8.y * 1.5 ) + ( nodeVarying8.z * 0.6 ) ), 0.0, 1.0 ) * 0.75 ) + 0.45 ) ) + ( ( smoothstep( 0.58, 0.98, nodeVarying8.y ) * nodeConst37 ) * ( ( smoothstep( 0.2, 0.7, ( ( nodeVar58.w * 0.6 ) + ( nodeVar59.y * 0.55 ) ) ) * 0.45 ) + 0.55 ) ) ), 0.0, 1.0 );
	nodeVar60 = ( nodeVar60 * step( 0.0001, object.nodeUniform13.y ) );
	nodeVar61 = mix( nodeVar21.xyz, mix( mix( ( nodeVar21.xyz * vec3<f32>( 0.72 ) ), vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), 0.26 ), mix( ( nodeVar21.xyz * vec3<f32>( 0.94 ) ), vec3<f32>( 0.15292615198613213, 0.04231141061442144, 0.011612245176281512 ), 0.5 ), ( clamp( ( ( step( 0.86, nodeConst43 ) * 0.9 ) + ( nodeVar23.z * 0.5 ) ), 0.0, 1.0 ) * ( ( ( 1.0 - smoothstep( 0.1, 0.9, nodeConst46 ) ) * 0.7 ) + 0.3 ) ) ), nodeVar60 );
	nodeVar21.x = nodeVar61[ 0 ];
	nodeVar21.y = nodeVar61[ 1 ];
	nodeVar21.z = nodeVar61[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeVar60 * 0.09 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeVar60 * 0.35 ) ) );
	let nodeConst47 = ( v_positionWorld.y - object.nodeUniform14 );
	let nodeConst48 = ( 1.0 - smoothstep( 0.02, 0.22, nodeConst47 ) );
	let nodeConst49 = ( ( ( nodeConst37 * max( nodeConst48, ( pow( ( 1.0 - smoothstep( 0.1, max( object.nodeUniform13.z, 0.101 ), nodeConst47 ) ), 2.0 ) * 0.85 ) ) ) * step( 0.0001, object.nodeUniform13.z ) ) * ( ( smoothstep( 0.25, 0.72, ( ( nodeVar38.z * 0.7 ) + ( nodeVar39.y * 0.4 ) ) ) * 0.45 ) + 0.55 ) );
	nodeVar62 = mix( ( nodeVar21.xyz * vec3<f32>( ( 1.0 - ( nodeConst49 * 0.35 ) ) ) ), mix( vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), ( vec3<f32>( 0.33245153633549385, 0.2541520943200296, 0.1499597898006365 ) * vec3<f32>( 0.9 ) ), 0.35 ), ( nodeConst49 * 0.42 ) );
	nodeVar21.x = nodeVar62[ 0 ];
	nodeVar21.y = nodeVar62[ 1 ];
	nodeVar21.z = nodeVar62[ 2 ];
	nodeVar23.y = clamp( ( ( nodeVar23.y + ( nodeConst49 * 0.16 ) ) - ( ( ( nodeConst48 * nodeConst37 ) * 0.1 ) * step( 0.0001, object.nodeUniform13.z ) ) ), 0.0, 1.0 );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeConst49 * 0.18 ) ) );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst49 * 0.7 ) ) );
	let nodeConst50 = ( ( ( ( nodeVar38.x * 0.6 ) + ( nodeVar39.z * 0.7 ) ) * 0.18 ) + 0.26 );
	let nodeConst51 = ( clamp( ( pow( ( nodeConst37 * ( 1.0 - smoothstep( ( nodeConst50 * 0.25 ), nodeConst50, nodeConst47 ) ) ), 2.0 ) * ( ( smoothstep( 0.2, 0.8, nodeVar39.y ) * 0.5 ) + 0.7 ) ), 0.0, 1.0 ) * step( 0.0001, object.nodeUniform13.z ) );
	nodeVar63 = mix( nodeVar21.xyz, vec3<f32>( 0.33245153633549385, 0.2541520943200296, 0.1499597898006365 ), ( nodeConst51 * 0.46 ) );
	nodeVar21.x = nodeVar63[ 0 ];
	nodeVar21.y = nodeVar63[ 1 ];
	nodeVar21.z = nodeVar63[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst51 * 0.07 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst51 * 0.9 ) ) );
	let nodeConst52 = ( 1.0 - nodeVar35 );
	nodeVar64 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), ( pow( nodeConst52, 2.0 ) * object.nodeUniform13.w ) );
	nodeVar21.x = nodeVar64[ 0 ];
	nodeVar21.y = nodeVar64[ 1 ];
	nodeVar21.z = nodeVar64[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( nodeConst52 * object.nodeUniform13.w ) * 0.5 ) ) );
	let nodeConst53 = clamp( ( ( ( nodeVarying8.x * 0.5 ) * ( ( smoothstep( 0.3, 0.8, nodeVar35 ) * 0.45 ) + 0.55 ) ) * ( ( smoothstep( 0.25, 0.85, ( ( nodeVar38.z * 0.65 ) + ( nodeVar39.w * 0.55 ) ) ) * 1.15 ) + 0.25 ) ), 0.0, 1.0 );
	nodeVar65 = mix( nodeVar21.xyz, vec3<f32>( 0.43415363616478553, 0.3813260114221238, 0.2874408377161099 ), ( nodeConst53 * 0.5 ) );
	nodeVar21.x = nodeVar65[ 0 ];
	nodeVar21.y = nodeVar65[ 1 ];
	nodeVar21.z = nodeVar65[ 2 ];
	nodeVar23.y = mix( nodeVar23.y, 0.42, nodeConst53 );
	nodeVar23.z = mix( nodeVar23.z, 0.0, nodeConst53 );
	let nodeConst54 = ( ( ( nodeVarying8.y * 0.7 ) * ( ( nodeConst52 * 0.65 ) + 0.35 ) ) * ( ( nodeVar39.y * 0.9 ) + 0.45 ) );
	nodeVar66 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.018500220124016652, 0.012286488353353374 ), ( nodeConst54 * 0.8 ) );
	nodeVar21.x = nodeVar66[ 0 ];
	nodeVar21.y = nodeVar66[ 1 ];
	nodeVar21.z = nodeVar66[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst54 * 0.22 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst54 * 0.8 ) ) );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeVarying8.z * 0.5 ) ) );
	nodeVar67 = ( nodeVar21.xyz * object.nodeUniform15 );
	nodeVar21.x = nodeVar67[ 0 ];
	nodeVar21.y = nodeVar67[ 1 ];
	nodeVar21.z = nodeVar67[ 2 ];
	nodeVar68 = StructType0( nodeVar21.xyz, nodeVar21.w, normalize( ( render.cameraViewMatrix * vec4<f32>( nodeVar32, 0.0 ) ).xyz ), clamp( ( ( nodeVar23.y * 0.97 ) + -0.02 ), 0.26, 1.0 ), clamp( nodeVar23.z, 0.0, 1.0 ), ( 1.0 + ( ( nodeVar23.x - 1.0 ) * 1.0 ) ) );
	DiffuseColor = vec4<f32>( nodeVar68.color, 1.0 );
	DiffuseColor.w = ( DiffuseColor.w * object.nodeUniform17 );
	DiffuseColor.w = 1.0;
	nodeVar69 = textureSample( nodeUniform18, nodeUniform18_sampler, ( object.nodeUniform19 * vec3<f32>( ( fragCoord.xy / render.nodeUniform20 ), 1.0 ) ).xy ).x;
	AmbientOcclusion = ( nodeVar68.ao * nodeVar69 );
	let nodeConst55 = ( nodeVar68.metal * object.nodeUniform21 );
	Metalness = nodeConst55;
	normalViewGeometry = normalize( v_normalViewGeometry );
	let nodeConst56 = max( abs( dpdx( normalViewGeometry ) ), abs( - dpdy( normalViewGeometry ) ) );
	Roughness = min( ( max( ( nodeVar68.rough * object.nodeUniform22 ), 0.045 ) + max( max( nodeConst56.x, nodeConst56.y ), nodeConst56.z ) ), 1.0 );
	SpecularColor = vec3<f32>( 0.04, 0.04, 0.04 );
	SpecularColorBlended = mix( vec3<f32>( 0.04, 0.04, 0.04 ), DiffuseColor.xyz, Metalness );
	SpecularF90 = 1.0;
	DiffuseContribution = ( DiffuseColor.xyz * vec3<f32>( ( 1.0 - nodeConst55 ) ) );
	EmissiveColor = ( object.nodeUniform23 * vec3<f32>( object.nodeUniform24 ) );
	normalView = nodeVar68.normal;
	positionViewDirection = normalize( v_positionViewDirection );
	nodeVar70 = textureSample( nodeUniform25, nodeUniform25_sampler, vec2<f32>( Roughness, clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ).xy;
	let dfg = nodeVar70;
	let multiScatteringCompensation = ( ( SpecularColorBlended * vec3<f32>( ( ( 1.0 / ( dfg.x + dfg.y ) ) - 1.0 ) ) ) + vec3<f32>( 1.0 ) );
	singleScatteringDielectric = vec3<f32>( 0.0, 0.0, 0.0 );
	multiScatteringDielectric = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst57 = ( ( SpecularColor * vec3<f32>( dfg.x ) ) + vec3<f32>( ( SpecularF90 * dfg.y ) ) );
	singleScatteringDielectric = ( singleScatteringDielectric + nodeConst57 );
	let nodeConst58 = ( SpecularColor + ( ( vec3<f32>( 1.0 ) - SpecularColor ) * vec3<f32>( 0.047619 ) ) );
	let nodeConst59 = ( 1.0 - ( dfg.x + dfg.y ) );
	multiScatteringDielectric = ( multiScatteringDielectric + ( ( ( nodeConst57 * nodeConst58 ) / ( vec3<f32>( 1.0 ) - ( vec3<f32>( nodeConst59 ) * nodeConst58 ) ) ) * vec3<f32>( nodeConst59 ) ) );
	directDiffuse = vec3<f32>( 0.0, 0.0, 0.0 );
	directSpecular = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst60 = normalize( ( render.cameraViewMatrix * vec4<f32>( ( owLightPositions.nodeUniform26 - owLightPositions.nodeUniform27 ), 0.0 ) ).xyz );
	shadowPositionWorld = v_positionWorld;
	shadowValue = vec4<f32>( 1.0, 1.0, 1.0, 1.0 );
	cascade = vec2<f32>( 0.0, 0.0 );
	cascade = cascades.value[ 0u ].xy;
	linearDepth = ( ( v_positionView.z + render.nodeUniform30 ) / ( render.nodeUniform30 - render.shadowFar ) );

	if ( ( ( linearDepth >= cascade.x ) && ( linearDepth <= cascade.y ) ) ) {

		shadowPositionWorld = v_positionWorld;
		normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
		let nodeConst61 = ( render.nodeUniform32 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform33 ) ) ), 1.0 ) );
		let nodeConst62 = ( nodeConst61.xyz / vec3<f32>( nodeConst61.w ) );
		normalWorldGeometry = normalize( v_normalWorldGeometry );
		nodeVar72 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform26 - owLightPositions.nodeUniform27 ) ) ) ), 0.12, 1.0 );
		let nodeConst63 = vec3<f32>( nodeConst62.x, ( 1.0 - nodeConst62.y ), ( nodeConst62.z + ( render.nodeUniform34 - ( ( ( ( render.nodeUniform35 - render.nodeUniform36 ) / render.nodeUniform37.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar72 * nodeVar72 ) ) ) ) / nodeVar72 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform38 - render.nodeUniform39 ), 1.0 ) ) ) ) );

		if ( ( ( ( ( ( nodeConst63.x >= 0.0 ) && ( nodeConst63.x <= 1.0 ) ) && ( nodeConst63.y >= 0.0 ) ) && ( nodeConst63.y <= 1.0 ) ) && ( nodeConst63.z <= 1.0 ) ) ) {

			let nodeConst64 = ( fn28( fragCoord.xy ) * 6.28318530718 );
			let nodeConst65 = ( render.nodeUniform41 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform42 ).x );
			let nodeConst66 = ( nodeConst63.xy + ( fn29( 0, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar73 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst66, nodeConst63.z );
			let nodeConst67 = ( nodeConst63.xy + ( fn29( 1, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar74 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst67, nodeConst63.z );
			let nodeConst68 = ( nodeConst63.xy + ( fn29( 2, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar75 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst68, nodeConst63.z );
			let nodeConst69 = ( nodeConst63.xy + ( fn29( 3, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar76 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst69, nodeConst63.z );
			let nodeConst70 = ( nodeConst63.xy + ( fn29( 4, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar77 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst70, nodeConst63.z );
			nodeVar71 = ( ( ( ( ( nodeVar73 + nodeVar74 ) + nodeVar75 ) + nodeVar76 ) + nodeVar77 ) * 0.2 );

		} else {

			nodeVar71 = 1.0;

		}

		nodeVar78 = mix( 1.0, nodeVar71, render.nodeUniform43 );
		shadowValue = vec4<f32>( nodeVar78 );
		

	}

	cascade = cascades.value[ 1u ].xy;

	if ( ( ( linearDepth >= cascade.x ) && ( linearDepth <= cascade.y ) ) ) {

		shadowPositionWorld = v_positionWorld;
		normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
		let nodeConst71 = ( render.nodeUniform44 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform45 ) ) ), 1.0 ) );
		let nodeConst72 = ( nodeConst71.xyz / vec3<f32>( nodeConst71.w ) );
		normalWorldGeometry = normalize( v_normalWorldGeometry );
		nodeVar80 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform26 - owLightPositions.nodeUniform27 ) ) ) ), 0.12, 1.0 );
		let nodeConst73 = vec3<f32>( nodeConst72.x, ( 1.0 - nodeConst72.y ), ( nodeConst72.z + ( render.nodeUniform46 - ( ( ( ( render.nodeUniform47 - render.nodeUniform48 ) / render.nodeUniform49.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar80 * nodeVar80 ) ) ) ) / nodeVar80 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform50 - render.nodeUniform51 ), 1.0 ) ) ) ) );

		if ( ( ( ( ( ( nodeConst73.x >= 0.0 ) && ( nodeConst73.x <= 1.0 ) ) && ( nodeConst73.y >= 0.0 ) ) && ( nodeConst73.y <= 1.0 ) ) && ( nodeConst73.z <= 1.0 ) ) ) {

			let nodeConst74 = ( fn28( fragCoord.xy ) * 6.28318530718 );
			let nodeConst75 = ( render.nodeUniform53 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform54 ).x );
			let nodeConst76 = ( nodeConst73.xy + ( fn29( 0, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
			nodeVar81 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst76, nodeConst73.z );
			let nodeConst77 = ( nodeConst73.xy + ( fn29( 1, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
			nodeVar82 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst77, nodeConst73.z );
			let nodeConst78 = ( nodeConst73.xy + ( fn29( 2, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
			nodeVar83 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst78, nodeConst73.z );
			let nodeConst79 = ( nodeConst73.xy + ( fn29( 3, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
			nodeVar84 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst79, nodeConst73.z );
			let nodeConst80 = ( nodeConst73.xy + ( fn29( 4, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
			nodeVar85 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst80, nodeConst73.z );
			nodeVar79 = ( ( ( ( ( nodeVar81 + nodeVar82 ) + nodeVar83 ) + nodeVar84 ) + nodeVar85 ) * 0.2 );

		} else {

			nodeVar79 = 1.0;

		}

		nodeVar86 = mix( 1.0, nodeVar79, render.nodeUniform55 );
		shadowValue = vec4<f32>( nodeVar86 );
		

	}

	cascade = cascades.value[ 2u ].xy;

	if ( ( ( linearDepth >= cascade.x ) && ( linearDepth <= cascade.y ) ) ) {

		shadowPositionWorld = v_positionWorld;
		normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
		let nodeConst81 = ( render.nodeUniform56 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform57 ) ) ), 1.0 ) );
		let nodeConst82 = ( nodeConst81.xyz / vec3<f32>( nodeConst81.w ) );
		normalWorldGeometry = normalize( v_normalWorldGeometry );
		nodeVar88 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform26 - owLightPositions.nodeUniform27 ) ) ) ), 0.12, 1.0 );
		let nodeConst83 = vec3<f32>( nodeConst82.x, ( 1.0 - nodeConst82.y ), ( nodeConst82.z + ( render.nodeUniform58 - ( ( ( ( render.nodeUniform59 - render.nodeUniform60 ) / render.nodeUniform61.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar88 * nodeVar88 ) ) ) ) / nodeVar88 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform62 - render.nodeUniform63 ), 1.0 ) ) ) ) );

		if ( ( ( ( ( ( nodeConst83.x >= 0.0 ) && ( nodeConst83.x <= 1.0 ) ) && ( nodeConst83.y >= 0.0 ) ) && ( nodeConst83.y <= 1.0 ) ) && ( nodeConst83.z <= 1.0 ) ) ) {

			let nodeConst84 = ( fn28( fragCoord.xy ) * 6.28318530718 );
			let nodeConst85 = ( render.nodeUniform65 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform66 ).x );
			let nodeConst86 = ( nodeConst83.xy + ( fn29( 0, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
			nodeVar89 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst86, nodeConst83.z );
			let nodeConst87 = ( nodeConst83.xy + ( fn29( 1, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
			nodeVar90 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst87, nodeConst83.z );
			let nodeConst88 = ( nodeConst83.xy + ( fn29( 2, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
			nodeVar91 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst88, nodeConst83.z );
			let nodeConst89 = ( nodeConst83.xy + ( fn29( 3, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
			nodeVar92 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst89, nodeConst83.z );
			let nodeConst90 = ( nodeConst83.xy + ( fn29( 4, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
			nodeVar93 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst90, nodeConst83.z );
			nodeVar87 = ( ( ( ( ( nodeVar89 + nodeVar90 ) + nodeVar91 ) + nodeVar92 ) + nodeVar93 ) * 0.2 );

		} else {

			nodeVar87 = 1.0;

		}

		nodeVar94 = mix( 1.0, nodeVar87, render.nodeUniform67 );
		shadowValue = vec4<f32>( nodeVar94 );
		

	}

	nodeVar95 = ( vec4<f32>( clamp( dot( normalView, nodeConst60 ), 0.0, 1.0 ) ) * ( vec4<f32>( render.nodeUniform28, 1.0 ) * shadowValue ) );
	let nodeConst91 = clamp( dot( positionViewDirection, normalize( ( nodeConst60 + positionViewDirection ) ) ), 0.0, 1.0 );
	let nodeConst92 = exp2( ( ( ( nodeConst91 * -5.55473 ) - 6.98316 ) * nodeConst91 ) );
	directDiffuse = ( vec4<f32>( directDiffuse, 1.0 ) + ( ( nodeVar95 * vec4<f32>( ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ), 1.0 ) ) * vec4<f32>( ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst92 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst92 ) ) ) ), 1.0 ) ) ).xyz;
	let nodeConst93 = normalize( ( nodeConst60 + positionViewDirection ) );
	let nodeConst94 = clamp( dot( positionViewDirection, nodeConst93 ), 0.0, 1.0 );
	let nodeConst95 = exp2( ( ( ( nodeConst94 * -5.55473 ) - 6.98316 ) * nodeConst94 ) );
	let nodeConst96 = max( Roughness, 0.045 );
	let nodeConst97 = ( nodeConst96 * nodeConst96 );
	directSpecular = ( vec4<f32>( directSpecular, 1.0 ) + ( ( nodeVar95 * vec4<f32>( ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst95 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst95 ) ) ) * vec3<f32>( fn10( nodeConst97, clamp( dot( normalView, nodeConst60 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst97, clamp( dot( normalView, nodeConst93 ), 0.0, 1.0 ) ) ) ), 1.0 ) ) * vec4<f32>( multiScatteringCompensation, 1.0 ) ) ).xyz;
	let nodeConst98 = normalize( ( render.cameraViewMatrix * vec4<f32>( ( owLightPositions.nodeUniform68 - owLightPositions.nodeUniform69 ), 0.0 ) ).xyz );
	nodeVar96 = ( vec3<f32>( clamp( dot( normalView, nodeConst98 ), 0.0, 1.0 ) ) * render.nodeUniform70 );
	let nodeConst99 = clamp( dot( positionViewDirection, normalize( ( nodeConst98 + positionViewDirection ) ) ), 0.0, 1.0 );
	let nodeConst100 = exp2( ( ( ( nodeConst99 * -5.55473 ) - 6.98316 ) * nodeConst99 ) );
	directDiffuse = ( directDiffuse + ( ( nodeVar96 * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst100 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst100 ) ) ) ) ) );
	let nodeConst101 = normalize( ( nodeConst98 + positionViewDirection ) );
	let nodeConst102 = clamp( dot( positionViewDirection, nodeConst101 ), 0.0, 1.0 );
	let nodeConst103 = exp2( ( ( ( nodeConst102 * -5.55473 ) - 6.98316 ) * nodeConst102 ) );
	let nodeConst104 = max( Roughness, 0.045 );
	let nodeConst105 = ( nodeConst104 * nodeConst104 );
	directSpecular = ( directSpecular + ( ( nodeVar96 * ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst103 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst103 ) ) ) * vec3<f32>( fn10( nodeConst105, clamp( dot( normalView, nodeConst98 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst105, clamp( dot( normalView, nodeConst101 ), 0.0, 1.0 ) ) ) ) ) * multiScatteringCompensation ) );
	let nodeConst106 = ( render.nodeUniform71 - v_positionView );
	let nodeConst107 = normalize( nodeConst106 );
	shadowPositionWorld = v_positionWorld;
	normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
	let nodeConst108 = ( render.nodeUniform73 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform74 ) ) ), 1.0 ) );
	let nodeConst109 = ( nodeConst108.xyz / vec3<f32>( nodeConst108.w ) );
	let nodeConst110 = vec3<f32>( nodeConst109.x, ( 1.0 - nodeConst109.y ), ( nodeConst109.z + render.nodeUniform75 ) );

	if ( ( ( ( ( ( nodeConst110.x >= 0.0 ) && ( nodeConst110.x <= 1.0 ) ) && ( nodeConst110.y >= 0.0 ) ) && ( nodeConst110.y <= 1.0 ) ) && ( nodeConst110.z <= 1.0 ) ) ) {

		let nodeConst111 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst112 = ( vec2<f32>( render.nodeUniform77 ) * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform78 ) );
		let nodeConst113 = ( nodeConst110.xy + ( fn29( 0, 5, nodeConst111 ) * nodeConst112 ) );
		nodeVar98 = textureSampleCompare( nodeUniform76, nodeUniform76_sampler, nodeConst113, nodeConst110.z );
		let nodeConst114 = ( nodeConst110.xy + ( fn29( 1, 5, nodeConst111 ) * nodeConst112 ) );
		nodeVar99 = textureSampleCompare( nodeUniform76, nodeUniform76_sampler, nodeConst114, nodeConst110.z );
		let nodeConst115 = ( nodeConst110.xy + ( fn29( 2, 5, nodeConst111 ) * nodeConst112 ) );
		nodeVar100 = textureSampleCompare( nodeUniform76, nodeUniform76_sampler, nodeConst115, nodeConst110.z );
		let nodeConst116 = ( nodeConst110.xy + ( fn29( 3, 5, nodeConst111 ) * nodeConst112 ) );
		nodeVar101 = textureSampleCompare( nodeUniform76, nodeUniform76_sampler, nodeConst116, nodeConst110.z );
		let nodeConst117 = ( nodeConst110.xy + ( fn29( 4, 5, nodeConst111 ) * nodeConst112 ) );
		nodeVar102 = textureSampleCompare( nodeUniform76, nodeUniform76_sampler, nodeConst117, nodeConst110.z );
		nodeVar97 = ( ( ( ( ( nodeVar98 + nodeVar99 ) + nodeVar100 ) + nodeVar101 ) + nodeVar102 ) * 0.2 );

	} else {

		nodeVar97 = 1.0;

	}

	nodeVar103 = mix( 1.0, nodeVar97, render.nodeUniform79 );
	nodeVar104 = ( vec3<f32>( clamp( dot( normalView, nodeConst107 ), 0.0, 1.0 ) ) * ( ( ( render.nodeUniform72 * vec3<f32>( nodeVar103 ) ) * vec3<f32>( smoothstep( render.nodeUniform80, render.nodeUniform81, dot( nodeConst107, normalize( ( render.cameraViewMatrix * vec4<f32>( ( owLightPositions.nodeUniform82 - owLightPositions.nodeUniform83 ), 0.0 ) ).xyz ) ) ) ) ) * vec3<f32>( fn38( length( nodeConst106 ), render.nodeUniform84, render.nodeUniform85 ) ) ) );
	let nodeConst118 = clamp( dot( positionViewDirection, normalize( ( nodeConst107 + positionViewDirection ) ) ), 0.0, 1.0 );
	let nodeConst119 = exp2( ( ( ( nodeConst118 * -5.55473 ) - 6.98316 ) * nodeConst118 ) );
	directDiffuse = ( directDiffuse + ( ( nodeVar104 * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst119 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst119 ) ) ) ) ) );
	let nodeConst120 = normalize( ( nodeConst107 + positionViewDirection ) );
	let nodeConst121 = clamp( dot( positionViewDirection, nodeConst120 ), 0.0, 1.0 );
	let nodeConst122 = exp2( ( ( ( nodeConst121 * -5.55473 ) - 6.98316 ) * nodeConst121 ) );
	let nodeConst123 = max( Roughness, 0.045 );
	let nodeConst124 = ( nodeConst123 * nodeConst123 );
	directSpecular = ( directSpecular + ( ( nodeVar104 * ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst122 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst122 ) ) ) * vec3<f32>( fn10( nodeConst124, clamp( dot( normalView, nodeConst107 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst124, clamp( dot( normalView, nodeConst120 ), 0.0, 1.0 ) ) ) ) ) * multiScatteringCompensation ) );
	radiance = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst125 = normalize( ( render.cameraWorldMatrix * vec4<f32>( normalize( mix( reflect( ( - positionViewDirection ), normalView ), normalView, ( ( ( Roughness * Roughness ) * Roughness ) * Roughness ) ) ), 0.0 ) ).xyz );
	let nodeConst126 = ( object.nodeUniform87 * vec4<f32>( nodeConst125, 1.0 ) );
	let nodeConst127 = clamp( Roughness, 0.0, 1.0 );
	nodeVar105 = textureSampleLevel( nodeUniform86, nodeUniform86_sampler, vec3<f32>( ( - nodeConst126.x ), nodeConst126.yz ), ( ( object.nodeUniform89 * nodeConst127 ) * ( 2.0 - nodeConst127 ) ) );
	radiance = ( radiance + ( nodeVar105.xyz * vec3<f32>( object.nodeUniform90 ) ) );
	iblIrradiance = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst128 = ( object.nodeUniform87 * vec4<f32>( normalWorld, 1.0 ) );
	let nodeConst129 = clamp( 1.0, 0.0, 1.0 );
	nodeVar106 = textureSampleLevel( nodeUniform86, nodeUniform86_sampler, vec3<f32>( ( - nodeConst128.x ), nodeConst128.yz ), ( ( object.nodeUniform89 * nodeConst129 ) * ( 2.0 - nodeConst129 ) ) );
	iblIrradiance = ( iblIrradiance + ( ( nodeVar106.xyz * vec3<f32>( 3.141592653589793 ) ) * vec3<f32>( object.nodeUniform90 ) ) );
	nodeVar107 = 0.0;

	for ( var i : i32 = 0; i < 10; i ++ ) {


		if ( ( i >= object.nodeUniform92 ) ) {

			break;
			

		}

		nodeVar107 = max( nodeVar107, smoothstep( 0.06, 0.3, min( min( ( nodeUniform93.value[ i ].z - abs( ( ( ( ( v_positionWorld.x * object.nodeUniform94.x ) + ( v_positionWorld.z * object.nodeUniform94.y ) ) + object.nodeUniform94.z ) - nodeUniform93.value[ i ].x ) ) ), ( nodeUniform93.value[ i ].w - abs( ( ( ( ( v_positionWorld.z * object.nodeUniform94.x ) - ( v_positionWorld.x * object.nodeUniform94.y ) ) + object.nodeUniform94.w ) - nodeUniform93.value[ i ].y ) ) ) ), min( ( v_positionWorld.y - nodeUniform95.value[ i ].x ), ( nodeUniform95.value[ i ].y - v_positionWorld.y ) ) ) ) );

	}

	ambientOcclusion = 1.0;
	let nodeConst130 = mix( 0.035, 1.0, clamp( min( ( 1.0 - nodeVar107 ), mix( 1.0, smoothstep( 0.45, 0.98, ambientOcclusion ), 0.6 ) ), 0.0, 1.0 ) );
	iblIrradiance = ( iblIrradiance * vec3<f32>( ( render.nodeUniform91 * nodeConst130 ) ) );
	irradiance = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst131 = clamp( normalWorld.y, -1.0, 1.0 );
	irradiance = ( irradiance + ( ( ( ( render.nodeUniform96 * vec3<f32>( smoothstep( -0.95, 0.85, nodeConst131 ) ) ) + ( render.nodeUniform97 * vec3<f32>( ( smoothstep( -0.05, 0.7, ( - nodeConst131 ) ) + ( clamp( ( ( dot( normalWorld, normalize( vec3<f32>( ( ( - render.nodeUniform98.x ) + 0.0001 ), 0.28, ( ( - render.nodeUniform98.z ) + 0.0001 ) ) ) ) + 0.12 ) / 1.12 ), 0.0, 1.0 ) * 0.6153846153846154 ) ) ) ) ) * vec3<f32>( nodeConst130 ) ) * vec3<f32>( sqrt( max( ambientOcclusion, 0.0 ) ) ) ) );
	ambientOcclusion = ( ambientOcclusion * AmbientOcclusion );

	for ( var i : i32 = 0; i < 64; i ++ ) {

		let nodeConst132 = floor( ( fragCoord.xy / vec2<f32>( 32.0 ) ) );
		let nodeConst133 = i32( object.nodeUniform100.x );
		nodeVar108 = ( ( i32( nodeConst132.x ) + ( i32( nodeConst132.y ) * nodeConst133 ) ) + ( i32( clamp( floor( ( ( log( ( ( - v_positionView.z ) / render.clusteredCameraNear ) ) * ( 1.0 / log( ( render.clusteredCameraFar / render.clusteredCameraNear ) ) ) ) * 24.0 ) ), 0.0, 23.0 ) ) * ( nodeConst133 * i32( object.nodeUniform100.y ) ) ) );
		let nodeConst134 = i;

		if ( ( lightIndexes.value[ ( ( nodeVar108 * 16 ) + ( nodeConst134 / 4 ) ) ][ ( nodeConst134 % 4 ) ] == 0 ) ) {

			break;
			

		}

		let nodeConst135 = ( lightIndexes.value[ ( ( nodeVar108 * 16 ) + ( nodeConst134 / 4 ) ) ][ ( nodeConst134 % 4 ) ] - 1 );
		nodeVar109 = textureLoad( nodeUniform104, vec2<i32>( nodeConst135, i32( 0.0 ) ), u32( 0u ) );
		let nodeConst136 = ( ( render.clusteredCameraViewMatrix * vec4<f32>( nodeVar109.xyz, 1.0 ) ).xyz - v_positionView );
		nodeVar110 = textureLoad( nodeUniform104, vec2<i32>( nodeConst135, i32( 2.0 ) ), u32( 0u ) );
		nodeVar111 = smoothstep( 0.0, 1.0, ( dot( normalize( nodeConst136 ), ( render.clusteredCameraViewMatrix * vec4<f32>( nodeVar110.xyz, 0.0 ) ).xyz ) - nodeVar110.w ) );

		if ( ( ( ( nodeVar109.w == 0.0 ) || ( dot( nodeConst136, nodeConst136 ) <= ( nodeVar109.w * nodeVar109.w ) ) ) && ( nodeVar111 > 0.0 ) ) ) {

			let nodeConst137 = normalize( nodeConst136 );
			nodeVar112 = textureLoad( nodeUniform104, vec2<i32>( nodeConst135, i32( 1.0 ) ), u32( 0u ) );
			nodeVar113 = ( vec3<f32>( clamp( dot( normalView, nodeConst137 ), 0.0, 1.0 ) ) * ( ( nodeVar112.xyz * vec3<f32>( nodeVar111 ) ) * vec3<f32>( fn38( length( nodeConst136 ), nodeVar109.w, nodeVar112.w ) ) ) );
			let nodeConst138 = clamp( dot( positionViewDirection, normalize( ( nodeConst137 + positionViewDirection ) ) ), 0.0, 1.0 );
			let nodeConst139 = exp2( ( ( ( nodeConst138 * -5.55473 ) - 6.98316 ) * nodeConst138 ) );
			directDiffuse = ( directDiffuse + ( ( nodeVar113 * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst139 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst139 ) ) ) ) ) );
			let nodeConst140 = normalize( ( nodeConst137 + positionViewDirection ) );
			let nodeConst141 = clamp( dot( positionViewDirection, nodeConst140 ), 0.0, 1.0 );
			let nodeConst142 = exp2( ( ( ( nodeConst141 * -5.55473 ) - 6.98316 ) * nodeConst141 ) );
			let nodeConst143 = max( Roughness, 0.045 );
			let nodeConst144 = ( nodeConst143 * nodeConst143 );
			directSpecular = ( directSpecular + ( ( nodeVar113 * ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst142 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst142 ) ) ) * vec3<f32>( fn10( nodeConst144, clamp( dot( normalView, nodeConst137 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst144, clamp( dot( normalView, nodeConst140 ), 0.0, 1.0 ) ) ) ) ) * multiScatteringCompensation ) );
			

		}


	}

	nodeVar114 = ( ( irradiance * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( singleScatteringDielectric + multiScatteringDielectric ) ) );
	indirectDiffuse = vec3<f32>( 0.0, 0.0, 0.0 );
	indirectDiffuse = ( indirectDiffuse + nodeVar114 );
	singleScatteringMetallic = vec3<f32>( 0.0, 0.0, 0.0 );
	multiScatteringMetallic = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst145 = ( ( DiffuseColor.xyz * vec3<f32>( dfg.x ) ) + vec3<f32>( ( SpecularF90 * dfg.y ) ) );
	singleScatteringMetallic = ( singleScatteringMetallic + nodeConst145 );
	let nodeConst146 = ( DiffuseColor.xyz + ( ( vec3<f32>( 1.0 ) - DiffuseColor.xyz ) * vec3<f32>( 0.047619 ) ) );
	let nodeConst147 = ( 1.0 - ( dfg.x + dfg.y ) );
	multiScatteringMetallic = ( multiScatteringMetallic + ( ( ( nodeConst145 * nodeConst146 ) / ( vec3<f32>( 1.0 ) - ( vec3<f32>( nodeConst147 ) * nodeConst146 ) ) ) * vec3<f32>( nodeConst147 ) ) );
	let nodeConst148 = ( iblIrradiance * vec3<f32>( 0.3183098861837907 ) );
	nodeVar115 = ( ( radiance * mix( singleScatteringDielectric, singleScatteringMetallic, Metalness ) ) + ( mix( multiScatteringDielectric, multiScatteringMetallic, Metalness ) * nodeConst148 ) );
	nodeVar116 = ( ( DiffuseContribution * ( vec3<f32>( 1.0 ) - ( singleScatteringDielectric + multiScatteringDielectric ) ) ) * nodeConst148 );
	indirectSpecular = vec3<f32>( 0.0, 0.0, 0.0 );
	indirectSpecular = ( indirectSpecular + nodeVar115 );
	indirectDiffuse = ( indirectDiffuse + nodeVar116 );
	indirectDiffuse = ( indirectDiffuse * vec3<f32>( ambientOcclusion ) );
	indirectSpecular = ( indirectSpecular * vec3<f32>( clamp( ( ambientOcclusion - ( 1.0 - pow( ( clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) + ambientOcclusion ), exp2( ( - ( 1.0 - ( Roughness * -16.0 ) ) ) ) ) ) ), 0.0, 1.0 ) ) );
	totalDiffuse = ( directDiffuse + indirectDiffuse );
	totalSpecular = ( directSpecular + indirectSpecular );
	outgoingLight = ( totalDiffuse + totalSpecular );
	let nodeConst149 = max( vec4<f32>( ( outgoingLight + EmissiveColor ), DiffuseColor.w ), vec4<f32>( 0.0 ) );
	Output = nodeConst149;
	let nodeConst61 = ( render.nodeUniform32 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform33 ) ) ), 1.0 ) );
	let nodeConst62 = ( nodeConst61.xyz / vec3<f32>( nodeConst61.w ) );
	normalWorldGeometry = normalize( v_normalWorldGeometry );
	nodeVar72 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform26 - owLightPositions.nodeUniform27 ) ) ) ), 0.12, 1.0 );
	let nodeConst63 = vec3<f32>( nodeConst62.x, ( 1.0 - nodeConst62.y ), ( nodeConst62.z + ( render.nodeUniform34 - ( ( ( ( render.nodeUniform35 - render.nodeUniform36 ) / render.nodeUniform37.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar72 * nodeVar72 ) ) ) ) / nodeVar72 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform38 - render.nodeUniform39 ), 1.0 ) ) ) ) );

	if ( ( ( ( ( ( nodeConst63.x >= 0.0 ) && ( nodeConst63.x <= 1.0 ) ) && ( nodeConst63.y >= 0.0 ) ) && ( nodeConst63.y <= 1.0 ) ) && ( nodeConst63.z <= 1.0 ) ) ) {

		let nodeConst64 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst65 = ( render.nodeUniform41 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform42 ).x );
		let nodeConst66 = ( nodeConst63.xy + ( fn29( 0, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar73 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst66, nodeConst63.z );
		let nodeConst67 = ( nodeConst63.xy + ( fn29( 1, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar74 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst67, nodeConst63.z );
		let nodeConst68 = ( nodeConst63.xy + ( fn29( 2, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar75 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst68, nodeConst63.z );
		let nodeConst69 = ( nodeConst63.xy + ( fn29( 3, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar76 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst69, nodeConst63.z );
		let nodeConst70 = ( nodeConst63.xy + ( fn29( 4, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar77 = textureSampleCompare( nodeUniform40, nodeUniform40_sampler, nodeConst70, nodeConst63.z );
		nodeVar117 = ( ( ( ( ( nodeVar73 + nodeVar74 ) + nodeVar75 ) + nodeVar76 ) + nodeVar77 ) * 0.2 );

	} else {

		nodeVar117 = 1.0;

	}

	nodeVar78 = mix( 1.0, nodeVar117, render.nodeUniform43 );
	let nodeConst71 = ( render.nodeUniform44 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform45 ) ) ), 1.0 ) );
	let nodeConst72 = ( nodeConst71.xyz / vec3<f32>( nodeConst71.w ) );
	nodeVar80 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform26 - owLightPositions.nodeUniform27 ) ) ) ), 0.12, 1.0 );
	let nodeConst73 = vec3<f32>( nodeConst72.x, ( 1.0 - nodeConst72.y ), ( nodeConst72.z + ( render.nodeUniform46 - ( ( ( ( render.nodeUniform47 - render.nodeUniform48 ) / render.nodeUniform49.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar80 * nodeVar80 ) ) ) ) / nodeVar80 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform50 - render.nodeUniform51 ), 1.0 ) ) ) ) );

	if ( ( ( ( ( ( nodeConst73.x >= 0.0 ) && ( nodeConst73.x <= 1.0 ) ) && ( nodeConst73.y >= 0.0 ) ) && ( nodeConst73.y <= 1.0 ) ) && ( nodeConst73.z <= 1.0 ) ) ) {

		let nodeConst74 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst75 = ( render.nodeUniform53 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform54 ).x );
		let nodeConst76 = ( nodeConst73.xy + ( fn29( 0, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
		nodeVar81 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst76, nodeConst73.z );
		let nodeConst77 = ( nodeConst73.xy + ( fn29( 1, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
		nodeVar82 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst77, nodeConst73.z );
		let nodeConst78 = ( nodeConst73.xy + ( fn29( 2, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
		nodeVar83 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst78, nodeConst73.z );
		let nodeConst79 = ( nodeConst73.xy + ( fn29( 3, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
		nodeVar84 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst79, nodeConst73.z );
		let nodeConst80 = ( nodeConst73.xy + ( fn29( 4, 5, nodeConst74 ) * vec2<f32>( nodeConst75 ) ) );
		nodeVar85 = textureSampleCompare( nodeUniform52, nodeUniform52_sampler, nodeConst80, nodeConst73.z );
		nodeVar118 = ( ( ( ( ( nodeVar81 + nodeVar82 ) + nodeVar83 ) + nodeVar84 ) + nodeVar85 ) * 0.2 );

	} else {

		nodeVar118 = 1.0;

	}

	nodeVar86 = mix( 1.0, nodeVar118, render.nodeUniform55 );
	let nodeConst81 = ( render.nodeUniform56 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform57 ) ) ), 1.0 ) );
	let nodeConst82 = ( nodeConst81.xyz / vec3<f32>( nodeConst81.w ) );
	nodeVar88 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform26 - owLightPositions.nodeUniform27 ) ) ) ), 0.12, 1.0 );
	let nodeConst83 = vec3<f32>( nodeConst82.x, ( 1.0 - nodeConst82.y ), ( nodeConst82.z + ( render.nodeUniform58 - ( ( ( ( render.nodeUniform59 - render.nodeUniform60 ) / render.nodeUniform61.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar88 * nodeVar88 ) ) ) ) / nodeVar88 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform62 - render.nodeUniform63 ), 1.0 ) ) ) ) );

	if ( ( ( ( ( ( nodeConst83.x >= 0.0 ) && ( nodeConst83.x <= 1.0 ) ) && ( nodeConst83.y >= 0.0 ) ) && ( nodeConst83.y <= 1.0 ) ) && ( nodeConst83.z <= 1.0 ) ) ) {

		let nodeConst84 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst85 = ( render.nodeUniform65 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform66 ).x );
		let nodeConst86 = ( nodeConst83.xy + ( fn29( 0, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
		nodeVar89 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst86, nodeConst83.z );
		let nodeConst87 = ( nodeConst83.xy + ( fn29( 1, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
		nodeVar90 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst87, nodeConst83.z );
		let nodeConst88 = ( nodeConst83.xy + ( fn29( 2, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
		nodeVar91 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst88, nodeConst83.z );
		let nodeConst89 = ( nodeConst83.xy + ( fn29( 3, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
		nodeVar92 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst89, nodeConst83.z );
		let nodeConst90 = ( nodeConst83.xy + ( fn29( 4, 5, nodeConst84 ) * vec2<f32>( nodeConst85 ) ) );
		nodeVar93 = textureSampleCompare( nodeUniform64, nodeUniform64_sampler, nodeConst90, nodeConst83.z );
		nodeVar119 = ( ( ( ( ( nodeVar89 + nodeVar90 ) + nodeVar91 ) + nodeVar92 ) + nodeVar93 ) * 0.2 );

	} else {

		nodeVar119 = 1.0;

	}

	nodeVar94 = mix( 1.0, nodeVar119, render.nodeUniform67 );
	let nodeConst132 = floor( ( fragCoord.xy / vec2<f32>( 32.0 ) ) );
	let nodeConst133 = i32( object.nodeUniform100.x );
	nodeVar108 = ( ( i32( nodeConst132.x ) + ( i32( nodeConst132.y ) * nodeConst133 ) ) + ( i32( clamp( floor( ( ( log( ( ( - v_positionView.z ) / render.clusteredCameraNear ) ) * ( 1.0 / log( ( render.clusteredCameraFar / render.clusteredCameraNear ) ) ) ) * 24.0 ) ), 0.0, 23.0 ) ) * ( nodeConst133 * i32( object.nodeUniform100.y ) ) ) );

	// result

	output.color = nodeConst149;

	return output;

}
