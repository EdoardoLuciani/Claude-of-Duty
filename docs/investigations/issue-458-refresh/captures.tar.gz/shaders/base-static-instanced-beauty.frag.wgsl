// Three.js r187dev - Node System

// global
diagnostic( off, derivative_uniformity );


// directives


// structs

struct StructType0 {
	color : vec3<f32>,
	opacity : f32,
	normal : vec3<f32>,
	rough : f32,
	metal : f32,
	ao : f32
};

struct OutputStruct {
	@location( 0 ) color: vec4<f32>
};
var<private> output : OutputStruct;

// uniforms
@binding( 1 ) @group( 2 ) var nodeUniform8_sampler : sampler;
@binding( 2 ) @group( 2 ) var nodeUniform8 : texture_2d<f32>;
@binding( 3 ) @group( 2 ) var nodeUniform9_sampler : sampler;
@binding( 4 ) @group( 2 ) var nodeUniform9 : texture_2d<f32>;
@binding( 5 ) @group( 2 ) var nodeUniform10_sampler : sampler;
@binding( 6 ) @group( 2 ) var nodeUniform10 : texture_2d<f32>;
@binding( 7 ) @group( 2 ) var nodeUniform12_sampler : sampler;
@binding( 8 ) @group( 2 ) var nodeUniform12 : texture_2d<f32>;
@binding( 9 ) @group( 2 ) var nodeUniform13_sampler : sampler;
@binding( 10 ) @group( 2 ) var nodeUniform13 : texture_2d<f32>;
@binding( 11 ) @group( 2 ) var nodeUniform14_sampler : sampler;
@binding( 12 ) @group( 2 ) var nodeUniform14 : texture_2d<f32>;
@binding( 13 ) @group( 2 ) var nodeUniform20_sampler : sampler;
@binding( 14 ) @group( 2 ) var nodeUniform20 : texture_2d<f32>;
@binding( 15 ) @group( 2 ) var nodeUniform27_sampler : sampler;
@binding( 16 ) @group( 2 ) var nodeUniform27 : texture_2d<f32>;
@binding( 17 ) @group( 2 ) var nodeUniform42_sampler : sampler_comparison;
@binding( 18 ) @group( 2 ) var nodeUniform42 : texture_depth_2d;
@binding( 19 ) @group( 2 ) var nodeUniform54_sampler : sampler_comparison;
@binding( 20 ) @group( 2 ) var nodeUniform54 : texture_depth_2d;
@binding( 21 ) @group( 2 ) var nodeUniform66_sampler : sampler_comparison;
@binding( 22 ) @group( 2 ) var nodeUniform66 : texture_depth_2d;
@binding( 23 ) @group( 2 ) var nodeUniform78_sampler : sampler_comparison;
@binding( 24 ) @group( 2 ) var nodeUniform78 : texture_depth_2d;
@binding( 25 ) @group( 2 ) var nodeUniform88_sampler : sampler;
@binding( 26 ) @group( 2 ) var nodeUniform88 : texture_cube<f32>;
@binding( 28 ) @group( 2 ) var nodeUniform106 : texture_2d<f32>;

struct cascadesStruct {
	value : array< vec4<f32>, 3 >
};
@binding( 1 ) @group( 0 )
var<uniform> cascades : cascadesStruct;

struct nodeUniform95Struct {
	value : array< vec4<f32>, 10 >
};
@binding( 0 ) @group( 3 )
var<uniform> nodeUniform95 : nodeUniform95Struct;

struct nodeUniform97Struct {
	value : array< vec4<f32>, 10 >
};
@binding( 1 ) @group( 3 )
var<uniform> nodeUniform97 : nodeUniform97Struct;

struct lightIndexesStruct {
	value : array< vec4<i32> >
};
@binding( 27 ) @group( 2 )
var<storage, read> lightIndexes : lightIndexesStruct;

struct objectStruct {
	nodeUniform3 : mat3x3<f32>,
	nodeUniform4 : mat4x4<f32>,
	nodeUniform5 : f32,
	nodeUniform6 : f32,
	nodeUniform11 : f32,
	nodeUniform15 : vec4<f32>,
	nodeUniform16 : f32,
	nodeUniform17 : vec3<f32>,
	nodeUniform19 : f32,
	nodeUniform21 : mat3x3<f32>,
	nodeUniform23 : f32,
	nodeUniform24 : f32,
	nodeUniform25 : vec3<f32>,
	nodeUniform26 : f32,
	nodeUniform89 : mat4x4<f32>,
	nodeUniform91 : f32,
	nodeUniform92 : f32,
	nodeUniform94 : i32,
	nodeUniform96 : vec4<f32>,
	nodeUniform102 : vec2<f32>
};
@binding( 0 ) @group( 2 )
var<uniform> object : objectStruct;

struct renderStruct {
	nodeUniform98 : vec3<f32>,
	nodeUniform99 : vec3<f32>,
	nodeUniform100 : vec3<f32>,
	nodeUniform93 : f32,
	cameraProjectionMatrix : mat4x4<f32>,
	cameraViewMatrix : mat4x4<f32>,
	cameraWorldMatrix : mat4x4<f32>,
	clusteredCameraNear : f32,
	clusteredCameraFar : f32,
	clusteredCameraViewMatrix : mat4x4<f32>,
	nodeUniform22 : vec2<f32>,
	cameraPosition : vec3<f32>,
	nodeUniform30 : vec3<f32>,
	nodeUniform72 : vec3<f32>,
	nodeUniform82 : f32,
	nodeUniform83 : f32,
	nodeUniform86 : f32,
	nodeUniform87 : f32,
	nodeUniform74 : vec3<f32>,
	shadowFar : f32,
	nodeUniform32 : f32,
	nodeUniform34 : mat4x4<f32>,
	nodeUniform35 : f32,
	nodeUniform36 : f32,
	nodeUniform37 : f32,
	nodeUniform38 : f32,
	nodeUniform39 : vec2<f32>,
	nodeUniform40 : f32,
	nodeUniform41 : f32,
	nodeUniform43 : f32,
	nodeUniform44 : vec2<f32>,
	nodeUniform45 : f32,
	nodeUniform46 : mat4x4<f32>,
	nodeUniform47 : f32,
	nodeUniform48 : f32,
	nodeUniform49 : f32,
	nodeUniform50 : f32,
	nodeUniform51 : vec2<f32>,
	nodeUniform52 : f32,
	nodeUniform53 : f32,
	nodeUniform55 : f32,
	nodeUniform56 : vec2<f32>,
	nodeUniform57 : f32,
	nodeUniform58 : mat4x4<f32>,
	nodeUniform59 : f32,
	nodeUniform60 : f32,
	nodeUniform61 : f32,
	nodeUniform62 : f32,
	nodeUniform63 : vec2<f32>,
	nodeUniform64 : f32,
	nodeUniform65 : f32,
	nodeUniform67 : f32,
	nodeUniform68 : vec2<f32>,
	nodeUniform69 : f32,
	nodeUniform73 : vec3<f32>,
	nodeUniform75 : mat4x4<f32>,
	nodeUniform76 : f32,
	nodeUniform77 : f32,
	nodeUniform79 : f32,
	nodeUniform80 : vec2<f32>,
	nodeUniform81 : f32
};
@binding( 0 ) @group( 0 )
var<uniform> render : renderStruct;

struct owLightPositionsStruct {
	nodeUniform28 : vec3<f32>,
	nodeUniform29 : vec3<f32>,
	nodeUniform70 : vec3<f32>,
	nodeUniform71 : vec3<f32>,
	nodeUniform84 : vec3<f32>,
	nodeUniform85 : vec3<f32>
};
@binding( 0 ) @group( 1 )
var<uniform> owLightPositions : owLightPositionsStruct;

// vars
var<private> DiffuseColor : vec4<f32>;
var<private> nodeVar0 : vec3<f32>;
var<private> nodeVar1 : f32;
var<private> nodeVar2 : vec3<f32>;
var<private> normalWorldGeometry : vec3<f32>;
var<private> nodeVar3 : f32;
var<private> nodeVar4 : vec3<f32>;
var<private> nodeVar5 : vec3<f32>;
var<private> nodeVar6 : vec3<f32>;
var<private> nodeVar7 : vec2<f32>;
var<private> nodeVar8 : vec2<f32>;
var<private> nodeVar9 : vec2<f32>;
var<private> nodeVar10 : vec2<f32>;
var<private> nodeVar11 : vec2<f32>;
var<private> nodeVar12 : f32;
var<private> nodeVar13 : f32;
var<private> nodeVar14 : vec2<f32>;
var<private> nodeVar15 : f32;
var<private> nodeVar16 : vec4<f32>;
var<private> nodeVar17 : f32;
var<private> nodeVar18 : vec4<f32>;
var<private> nodeVar19 : vec4<f32>;
var<private> nodeVar20 : vec4<f32>;
var<private> nodeVar21 : vec4<f32>;
var<private> nodeVar22 : vec4<f32>;
var<private> nodeVar23 : vec3<f32>;
var<private> nodeVar24 : vec4<f32>;
var<private> nodeVar25 : vec3<f32>;
var<private> nodeVar26 : vec3<f32>;
var<private> nodeVar27 : vec4<f32>;
var<private> nodeVar28 : vec3<f32>;
var<private> nodeVar29 : f32;
var<private> nodeVar30 : vec4<f32>;
var<private> nodeVar31 : vec2<f32>;
var<private> nodeVar32 : vec4<f32>;
var<private> nodeVar33 : vec4<f32>;
var<private> nodeVar34 : vec3<f32>;
var<private> nodeVar35 : vec3<f32>;
var<private> nodeVar36 : vec3<f32>;
var<private> nodeVar37 : vec3<f32>;
var<private> nodeVar38 : f32;
var<private> nodeVar39 : f32;
var<private> nodeVar40 : vec4<f32>;
var<private> nodeVar41 : vec4<f32>;
var<private> nodeVar42 : f32;
var<private> nodeVar43 : vec3<f32>;
var<private> nodeVar44 : vec3<f32>;
var<private> nodeVar45 : vec3<f32>;
var<private> nodeVar46 : vec3<f32>;
var<private> nodeVar47 : vec3<f32>;
var<private> nodeVar48 : vec3<f32>;
var<private> nodeVar49 : vec3<f32>;
var<private> nodeVar50 : StructType0;
var<private> AmbientOcclusion : f32;
var<private> nodeVar51 : f32;
var<private> Metalness : f32;
var<private> Roughness : f32;
var<private> normalViewGeometry : vec3<f32>;
var<private> SpecularColor : vec3<f32>;
var<private> SpecularColorBlended : vec3<f32>;
var<private> SpecularF90 : f32;
var<private> DiffuseContribution : vec3<f32>;
var<private> EmissiveColor : vec3<f32>;
var<private> Output : vec4<f32>;
var<private> normalView : vec3<f32>;
var<private> positionViewDirection : vec3<f32>;
var<private> nodeVar52 : vec2<f32>;
var<private> singleScatteringDielectric : vec3<f32>;
var<private> multiScatteringDielectric : vec3<f32>;
var<private> directDiffuse : vec3<f32>;
var<private> directSpecular : vec3<f32>;
var<private> shadowPositionWorld : vec3<f32>;
var<private> shadowValue : vec4<f32>;
var<private> cascade : vec2<f32>;
var<private> linearDepth : f32;
var<private> nodeVar53 : f32;
var<private> normalWorld : vec3<f32>;
var<private> nodeVar54 : f32;
var<private> nodeVar55 : f32;
var<private> nodeVar56 : f32;
var<private> nodeVar57 : f32;
var<private> nodeVar58 : f32;
var<private> nodeVar59 : f32;
var<private> nodeVar60 : f32;
var<private> nodeVar61 : f32;
var<private> nodeVar62 : f32;
var<private> nodeVar63 : f32;
var<private> nodeVar64 : f32;
var<private> nodeVar65 : f32;
var<private> nodeVar66 : f32;
var<private> nodeVar67 : f32;
var<private> nodeVar68 : f32;
var<private> nodeVar69 : f32;
var<private> nodeVar70 : f32;
var<private> nodeVar71 : f32;
var<private> nodeVar72 : f32;
var<private> nodeVar73 : f32;
var<private> nodeVar74 : f32;
var<private> nodeVar75 : f32;
var<private> nodeVar76 : f32;
var<private> nodeVar77 : vec4<f32>;
var<private> nodeVar78 : vec3<f32>;
var<private> nodeVar79 : f32;
var<private> nodeVar80 : f32;
var<private> nodeVar81 : f32;
var<private> nodeVar82 : f32;
var<private> nodeVar83 : f32;
var<private> nodeVar84 : f32;
var<private> nodeVar85 : f32;
var<private> nodeVar86 : vec3<f32>;
var<private> radiance : vec3<f32>;
var<private> nodeVar87 : vec4<f32>;
var<private> iblIrradiance : vec3<f32>;
var<private> nodeVar88 : vec4<f32>;
var<private> nodeVar89 : f32;
var<private> ambientOcclusion : f32;
var<private> irradiance : vec3<f32>;
var<private> nodeVar90 : i32;
var<private> nodeVar91 : vec4<f32>;
var<private> nodeVar92 : vec4<f32>;
var<private> nodeVar93 : f32;
var<private> nodeVar94 : vec4<f32>;
var<private> nodeVar95 : vec3<f32>;
var<private> nodeVar96 : vec3<f32>;
var<private> indirectDiffuse : vec3<f32>;
var<private> singleScatteringMetallic : vec3<f32>;
var<private> multiScatteringMetallic : vec3<f32>;
var<private> nodeVar97 : vec3<f32>;
var<private> nodeVar98 : vec3<f32>;
var<private> indirectSpecular : vec3<f32>;
var<private> totalDiffuse : vec3<f32>;
var<private> totalSpecular : vec3<f32>;
var<private> outgoingLight : vec3<f32>;
var<private> nodeVar99 : f32;
var<private> nodeVar100 : f32;
var<private> nodeVar101 : f32;

// codes
fn fn28 ( position : vec2<f32> ) -> f32 {

	


	return fract( ( 52.9829189 * fract( dot( position, vec2<f32>( 0.06711056, 0.00583715 ) ) ) ) );

}


fn fn29 ( sampleIndex : i32, samplesCount : i32, phi : f32 ) -> vec2<f32> {

	

	let nodeConst0 = ( ( f32( sampleIndex ) * 2.399963229728653 ) + phi );

	return ( vec2<f32>( cos( nodeConst0 ), sin( nodeConst0 ) ) * vec2<f32>( sqrt( ( ( f32( sampleIndex ) + 0.5 ) / f32( samplesCount ) ) ) ) );

}


fn fn10 ( alpha : f32, dotNL : f32, dotNV : f32 ) -> f32 {

	

	let nodeConst0 = ( alpha * alpha );

	return ( 0.5 / max( ( ( dotNL * sqrt( ( nodeConst0 + ( ( 1.0 - nodeConst0 ) * ( dotNV * dotNV ) ) ) ) ) + ( dotNV * sqrt( ( nodeConst0 + ( ( 1.0 - nodeConst0 ) * ( dotNL * dotNL ) ) ) ) ) ), 0.000001 ) );

}


fn fn12 ( alpha : f32, dotNH : f32 ) -> f32 {

	

	let nodeConst0 = ( alpha * alpha );
	let nodeConst1 = ( 1.0 - ( ( dotNH * dotNH ) * ( 1.0 - nodeConst0 ) ) );

	return ( ( nodeConst0 / ( nodeConst1 * nodeConst1 ) ) * 0.3183098861837907 );

}


fn fn38 ( lightDistance : f32, cutoffDistance : f32, decayExponent : f32 ) -> f32 {

	var nodeVar0 : f32;


	if ( ( cutoffDistance > 0.0 ) ) {

		let nodeConst0 = ( 1.0 / max( pow( lightDistance, decayExponent ), 0.01 ) );
		let nodeConst1 = ( lightDistance / cutoffDistance );
		let nodeConst2 = clamp( ( 1.0 - ( ( ( nodeConst1 * nodeConst1 ) * nodeConst1 ) * nodeConst1 ) ), 0.0, 1.0 );
		nodeVar0 = ( nodeConst0 * ( nodeConst2 * nodeConst2 ) );

	} else {

		let nodeConst0 = ( 1.0 / max( pow( lightDistance, decayExponent ), 0.01 ) );
		nodeVar0 = nodeConst0;

	}


	return nodeVar0;

}




@fragment
fn main( @location( 0 ) v_positionView : vec3<f32>,
	@location( 1 ) v_normalWorldGeometry : vec3<f32>,
	@location( 2 ) v_normalViewGeometry : vec3<f32>,
	@location( 3 ) v_positionWorld : vec3<f32>,
	@location( 4 ) v_positionViewDirection : vec3<f32>,
	@location( 5 ) vInstanceColor : vec3<f32>,
	@location( 6 ) nodeVarying9 : vec4<f32>,
	@builtin( front_facing ) isFront : bool,
	@builtin( position ) fragCoord : vec4<f32> ) -> OutputStruct {

	// flow
	// code


	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar2 = ( - nodeConst1 );

	}

	let nodeConst2 = pow( abs( nodeVar2 ), vec3<f32>( 5.0, 5.0, 5.0 ) );
	let nodeConst3 = ( nodeConst2 / vec3<f32>( max( ( ( nodeConst2.x + nodeConst2.y ) + nodeConst2.z ), 0.0001 ) ) );

	if ( ( ( nodeConst3.x > nodeConst3.y ) && ( nodeConst3.x > nodeConst3.z ) ) ) {

		nodeVar1 = 0.0;

	} else {


		if ( ( nodeConst3.y > nodeConst3.z ) ) {

			nodeVar3 = 1.0;

		} else {

			nodeVar3 = 2.0;

		}

		nodeVar1 = nodeVar3;

	}


	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar0 = vec3<f32>( 0.0, 0.0, ( - nodeConst4 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar4 = vec3<f32>( 1.0, 0.0, 0.0 );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar4 = vec3<f32>( nodeConst5, 0.0, 0.0 );

		}

		nodeVar0 = nodeVar4;

	}

	nodeVar5 = normalize( ( nodeVar0 - ( nodeVar2 * vec3<f32>( dot( nodeVar0, nodeVar2 ) ) ) ) );
	nodeVar6 = cross( nodeVar2, nodeVar5 );

	if ( ( nodeVar1 == 0.0 ) ) {

		let nodeConst4 = ( ( step( 0.0, nodeVar2.x ) * 2.0 ) - 1.0 );
		nodeVar7 = ( ( vec2<f32>( ( ( - v_positionWorld.z ) * nodeConst4 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform5 ) ) + vec2<f32>( 0.0, 0.0 ) );

	} else {


		if ( ( nodeVar1 == 1.0 ) ) {

			nodeVar8 = ( ( vec2<f32>( v_positionWorld.x, ( ( - v_positionWorld.z ) * ( ( step( 0.0, nodeVar2.y ) * 2.0 ) - 1.0 ) ) ) * vec2<f32>( object.nodeUniform5 ) ) + vec2<f32>( 0.0, 0.0 ) );

		} else {

			let nodeConst5 = ( ( step( 0.0, nodeVar2.z ) * 2.0 ) - 1.0 );
			nodeVar8 = ( ( vec2<f32>( ( v_positionWorld.x * nodeConst5 ), v_positionWorld.y ) * vec2<f32>( object.nodeUniform5 ) ) + vec2<f32>( 0.0, 0.0 ) );

		}

		nodeVar7 = nodeVar8;

	}

	nodeVar9 = nodeVar7;
	nodeVar10 = dpdx( nodeVar7 );
	nodeVar11 = - dpdy( nodeVar7 );
	let nodeConst6 = ( object.nodeUniform6 * object.nodeUniform5 );
	let nodeConst7 = length( ( render.cameraPosition - v_positionWorld ) );
	let nodeConst8 = ( 1.0 - smoothstep( 6.0, 14.0, nodeConst7 ) );

	if ( ( ( nodeConst6 > 0.0 ) && ( nodeConst8 > 0.001 ) ) ) {

		let nodeConst9 = normalize( ( render.cameraPosition - v_positionWorld ) );
		let nodeConst10 = normalize( vec3<f32>( dot( nodeConst9, nodeVar5 ), dot( nodeConst9, nodeVar6 ), dot( nodeConst9, nodeVar2 ) ) );
		nodeVar12 = max( ( mix( 16.0, 8.0, clamp( abs( nodeConst10.z ), 0.0, 1.0 ) ) * nodeConst8 ), 4.0 );
		nodeVar13 = ( 1.0 / nodeVar12 );
		nodeVar14 = ( ( ( ( nodeConst10.xy / vec2<f32>( max( abs( nodeConst10.z ), 0.3 ) ) ) * vec2<f32>( nodeConst6 ) ) * vec2<f32>( nodeConst8 ) ) * vec2<f32>( nodeVar13 ) );
		nodeVar15 = 0.0;
		nodeVar16 = textureSampleGrad( nodeUniform8, nodeUniform8_sampler, nodeVar9, nodeVar10, nodeVar11 );
		nodeVar17 = ( 1.0 - nodeVar16.w );

		for ( var i : i32 = 0; i < 48; i ++ ) {


			if ( ( ( nodeVar15 >= nodeVar17 ) || ( f32( i ) >= nodeVar12 ) ) ) {

				break;
				

			}

			nodeVar9 = ( nodeVar9 - nodeVar14 );
			nodeVar18 = textureSampleGrad( nodeUniform8, nodeUniform8_sampler, nodeVar9, nodeVar10, nodeVar11 );
			nodeVar17 = ( 1.0 - nodeVar18.w );
			nodeVar15 = ( nodeVar15 + nodeVar13 );

		}

		let nodeConst11 = ( nodeVar9 + nodeVar14 );
		let nodeConst12 = ( nodeVar17 - nodeVar15 );
		nodeVar19 = textureSampleGrad( nodeUniform8, nodeUniform8_sampler, nodeConst11, nodeVar10, nodeVar11 );
		nodeVar9 = mix( nodeVar9, nodeConst11, clamp( ( ( - nodeConst12 ) / max( ( ( ( ( 1.0 - nodeVar19.w ) - nodeVar15 ) + nodeVar13 ) - nodeConst12 ), 0.0001 ) ), 0.0, 1.0 ) );
		

	}

	nodeVar20 = textureSample( nodeUniform8, nodeUniform8_sampler, nodeVar9 );
	nodeVar21 = nodeVar20;
	nodeVar22 = textureSample( nodeUniform9, nodeUniform9_sampler, nodeVar9 );
	nodeVar23 = nodeVar22.xyz;
	nodeVar24 = textureSample( nodeUniform10, nodeUniform10_sampler, nodeVar9 );
	nodeVar25 = normalize( vec3<f32>( ( ( ( nodeVar24.x * 2.0 ) - 1.0 ) * object.nodeUniform11 ), ( ( ( nodeVar24.y * 2.0 ) - 1.0 ) * object.nodeUniform11 ), ( ( nodeVar24.z * 2.0 ) - 1.0 ) ) );
	nodeVar26 = ( ( ( nodeVar5 * vec3<f32>( nodeVar25.x ) ) + ( nodeVar6 * vec3<f32>( nodeVar25.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeVar25.z ) ) );
	let nodeConst13 = ( nodeVar9 * vec2<f32>( 3.846153846153846 ) );
	nodeVar27 = textureSample( nodeUniform12, nodeUniform12_sampler, nodeConst13 );
	let nodeConst14 = ( ( nodeVar27.w - 0.5 ) * 2.0 );
	let nodeConst15 = ( 1.0 - smoothstep( 7.2, 16.0, nodeConst7 ) );
	nodeVar28 = ( nodeVar21.xyz * vec3<f32>( ( 1.0 + ( ( ( ( nodeConst14 * 0.95 ) + ( ( nodeVar27.x - 0.5 ) * 1.25 ) ) * 0.32 ) * nodeConst15 ) ) ) );
	nodeVar21.x = nodeVar28[ 0 ];
	nodeVar21.y = nodeVar28[ 1 ];
	nodeVar21.z = nodeVar28[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( max( ( - nodeConst14 ), 0.0 ) * 0.096 ) * nodeConst15 ) ) );
	nodeVar29 = clamp( ( nodeVar21.w + ( ( nodeConst14 * 0.16 ) * nodeConst15 ) ), 0.0, 1.0 );
	nodeVar30 = textureSample( nodeUniform13, nodeUniform13_sampler, nodeConst13 );
	let nodeConst16 = ( ( nodeVar30.xyz * vec3<f32>( 2.0 ) ) - vec3<f32>( 1.0 ) );
	let nodeConst17 = ( ( ( nodeVar5 * vec3<f32>( nodeConst16.x ) ) + ( nodeVar6 * vec3<f32>( nodeConst16.y ) ) ) + ( nodeVar2 * vec3<f32>( nodeConst16.z ) ) );
	nodeVar26 = normalize( ( nodeVar26 + ( ( ( nodeConst17 - ( nodeVar2 * vec3<f32>( dot( nodeConst17, nodeVar2 ) ) ) ) * vec3<f32>( 0.6 ) ) * vec3<f32>( nodeConst15 ) ) ) );

	if ( ( step( 0.62, abs( nodeVar2.y ) ) > 0.5 ) ) {

		nodeVar31 = v_positionWorld.xz;

	} else {

		nodeVar31 = vec2<f32>( ( v_positionWorld.x + ( v_positionWorld.z * 0.63 ) ), v_positionWorld.y );

	}

	nodeVar32 = textureSample( nodeUniform14, nodeUniform14_sampler, ( nodeVar31 * vec2<f32>( 0.1 ) ) );
	nodeVar33 = textureSample( nodeUniform14, nodeUniform14_sampler, ( ( nodeVar31 * vec2<f32>( 0.0211 ) ) + vec2<f32>( 0.37 ) ) );
	nodeVar34 = ( nodeVar21.xyz * vec3<f32>( mix( 1.0, ( ( clamp( ( ( ( ( ( nodeVar32.x * 0.55 ) + ( nodeVar33.z * 0.45 ) ) - 0.5 ) * 1.0 ) + 0.5 ), 0.0, 1.0 ) * 0.92 ) + 0.55 ), 0.28 ) ) );
	nodeVar21.x = nodeVar34[ 0 ];
	nodeVar21.y = nodeVar34[ 1 ];
	nodeVar21.z = nodeVar34[ 2 ];
	nodeVar35 = ( nodeVar21.xyz * mix( vec3<f32>( 1.0, 1.0, 1.0 ), vec3<f32>( 1.05, 1.0, 0.93 ), ( ( nodeVar33.x - 0.5 ) * 0.35 ) ) );
	nodeVar21.x = nodeVar35[ 0 ];
	nodeVar21.y = nodeVar35[ 1 ];
	nodeVar21.z = nodeVar35[ 2 ];
	nodeVar23.y = clamp( ( ( ( nodeVar23.y + ( ( nodeVar32.y - 0.5 ) * 0.14 ) ) + ( ( nodeVar32.w - 0.5 ) * 0.16 ) ) - ( ( nodeConst14 * 0.07 ) * nodeConst15 ) ), 0.0, 1.0 );

	if ( isFront ) {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar36 = nodeConst1;

	} else {

		normalWorldGeometry = normalize( v_normalWorldGeometry );
		let nodeConst1 = normalize( normalWorldGeometry );
		nodeVar36 = ( - nodeConst1 );

	}

	let nodeConst18 = ( ( pow( clamp( nodeVar36.y, 0.0, 1.0 ), 2.0 ) * object.nodeUniform15.x ) * smoothstep( 0.3, 0.8, ( ( nodeVar32.z * 0.7 ) + ( nodeVar33.y * 0.5 ) ) ) );
	nodeVar37 = mix( nodeVar21.xyz, vec3<f32>( 0.14702726648767014, 0.11953842797895521, 0.08865558627723595 ), ( nodeConst18 * 0.75 ) );
	nodeVar21.x = nodeVar37[ 0 ];
	nodeVar21.y = nodeVar37[ 1 ];
	nodeVar21.z = nodeVar37[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst18 * 0.3 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst18 * 0.85 ) ) );
	let nodeConst19 = ( 1.0 - smoothstep( 0.34, 0.72, abs( nodeVar36.y ) ) );
	let nodeConst20 = ( ( v_positionWorld.z * nodeVar36.x ) - ( v_positionWorld.x * nodeVar36.z ) );
	let nodeConst21 = ( nodeConst20 * 1.55 );
	let nodeConst22 = floor( nodeConst21 );
	nodeVar38 = fract( ( ( ( nodeConst22 * 2.71 ) + 11.7 ) * 0.1031 ) );
	nodeVar38 = ( nodeVar38 * ( nodeVar38 + 33.33 ) );
	nodeVar38 = ( nodeVar38 * ( nodeVar38 + nodeVar38 ) );
	let nodeConst23 = fract( nodeVar38 );
	nodeVar39 = fract( ( ( ( nodeConst22 * 1.37 ) + 3.1 ) * 0.1031 ) );
	nodeVar39 = ( nodeVar39 * ( nodeVar39 + 33.33 ) );
	nodeVar39 = ( nodeVar39 * ( nodeVar39 + nodeVar39 ) );
	let nodeConst24 = fract( nodeVar39 );
	let nodeConst25 = ( ( nodeConst23 * 1.2 ) + ( nodeConst24 * 0.5 ) );
	nodeVar40 = textureSample( nodeUniform14, nodeUniform14_sampler, vec2<f32>( ( nodeConst20 * 0.46 ), ( v_positionWorld.y * 0.155 ) ) );
	let nodeConst26 = ( ( ( ( ( floor( ( ( v_positionWorld.y + nodeConst25 ) / 2.85 ) ) + 1.0 ) * 2.85 ) - nodeConst25 ) + ( ( nodeVar40.w - 0.5 ) * 0.2 ) ) - v_positionWorld.y );
	nodeVar41 = textureSample( nodeUniform14, nodeUniform14_sampler, vec2<f32>( ( ( nodeConst20 * 1.35 ) + 0.4 ), ( v_positionWorld.y * 0.42 ) ) );
	nodeVar42 = clamp( ( ( ( nodeConst19 * clamp( ( ( smoothstep( 0.0, 0.15, nodeConst26 ) * ( 1.0 - smoothstep( 0.15, 1.65, nodeConst26 ) ) ) * ( ( ( smoothstep( 0.3, 0.62, nodeConst24 ) * ( ( nodeConst23 * 0.45 ) + 0.55 ) ) * pow( sin( ( fract( nodeConst21 ) * 3.14159265 ) ), 2.0 ) ) * ( ( nodeConst24 * 0.45 ) + 0.8 ) ) ), 0.0, 1.0 ) ) * clamp( ( object.nodeUniform15.y * 2.2 ), 0.0, 1.15 ) ) * smoothstep( 0.3, 0.66, ( ( nodeVar40.w * 0.72 ) + ( nodeVar41.y * 0.38 ) ) ) ), 0.0, 1.0 );
	nodeVar42 = clamp( ( ( nodeVar42 * ( ( clamp( ( ( nodeVarying9.y * 1.5 ) + ( nodeVarying9.z * 0.6 ) ), 0.0, 1.0 ) * 0.75 ) + 0.45 ) ) + ( ( smoothstep( 0.58, 0.98, nodeVarying9.y ) * nodeConst19 ) * ( ( smoothstep( 0.2, 0.7, ( ( nodeVar40.w * 0.6 ) + ( nodeVar41.y * 0.55 ) ) ) * 0.45 ) + 0.55 ) ) ), 0.0, 1.0 );
	nodeVar42 = ( nodeVar42 * step( 0.0001, object.nodeUniform15.y ) );
	nodeVar43 = mix( nodeVar21.xyz, mix( mix( ( nodeVar21.xyz * vec3<f32>( 0.72 ) ), vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), 0.26 ), mix( ( nodeVar21.xyz * vec3<f32>( 0.94 ) ), vec3<f32>( 0.15292615198613213, 0.04231141061442144, 0.011612245176281512 ), 0.5 ), ( clamp( ( ( step( 0.86, nodeConst23 ) * 0.9 ) + ( nodeVar23.z * 0.5 ) ), 0.0, 1.0 ) * ( ( ( 1.0 - smoothstep( 0.1, 0.9, nodeConst26 ) ) * 0.7 ) + 0.3 ) ) ), nodeVar42 );
	nodeVar21.x = nodeVar43[ 0 ];
	nodeVar21.y = nodeVar43[ 1 ];
	nodeVar21.z = nodeVar43[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeVar42 * 0.09 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeVar42 * 0.35 ) ) );
	let nodeConst27 = ( v_positionWorld.y - object.nodeUniform16 );
	let nodeConst28 = ( 1.0 - smoothstep( 0.02, 0.22, nodeConst27 ) );
	let nodeConst29 = ( ( ( nodeConst19 * max( nodeConst28, ( pow( ( 1.0 - smoothstep( 0.1, max( object.nodeUniform15.z, 0.101 ), nodeConst27 ) ), 2.0 ) * 0.85 ) ) ) * step( 0.0001, object.nodeUniform15.z ) ) * ( ( smoothstep( 0.25, 0.72, ( ( nodeVar32.z * 0.7 ) + ( nodeVar33.y * 0.4 ) ) ) * 0.45 ) + 0.55 ) );
	nodeVar44 = mix( ( nodeVar21.xyz * vec3<f32>( ( 1.0 - ( nodeConst29 * 0.35 ) ) ) ), mix( vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), ( vec3<f32>( 0.14702726648767014, 0.11953842797895521, 0.08865558627723595 ) * vec3<f32>( 0.9 ) ), 0.35 ), ( nodeConst29 * 0.42 ) );
	nodeVar21.x = nodeVar44[ 0 ];
	nodeVar21.y = nodeVar44[ 1 ];
	nodeVar21.z = nodeVar44[ 2 ];
	nodeVar23.y = clamp( ( ( nodeVar23.y + ( nodeConst29 * 0.16 ) ) - ( ( ( nodeConst28 * nodeConst19 ) * 0.1 ) * step( 0.0001, object.nodeUniform15.z ) ) ), 0.0, 1.0 );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeConst29 * 0.18 ) ) );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst29 * 0.7 ) ) );
	let nodeConst30 = ( ( ( ( nodeVar32.x * 0.6 ) + ( nodeVar33.z * 0.7 ) ) * 0.18 ) + 0.26 );
	let nodeConst31 = ( clamp( ( pow( ( nodeConst19 * ( 1.0 - smoothstep( ( nodeConst30 * 0.25 ), nodeConst30, nodeConst27 ) ) ), 2.0 ) * ( ( smoothstep( 0.2, 0.8, nodeVar33.y ) * 0.5 ) + 0.7 ) ), 0.0, 1.0 ) * step( 0.0001, object.nodeUniform15.z ) );
	nodeVar45 = mix( nodeVar21.xyz, vec3<f32>( 0.14702726648767014, 0.11953842797895521, 0.08865558627723595 ), ( nodeConst31 * 0.46 ) );
	nodeVar21.x = nodeVar45[ 0 ];
	nodeVar21.y = nodeVar45[ 1 ];
	nodeVar21.z = nodeVar45[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst31 * 0.07 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst31 * 0.9 ) ) );
	let nodeConst32 = ( 1.0 - nodeVar29 );
	nodeVar46 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), ( pow( nodeConst32, 2.0 ) * object.nodeUniform15.w ) );
	nodeVar21.x = nodeVar46[ 0 ];
	nodeVar21.y = nodeVar46[ 1 ];
	nodeVar21.z = nodeVar46[ 2 ];
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( ( nodeConst32 * object.nodeUniform15.w ) * 0.5 ) ) );
	let nodeConst33 = clamp( ( ( ( nodeVarying9.x * 0.5 ) * ( ( smoothstep( 0.3, 0.8, nodeVar29 ) * 0.45 ) + 0.55 ) ) * ( ( smoothstep( 0.25, 0.85, ( ( nodeVar32.z * 0.65 ) + ( nodeVar33.w * 0.55 ) ) ) * 1.15 ) + 0.25 ) ), 0.0, 1.0 );
	nodeVar47 = mix( nodeVar21.xyz, vec3<f32>( 0.2746773120495699, 0.2874408377161099, 0.3049873140591091 ), ( nodeConst33 * 0.9 ) );
	nodeVar21.x = nodeVar47[ 0 ];
	nodeVar21.y = nodeVar47[ 1 ];
	nodeVar21.z = nodeVar47[ 2 ];
	nodeVar23.y = mix( nodeVar23.y, 0.3, nodeConst33 );
	nodeVar23.z = mix( nodeVar23.z, 1.0, nodeConst33 );
	let nodeConst34 = ( ( ( nodeVarying9.y * 0.7 ) * ( ( nodeConst32 * 0.65 ) + 0.35 ) ) * ( ( nodeVar33.y * 0.9 ) + 0.45 ) );
	nodeVar48 = mix( nodeVar21.xyz, vec3<f32>( 0.023153366173251363, 0.019382360952473074, 0.014443843592229466 ), ( nodeConst34 * 0.8 ) );
	nodeVar21.x = nodeVar48[ 0 ];
	nodeVar21.y = nodeVar48[ 1 ];
	nodeVar21.z = nodeVar48[ 2 ];
	nodeVar23.y = clamp( ( nodeVar23.y + ( nodeConst34 * 0.22 ) ), 0.0, 1.0 );
	nodeVar23.z = ( nodeVar23.z * ( 1.0 - ( nodeConst34 * 0.8 ) ) );
	nodeVar23.x = ( nodeVar23.x * ( 1.0 - ( nodeVarying9.z * 0.5 ) ) );
	nodeVar49 = ( nodeVar21.xyz * object.nodeUniform17 );
	nodeVar21.x = nodeVar49[ 0 ];
	nodeVar21.y = nodeVar49[ 1 ];
	nodeVar21.z = nodeVar49[ 2 ];
	nodeVar50 = StructType0( nodeVar21.xyz, nodeVar21.w, normalize( ( render.cameraViewMatrix * vec4<f32>( nodeVar26, 0.0 ) ).xyz ), clamp( ( ( nodeVar23.y * 0.92 ) + -0.03 ), 0.22, 1.0 ), clamp( nodeVar23.z, 0.0, 1.0 ), ( 1.0 + ( ( nodeVar23.x - 1.0 ) * 1.0 ) ) );
	DiffuseColor = ( vec4<f32>( vInstanceColor, 1.0 ) * vec4<f32>( nodeVar50.color, 1.0 ) );
	DiffuseColor.w = ( DiffuseColor.w * object.nodeUniform19 );
	DiffuseColor.w = 1.0;
	nodeVar51 = textureSample( nodeUniform20, nodeUniform20_sampler, ( object.nodeUniform21 * vec3<f32>( ( fragCoord.xy / render.nodeUniform22 ), 1.0 ) ).xy ).x;
	AmbientOcclusion = ( nodeVar50.ao * nodeVar51 );
	let nodeConst35 = ( nodeVar50.metal * object.nodeUniform23 );
	Metalness = nodeConst35;
	normalViewGeometry = normalize( v_normalViewGeometry );
	let nodeConst36 = max( abs( dpdx( normalViewGeometry ) ), abs( - dpdy( normalViewGeometry ) ) );
	Roughness = min( ( max( ( nodeVar50.rough * object.nodeUniform24 ), 0.045 ) + max( max( nodeConst36.x, nodeConst36.y ), nodeConst36.z ) ), 1.0 );
	SpecularColor = vec3<f32>( 0.04, 0.04, 0.04 );
	SpecularColorBlended = mix( vec3<f32>( 0.04, 0.04, 0.04 ), DiffuseColor.xyz, Metalness );
	SpecularF90 = 1.0;
	DiffuseContribution = ( DiffuseColor.xyz * vec3<f32>( ( 1.0 - nodeConst35 ) ) );
	EmissiveColor = ( object.nodeUniform25 * vec3<f32>( object.nodeUniform26 ) );
	normalView = nodeVar50.normal;
	positionViewDirection = normalize( v_positionViewDirection );
	nodeVar52 = textureSample( nodeUniform27, nodeUniform27_sampler, vec2<f32>( Roughness, clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ).xy;
	let dfg = nodeVar52;
	let multiScatteringCompensation = ( ( SpecularColorBlended * vec3<f32>( ( ( 1.0 / ( dfg.x + dfg.y ) ) - 1.0 ) ) ) + vec3<f32>( 1.0 ) );
	singleScatteringDielectric = vec3<f32>( 0.0, 0.0, 0.0 );
	multiScatteringDielectric = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst37 = ( ( SpecularColor * vec3<f32>( dfg.x ) ) + vec3<f32>( ( SpecularF90 * dfg.y ) ) );
	singleScatteringDielectric = ( singleScatteringDielectric + nodeConst37 );
	let nodeConst38 = ( SpecularColor + ( ( vec3<f32>( 1.0 ) - SpecularColor ) * vec3<f32>( 0.047619 ) ) );
	let nodeConst39 = ( 1.0 - ( dfg.x + dfg.y ) );
	multiScatteringDielectric = ( multiScatteringDielectric + ( ( ( nodeConst37 * nodeConst38 ) / ( vec3<f32>( 1.0 ) - ( vec3<f32>( nodeConst39 ) * nodeConst38 ) ) ) * vec3<f32>( nodeConst39 ) ) );
	directDiffuse = vec3<f32>( 0.0, 0.0, 0.0 );
	directSpecular = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst40 = normalize( ( render.cameraViewMatrix * vec4<f32>( ( owLightPositions.nodeUniform28 - owLightPositions.nodeUniform29 ), 0.0 ) ).xyz );
	shadowPositionWorld = v_positionWorld;
	shadowValue = vec4<f32>( 1.0, 1.0, 1.0, 1.0 );
	cascade = vec2<f32>( 0.0, 0.0 );
	cascade = cascades.value[ 0u ].xy;
	linearDepth = ( ( v_positionView.z + render.nodeUniform32 ) / ( render.nodeUniform32 - render.shadowFar ) );

	if ( ( ( linearDepth >= cascade.x ) && ( linearDepth <= cascade.y ) ) ) {

		shadowPositionWorld = v_positionWorld;
		normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
		let nodeConst41 = ( render.nodeUniform34 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform35 ) ) ), 1.0 ) );
		let nodeConst42 = ( nodeConst41.xyz / vec3<f32>( nodeConst41.w ) );
		normalWorldGeometry = normalize( v_normalWorldGeometry );
		nodeVar54 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform28 - owLightPositions.nodeUniform29 ) ) ) ), 0.12, 1.0 );
		let nodeConst43 = vec3<f32>( nodeConst42.x, ( 1.0 - nodeConst42.y ), ( nodeConst42.z + ( render.nodeUniform36 - ( ( ( ( render.nodeUniform37 - render.nodeUniform38 ) / render.nodeUniform39.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar54 * nodeVar54 ) ) ) ) / nodeVar54 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform40 - render.nodeUniform41 ), 1.0 ) ) ) ) );

		if ( ( ( ( ( ( nodeConst43.x >= 0.0 ) && ( nodeConst43.x <= 1.0 ) ) && ( nodeConst43.y >= 0.0 ) ) && ( nodeConst43.y <= 1.0 ) ) && ( nodeConst43.z <= 1.0 ) ) ) {

			let nodeConst44 = ( fn28( fragCoord.xy ) * 6.28318530718 );
			let nodeConst45 = ( render.nodeUniform43 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform44 ).x );
			let nodeConst46 = ( nodeConst43.xy + ( fn29( 0, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
			nodeVar55 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst46, nodeConst43.z );
			let nodeConst47 = ( nodeConst43.xy + ( fn29( 1, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
			nodeVar56 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst47, nodeConst43.z );
			let nodeConst48 = ( nodeConst43.xy + ( fn29( 2, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
			nodeVar57 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst48, nodeConst43.z );
			let nodeConst49 = ( nodeConst43.xy + ( fn29( 3, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
			nodeVar58 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst49, nodeConst43.z );
			let nodeConst50 = ( nodeConst43.xy + ( fn29( 4, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
			nodeVar59 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst50, nodeConst43.z );
			nodeVar53 = ( ( ( ( ( nodeVar55 + nodeVar56 ) + nodeVar57 ) + nodeVar58 ) + nodeVar59 ) * 0.2 );

		} else {

			nodeVar53 = 1.0;

		}

		nodeVar60 = mix( 1.0, nodeVar53, render.nodeUniform45 );
		shadowValue = vec4<f32>( nodeVar60 );
		

	}

	cascade = cascades.value[ 1u ].xy;

	if ( ( ( linearDepth >= cascade.x ) && ( linearDepth <= cascade.y ) ) ) {

		shadowPositionWorld = v_positionWorld;
		normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
		let nodeConst51 = ( render.nodeUniform46 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform47 ) ) ), 1.0 ) );
		let nodeConst52 = ( nodeConst51.xyz / vec3<f32>( nodeConst51.w ) );
		normalWorldGeometry = normalize( v_normalWorldGeometry );
		nodeVar62 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform28 - owLightPositions.nodeUniform29 ) ) ) ), 0.12, 1.0 );
		let nodeConst53 = vec3<f32>( nodeConst52.x, ( 1.0 - nodeConst52.y ), ( nodeConst52.z + ( render.nodeUniform48 - ( ( ( ( render.nodeUniform49 - render.nodeUniform50 ) / render.nodeUniform51.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar62 * nodeVar62 ) ) ) ) / nodeVar62 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform52 - render.nodeUniform53 ), 1.0 ) ) ) ) );

		if ( ( ( ( ( ( nodeConst53.x >= 0.0 ) && ( nodeConst53.x <= 1.0 ) ) && ( nodeConst53.y >= 0.0 ) ) && ( nodeConst53.y <= 1.0 ) ) && ( nodeConst53.z <= 1.0 ) ) ) {

			let nodeConst54 = ( fn28( fragCoord.xy ) * 6.28318530718 );
			let nodeConst55 = ( render.nodeUniform55 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform56 ).x );
			let nodeConst56 = ( nodeConst53.xy + ( fn29( 0, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
			nodeVar63 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst56, nodeConst53.z );
			let nodeConst57 = ( nodeConst53.xy + ( fn29( 1, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
			nodeVar64 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst57, nodeConst53.z );
			let nodeConst58 = ( nodeConst53.xy + ( fn29( 2, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
			nodeVar65 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst58, nodeConst53.z );
			let nodeConst59 = ( nodeConst53.xy + ( fn29( 3, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
			nodeVar66 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst59, nodeConst53.z );
			let nodeConst60 = ( nodeConst53.xy + ( fn29( 4, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
			nodeVar67 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst60, nodeConst53.z );
			nodeVar61 = ( ( ( ( ( nodeVar63 + nodeVar64 ) + nodeVar65 ) + nodeVar66 ) + nodeVar67 ) * 0.2 );

		} else {

			nodeVar61 = 1.0;

		}

		nodeVar68 = mix( 1.0, nodeVar61, render.nodeUniform57 );
		shadowValue = vec4<f32>( nodeVar68 );
		

	}

	cascade = cascades.value[ 2u ].xy;

	if ( ( ( linearDepth >= cascade.x ) && ( linearDepth <= cascade.y ) ) ) {

		shadowPositionWorld = v_positionWorld;
		normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
		let nodeConst61 = ( render.nodeUniform58 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform59 ) ) ), 1.0 ) );
		let nodeConst62 = ( nodeConst61.xyz / vec3<f32>( nodeConst61.w ) );
		normalWorldGeometry = normalize( v_normalWorldGeometry );
		nodeVar70 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform28 - owLightPositions.nodeUniform29 ) ) ) ), 0.12, 1.0 );
		let nodeConst63 = vec3<f32>( nodeConst62.x, ( 1.0 - nodeConst62.y ), ( nodeConst62.z + ( render.nodeUniform60 - ( ( ( ( render.nodeUniform61 - render.nodeUniform62 ) / render.nodeUniform63.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar70 * nodeVar70 ) ) ) ) / nodeVar70 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform64 - render.nodeUniform65 ), 1.0 ) ) ) ) );

		if ( ( ( ( ( ( nodeConst63.x >= 0.0 ) && ( nodeConst63.x <= 1.0 ) ) && ( nodeConst63.y >= 0.0 ) ) && ( nodeConst63.y <= 1.0 ) ) && ( nodeConst63.z <= 1.0 ) ) ) {

			let nodeConst64 = ( fn28( fragCoord.xy ) * 6.28318530718 );
			let nodeConst65 = ( render.nodeUniform67 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform68 ).x );
			let nodeConst66 = ( nodeConst63.xy + ( fn29( 0, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar71 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst66, nodeConst63.z );
			let nodeConst67 = ( nodeConst63.xy + ( fn29( 1, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar72 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst67, nodeConst63.z );
			let nodeConst68 = ( nodeConst63.xy + ( fn29( 2, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar73 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst68, nodeConst63.z );
			let nodeConst69 = ( nodeConst63.xy + ( fn29( 3, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar74 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst69, nodeConst63.z );
			let nodeConst70 = ( nodeConst63.xy + ( fn29( 4, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
			nodeVar75 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst70, nodeConst63.z );
			nodeVar69 = ( ( ( ( ( nodeVar71 + nodeVar72 ) + nodeVar73 ) + nodeVar74 ) + nodeVar75 ) * 0.2 );

		} else {

			nodeVar69 = 1.0;

		}

		nodeVar76 = mix( 1.0, nodeVar69, render.nodeUniform69 );
		shadowValue = vec4<f32>( nodeVar76 );
		

	}

	nodeVar77 = ( vec4<f32>( clamp( dot( normalView, nodeConst40 ), 0.0, 1.0 ) ) * ( vec4<f32>( render.nodeUniform30, 1.0 ) * shadowValue ) );
	let nodeConst71 = clamp( dot( positionViewDirection, normalize( ( nodeConst40 + positionViewDirection ) ) ), 0.0, 1.0 );
	let nodeConst72 = exp2( ( ( ( nodeConst71 * -5.55473 ) - 6.98316 ) * nodeConst71 ) );
	directDiffuse = ( vec4<f32>( directDiffuse, 1.0 ) + ( ( nodeVar77 * vec4<f32>( ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ), 1.0 ) ) * vec4<f32>( ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst72 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst72 ) ) ) ), 1.0 ) ) ).xyz;
	let nodeConst73 = normalize( ( nodeConst40 + positionViewDirection ) );
	let nodeConst74 = clamp( dot( positionViewDirection, nodeConst73 ), 0.0, 1.0 );
	let nodeConst75 = exp2( ( ( ( nodeConst74 * -5.55473 ) - 6.98316 ) * nodeConst74 ) );
	let nodeConst76 = max( Roughness, 0.045 );
	let nodeConst77 = ( nodeConst76 * nodeConst76 );
	directSpecular = ( vec4<f32>( directSpecular, 1.0 ) + ( ( nodeVar77 * vec4<f32>( ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst75 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst75 ) ) ) * vec3<f32>( fn10( nodeConst77, clamp( dot( normalView, nodeConst40 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst77, clamp( dot( normalView, nodeConst73 ), 0.0, 1.0 ) ) ) ), 1.0 ) ) * vec4<f32>( multiScatteringCompensation, 1.0 ) ) ).xyz;
	let nodeConst78 = normalize( ( render.cameraViewMatrix * vec4<f32>( ( owLightPositions.nodeUniform70 - owLightPositions.nodeUniform71 ), 0.0 ) ).xyz );
	nodeVar78 = ( vec3<f32>( clamp( dot( normalView, nodeConst78 ), 0.0, 1.0 ) ) * render.nodeUniform72 );
	let nodeConst79 = clamp( dot( positionViewDirection, normalize( ( nodeConst78 + positionViewDirection ) ) ), 0.0, 1.0 );
	let nodeConst80 = exp2( ( ( ( nodeConst79 * -5.55473 ) - 6.98316 ) * nodeConst79 ) );
	directDiffuse = ( directDiffuse + ( ( nodeVar78 * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst80 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst80 ) ) ) ) ) );
	let nodeConst81 = normalize( ( nodeConst78 + positionViewDirection ) );
	let nodeConst82 = clamp( dot( positionViewDirection, nodeConst81 ), 0.0, 1.0 );
	let nodeConst83 = exp2( ( ( ( nodeConst82 * -5.55473 ) - 6.98316 ) * nodeConst82 ) );
	let nodeConst84 = max( Roughness, 0.045 );
	let nodeConst85 = ( nodeConst84 * nodeConst84 );
	directSpecular = ( directSpecular + ( ( nodeVar78 * ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst83 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst83 ) ) ) * vec3<f32>( fn10( nodeConst85, clamp( dot( normalView, nodeConst78 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst85, clamp( dot( normalView, nodeConst81 ), 0.0, 1.0 ) ) ) ) ) * multiScatteringCompensation ) );
	let nodeConst86 = ( render.nodeUniform73 - v_positionView );
	let nodeConst87 = normalize( nodeConst86 );
	shadowPositionWorld = v_positionWorld;
	normalWorld = normalize( ( vec4<f32>( normalView, 0.0 ) * render.cameraViewMatrix ).xyz );
	let nodeConst88 = ( render.nodeUniform75 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform76 ) ) ), 1.0 ) );
	let nodeConst89 = ( nodeConst88.xyz / vec3<f32>( nodeConst88.w ) );
	let nodeConst90 = vec3<f32>( nodeConst89.x, ( 1.0 - nodeConst89.y ), ( nodeConst89.z + render.nodeUniform77 ) );

	if ( ( ( ( ( ( nodeConst90.x >= 0.0 ) && ( nodeConst90.x <= 1.0 ) ) && ( nodeConst90.y >= 0.0 ) ) && ( nodeConst90.y <= 1.0 ) ) && ( nodeConst90.z <= 1.0 ) ) ) {

		let nodeConst91 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst92 = ( vec2<f32>( render.nodeUniform79 ) * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform80 ) );
		let nodeConst93 = ( nodeConst90.xy + ( fn29( 0, 5, nodeConst91 ) * nodeConst92 ) );
		nodeVar80 = textureSampleCompare( nodeUniform78, nodeUniform78_sampler, nodeConst93, nodeConst90.z );
		let nodeConst94 = ( nodeConst90.xy + ( fn29( 1, 5, nodeConst91 ) * nodeConst92 ) );
		nodeVar81 = textureSampleCompare( nodeUniform78, nodeUniform78_sampler, nodeConst94, nodeConst90.z );
		let nodeConst95 = ( nodeConst90.xy + ( fn29( 2, 5, nodeConst91 ) * nodeConst92 ) );
		nodeVar82 = textureSampleCompare( nodeUniform78, nodeUniform78_sampler, nodeConst95, nodeConst90.z );
		let nodeConst96 = ( nodeConst90.xy + ( fn29( 3, 5, nodeConst91 ) * nodeConst92 ) );
		nodeVar83 = textureSampleCompare( nodeUniform78, nodeUniform78_sampler, nodeConst96, nodeConst90.z );
		let nodeConst97 = ( nodeConst90.xy + ( fn29( 4, 5, nodeConst91 ) * nodeConst92 ) );
		nodeVar84 = textureSampleCompare( nodeUniform78, nodeUniform78_sampler, nodeConst97, nodeConst90.z );
		nodeVar79 = ( ( ( ( ( nodeVar80 + nodeVar81 ) + nodeVar82 ) + nodeVar83 ) + nodeVar84 ) * 0.2 );

	} else {

		nodeVar79 = 1.0;

	}

	nodeVar85 = mix( 1.0, nodeVar79, render.nodeUniform81 );
	nodeVar86 = ( vec3<f32>( clamp( dot( normalView, nodeConst87 ), 0.0, 1.0 ) ) * ( ( ( render.nodeUniform74 * vec3<f32>( nodeVar85 ) ) * vec3<f32>( smoothstep( render.nodeUniform82, render.nodeUniform83, dot( nodeConst87, normalize( ( render.cameraViewMatrix * vec4<f32>( ( owLightPositions.nodeUniform84 - owLightPositions.nodeUniform85 ), 0.0 ) ).xyz ) ) ) ) ) * vec3<f32>( fn38( length( nodeConst86 ), render.nodeUniform86, render.nodeUniform87 ) ) ) );
	let nodeConst98 = clamp( dot( positionViewDirection, normalize( ( nodeConst87 + positionViewDirection ) ) ), 0.0, 1.0 );
	let nodeConst99 = exp2( ( ( ( nodeConst98 * -5.55473 ) - 6.98316 ) * nodeConst98 ) );
	directDiffuse = ( directDiffuse + ( ( nodeVar86 * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst99 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst99 ) ) ) ) ) );
	let nodeConst100 = normalize( ( nodeConst87 + positionViewDirection ) );
	let nodeConst101 = clamp( dot( positionViewDirection, nodeConst100 ), 0.0, 1.0 );
	let nodeConst102 = exp2( ( ( ( nodeConst101 * -5.55473 ) - 6.98316 ) * nodeConst101 ) );
	let nodeConst103 = max( Roughness, 0.045 );
	let nodeConst104 = ( nodeConst103 * nodeConst103 );
	directSpecular = ( directSpecular + ( ( nodeVar86 * ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst102 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst102 ) ) ) * vec3<f32>( fn10( nodeConst104, clamp( dot( normalView, nodeConst87 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst104, clamp( dot( normalView, nodeConst100 ), 0.0, 1.0 ) ) ) ) ) * multiScatteringCompensation ) );
	radiance = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst105 = normalize( ( render.cameraWorldMatrix * vec4<f32>( normalize( mix( reflect( ( - positionViewDirection ), normalView ), normalView, ( ( ( Roughness * Roughness ) * Roughness ) * Roughness ) ) ), 0.0 ) ).xyz );
	let nodeConst106 = ( object.nodeUniform89 * vec4<f32>( nodeConst105, 1.0 ) );
	let nodeConst107 = clamp( Roughness, 0.0, 1.0 );
	nodeVar87 = textureSampleLevel( nodeUniform88, nodeUniform88_sampler, vec3<f32>( ( - nodeConst106.x ), nodeConst106.yz ), ( ( object.nodeUniform91 * nodeConst107 ) * ( 2.0 - nodeConst107 ) ) );
	radiance = ( radiance + ( nodeVar87.xyz * vec3<f32>( object.nodeUniform92 ) ) );
	iblIrradiance = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst108 = ( object.nodeUniform89 * vec4<f32>( normalWorld, 1.0 ) );
	let nodeConst109 = clamp( 1.0, 0.0, 1.0 );
	nodeVar88 = textureSampleLevel( nodeUniform88, nodeUniform88_sampler, vec3<f32>( ( - nodeConst108.x ), nodeConst108.yz ), ( ( object.nodeUniform91 * nodeConst109 ) * ( 2.0 - nodeConst109 ) ) );
	iblIrradiance = ( iblIrradiance + ( ( nodeVar88.xyz * vec3<f32>( 3.141592653589793 ) ) * vec3<f32>( object.nodeUniform92 ) ) );
	nodeVar89 = 0.0;

	for ( var i : i32 = 0; i < 10; i ++ ) {


		if ( ( i >= object.nodeUniform94 ) ) {

			break;
			

		}

		nodeVar89 = max( nodeVar89, smoothstep( 0.06, 0.3, min( min( ( nodeUniform95.value[ i ].z - abs( ( ( ( ( v_positionWorld.x * object.nodeUniform96.x ) + ( v_positionWorld.z * object.nodeUniform96.y ) ) + object.nodeUniform96.z ) - nodeUniform95.value[ i ].x ) ) ), ( nodeUniform95.value[ i ].w - abs( ( ( ( ( v_positionWorld.z * object.nodeUniform96.x ) - ( v_positionWorld.x * object.nodeUniform96.y ) ) + object.nodeUniform96.w ) - nodeUniform95.value[ i ].y ) ) ) ), min( ( v_positionWorld.y - nodeUniform97.value[ i ].x ), ( nodeUniform97.value[ i ].y - v_positionWorld.y ) ) ) ) );

	}

	ambientOcclusion = 1.0;
	let nodeConst110 = mix( 0.035, 1.0, clamp( min( ( 1.0 - nodeVar89 ), mix( 1.0, smoothstep( 0.45, 0.98, ambientOcclusion ), 0.6 ) ), 0.0, 1.0 ) );
	iblIrradiance = ( iblIrradiance * vec3<f32>( ( render.nodeUniform93 * nodeConst110 ) ) );
	irradiance = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst111 = clamp( normalWorld.y, -1.0, 1.0 );
	irradiance = ( irradiance + ( ( ( ( render.nodeUniform98 * vec3<f32>( smoothstep( -0.95, 0.85, nodeConst111 ) ) ) + ( render.nodeUniform99 * vec3<f32>( ( smoothstep( -0.05, 0.7, ( - nodeConst111 ) ) + ( clamp( ( ( dot( normalWorld, normalize( vec3<f32>( ( ( - render.nodeUniform100.x ) + 0.0001 ), 0.28, ( ( - render.nodeUniform100.z ) + 0.0001 ) ) ) ) + 0.12 ) / 1.12 ), 0.0, 1.0 ) * 0.6153846153846154 ) ) ) ) ) * vec3<f32>( nodeConst110 ) ) * vec3<f32>( sqrt( max( ambientOcclusion, 0.0 ) ) ) ) );
	ambientOcclusion = ( ambientOcclusion * AmbientOcclusion );

	for ( var i : i32 = 0; i < 64; i ++ ) {

		let nodeConst112 = floor( ( fragCoord.xy / vec2<f32>( 32.0 ) ) );
		let nodeConst113 = i32( object.nodeUniform102.x );
		nodeVar90 = ( ( i32( nodeConst112.x ) + ( i32( nodeConst112.y ) * nodeConst113 ) ) + ( i32( clamp( floor( ( ( log( ( ( - v_positionView.z ) / render.clusteredCameraNear ) ) * ( 1.0 / log( ( render.clusteredCameraFar / render.clusteredCameraNear ) ) ) ) * 24.0 ) ), 0.0, 23.0 ) ) * ( nodeConst113 * i32( object.nodeUniform102.y ) ) ) );
		let nodeConst114 = i;

		if ( ( lightIndexes.value[ ( ( nodeVar90 * 16 ) + ( nodeConst114 / 4 ) ) ][ ( nodeConst114 % 4 ) ] == 0 ) ) {

			break;
			

		}

		let nodeConst115 = ( lightIndexes.value[ ( ( nodeVar90 * 16 ) + ( nodeConst114 / 4 ) ) ][ ( nodeConst114 % 4 ) ] - 1 );
		nodeVar91 = textureLoad( nodeUniform106, vec2<i32>( nodeConst115, i32( 0.0 ) ), u32( 0u ) );
		let nodeConst116 = ( ( render.clusteredCameraViewMatrix * vec4<f32>( nodeVar91.xyz, 1.0 ) ).xyz - v_positionView );
		nodeVar92 = textureLoad( nodeUniform106, vec2<i32>( nodeConst115, i32( 2.0 ) ), u32( 0u ) );
		nodeVar93 = smoothstep( 0.0, 1.0, ( dot( normalize( nodeConst116 ), ( render.clusteredCameraViewMatrix * vec4<f32>( nodeVar92.xyz, 0.0 ) ).xyz ) - nodeVar92.w ) );

		if ( ( ( ( nodeVar91.w == 0.0 ) || ( dot( nodeConst116, nodeConst116 ) <= ( nodeVar91.w * nodeVar91.w ) ) ) && ( nodeVar93 > 0.0 ) ) ) {

			let nodeConst117 = normalize( nodeConst116 );
			nodeVar94 = textureLoad( nodeUniform106, vec2<i32>( nodeConst115, i32( 1.0 ) ), u32( 0u ) );
			nodeVar95 = ( vec3<f32>( clamp( dot( normalView, nodeConst117 ), 0.0, 1.0 ) ) * ( ( nodeVar94.xyz * vec3<f32>( nodeVar93 ) ) * vec3<f32>( fn38( length( nodeConst116 ), nodeVar91.w, nodeVar94.w ) ) ) );
			let nodeConst118 = clamp( dot( positionViewDirection, normalize( ( nodeConst117 + positionViewDirection ) ) ), 0.0, 1.0 );
			let nodeConst119 = exp2( ( ( ( nodeConst118 * -5.55473 ) - 6.98316 ) * nodeConst118 ) );
			directDiffuse = ( directDiffuse + ( ( nodeVar95 * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( ( SpecularColor * vec3<f32>( ( 1.0 - nodeConst119 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst119 ) ) ) ) ) );
			let nodeConst120 = normalize( ( nodeConst117 + positionViewDirection ) );
			let nodeConst121 = clamp( dot( positionViewDirection, nodeConst120 ), 0.0, 1.0 );
			let nodeConst122 = exp2( ( ( ( nodeConst121 * -5.55473 ) - 6.98316 ) * nodeConst121 ) );
			let nodeConst123 = max( Roughness, 0.045 );
			let nodeConst124 = ( nodeConst123 * nodeConst123 );
			directSpecular = ( directSpecular + ( ( nodeVar95 * ( ( ( ( SpecularColorBlended * vec3<f32>( ( 1.0 - nodeConst122 ) ) ) + vec3<f32>( ( SpecularF90 * nodeConst122 ) ) ) * vec3<f32>( fn10( nodeConst124, clamp( dot( normalView, nodeConst117 ), 0.0, 1.0 ), clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) ) ) ) * vec3<f32>( fn12( nodeConst124, clamp( dot( normalView, nodeConst120 ), 0.0, 1.0 ) ) ) ) ) * multiScatteringCompensation ) );
			

		}


	}

	nodeVar96 = ( ( irradiance * ( DiffuseContribution * vec3<f32>( 0.3183098861837907 ) ) ) * ( vec3<f32>( 1.0 ) - ( singleScatteringDielectric + multiScatteringDielectric ) ) );
	indirectDiffuse = vec3<f32>( 0.0, 0.0, 0.0 );
	indirectDiffuse = ( indirectDiffuse + nodeVar96 );
	singleScatteringMetallic = vec3<f32>( 0.0, 0.0, 0.0 );
	multiScatteringMetallic = vec3<f32>( 0.0, 0.0, 0.0 );
	let nodeConst125 = ( ( DiffuseColor.xyz * vec3<f32>( dfg.x ) ) + vec3<f32>( ( SpecularF90 * dfg.y ) ) );
	singleScatteringMetallic = ( singleScatteringMetallic + nodeConst125 );
	let nodeConst126 = ( DiffuseColor.xyz + ( ( vec3<f32>( 1.0 ) - DiffuseColor.xyz ) * vec3<f32>( 0.047619 ) ) );
	let nodeConst127 = ( 1.0 - ( dfg.x + dfg.y ) );
	multiScatteringMetallic = ( multiScatteringMetallic + ( ( ( nodeConst125 * nodeConst126 ) / ( vec3<f32>( 1.0 ) - ( vec3<f32>( nodeConst127 ) * nodeConst126 ) ) ) * vec3<f32>( nodeConst127 ) ) );
	let nodeConst128 = ( iblIrradiance * vec3<f32>( 0.3183098861837907 ) );
	nodeVar97 = ( ( radiance * mix( singleScatteringDielectric, singleScatteringMetallic, Metalness ) ) + ( mix( multiScatteringDielectric, multiScatteringMetallic, Metalness ) * nodeConst128 ) );
	nodeVar98 = ( ( DiffuseContribution * ( vec3<f32>( 1.0 ) - ( singleScatteringDielectric + multiScatteringDielectric ) ) ) * nodeConst128 );
	indirectSpecular = vec3<f32>( 0.0, 0.0, 0.0 );
	indirectSpecular = ( indirectSpecular + nodeVar97 );
	indirectDiffuse = ( indirectDiffuse + nodeVar98 );
	indirectDiffuse = ( indirectDiffuse * vec3<f32>( ambientOcclusion ) );
	indirectSpecular = ( indirectSpecular * vec3<f32>( clamp( ( ambientOcclusion - ( 1.0 - pow( ( clamp( dot( normalView, positionViewDirection ), 0.0, 1.0 ) + ambientOcclusion ), exp2( ( - ( 1.0 - ( Roughness * -16.0 ) ) ) ) ) ) ), 0.0, 1.0 ) ) );
	totalDiffuse = ( directDiffuse + indirectDiffuse );
	totalSpecular = ( directSpecular + indirectSpecular );
	outgoingLight = ( totalDiffuse + totalSpecular );
	let nodeConst129 = max( vec4<f32>( ( outgoingLight + EmissiveColor ), DiffuseColor.w ), vec4<f32>( 0.0 ) );
	Output = nodeConst129;
	let nodeConst41 = ( render.nodeUniform34 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform35 ) ) ), 1.0 ) );
	let nodeConst42 = ( nodeConst41.xyz / vec3<f32>( nodeConst41.w ) );
	normalWorldGeometry = normalize( v_normalWorldGeometry );
	nodeVar54 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform28 - owLightPositions.nodeUniform29 ) ) ) ), 0.12, 1.0 );
	let nodeConst43 = vec3<f32>( nodeConst42.x, ( 1.0 - nodeConst42.y ), ( nodeConst42.z + ( render.nodeUniform36 - ( ( ( ( render.nodeUniform37 - render.nodeUniform38 ) / render.nodeUniform39.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar54 * nodeVar54 ) ) ) ) / nodeVar54 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform40 - render.nodeUniform41 ), 1.0 ) ) ) ) );

	if ( ( ( ( ( ( nodeConst43.x >= 0.0 ) && ( nodeConst43.x <= 1.0 ) ) && ( nodeConst43.y >= 0.0 ) ) && ( nodeConst43.y <= 1.0 ) ) && ( nodeConst43.z <= 1.0 ) ) ) {

		let nodeConst44 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst45 = ( render.nodeUniform43 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform44 ).x );
		let nodeConst46 = ( nodeConst43.xy + ( fn29( 0, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
		nodeVar55 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst46, nodeConst43.z );
		let nodeConst47 = ( nodeConst43.xy + ( fn29( 1, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
		nodeVar56 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst47, nodeConst43.z );
		let nodeConst48 = ( nodeConst43.xy + ( fn29( 2, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
		nodeVar57 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst48, nodeConst43.z );
		let nodeConst49 = ( nodeConst43.xy + ( fn29( 3, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
		nodeVar58 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst49, nodeConst43.z );
		let nodeConst50 = ( nodeConst43.xy + ( fn29( 4, 5, nodeConst44 ) * vec2<f32>( nodeConst45 ) ) );
		nodeVar59 = textureSampleCompare( nodeUniform42, nodeUniform42_sampler, nodeConst50, nodeConst43.z );
		nodeVar99 = ( ( ( ( ( nodeVar55 + nodeVar56 ) + nodeVar57 ) + nodeVar58 ) + nodeVar59 ) * 0.2 );

	} else {

		nodeVar99 = 1.0;

	}

	nodeVar60 = mix( 1.0, nodeVar99, render.nodeUniform45 );
	let nodeConst51 = ( render.nodeUniform46 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform47 ) ) ), 1.0 ) );
	let nodeConst52 = ( nodeConst51.xyz / vec3<f32>( nodeConst51.w ) );
	nodeVar62 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform28 - owLightPositions.nodeUniform29 ) ) ) ), 0.12, 1.0 );
	let nodeConst53 = vec3<f32>( nodeConst52.x, ( 1.0 - nodeConst52.y ), ( nodeConst52.z + ( render.nodeUniform48 - ( ( ( ( render.nodeUniform49 - render.nodeUniform50 ) / render.nodeUniform51.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar62 * nodeVar62 ) ) ) ) / nodeVar62 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform52 - render.nodeUniform53 ), 1.0 ) ) ) ) );

	if ( ( ( ( ( ( nodeConst53.x >= 0.0 ) && ( nodeConst53.x <= 1.0 ) ) && ( nodeConst53.y >= 0.0 ) ) && ( nodeConst53.y <= 1.0 ) ) && ( nodeConst53.z <= 1.0 ) ) ) {

		let nodeConst54 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst55 = ( render.nodeUniform55 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform56 ).x );
		let nodeConst56 = ( nodeConst53.xy + ( fn29( 0, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
		nodeVar63 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst56, nodeConst53.z );
		let nodeConst57 = ( nodeConst53.xy + ( fn29( 1, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
		nodeVar64 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst57, nodeConst53.z );
		let nodeConst58 = ( nodeConst53.xy + ( fn29( 2, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
		nodeVar65 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst58, nodeConst53.z );
		let nodeConst59 = ( nodeConst53.xy + ( fn29( 3, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
		nodeVar66 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst59, nodeConst53.z );
		let nodeConst60 = ( nodeConst53.xy + ( fn29( 4, 5, nodeConst54 ) * vec2<f32>( nodeConst55 ) ) );
		nodeVar67 = textureSampleCompare( nodeUniform54, nodeUniform54_sampler, nodeConst60, nodeConst53.z );
		nodeVar100 = ( ( ( ( ( nodeVar63 + nodeVar64 ) + nodeVar65 ) + nodeVar66 ) + nodeVar67 ) * 0.2 );

	} else {

		nodeVar100 = 1.0;

	}

	nodeVar68 = mix( 1.0, nodeVar100, render.nodeUniform57 );
	let nodeConst61 = ( render.nodeUniform58 * vec4<f32>( ( shadowPositionWorld + ( normalWorld * vec3<f32>( render.nodeUniform59 ) ) ), 1.0 ) );
	let nodeConst62 = ( nodeConst61.xyz / vec3<f32>( nodeConst61.w ) );
	nodeVar70 = clamp( abs( dot( normalWorldGeometry, normalize( ( owLightPositions.nodeUniform28 - owLightPositions.nodeUniform29 ) ) ) ), 0.12, 1.0 );
	let nodeConst63 = vec3<f32>( nodeConst62.x, ( 1.0 - nodeConst62.y ), ( nodeConst62.z + ( render.nodeUniform60 - ( ( ( ( render.nodeUniform61 - render.nodeUniform62 ) / render.nodeUniform63.x ) * ( ( min( ( sqrt( max( 0.0, ( 1.0 - ( nodeVar70 * nodeVar70 ) ) ) ) / nodeVar70 ), 5.0 ) * 1.5 ) + 0.5 ) ) / max( ( render.nodeUniform64 - render.nodeUniform65 ), 1.0 ) ) ) ) );

	if ( ( ( ( ( ( nodeConst63.x >= 0.0 ) && ( nodeConst63.x <= 1.0 ) ) && ( nodeConst63.y >= 0.0 ) ) && ( nodeConst63.y <= 1.0 ) ) && ( nodeConst63.z <= 1.0 ) ) ) {

		let nodeConst64 = ( fn28( fragCoord.xy ) * 6.28318530718 );
		let nodeConst65 = ( render.nodeUniform67 * ( vec2<f32>( 1.0, 1.0 ) / render.nodeUniform68 ).x );
		let nodeConst66 = ( nodeConst63.xy + ( fn29( 0, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar71 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst66, nodeConst63.z );
		let nodeConst67 = ( nodeConst63.xy + ( fn29( 1, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar72 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst67, nodeConst63.z );
		let nodeConst68 = ( nodeConst63.xy + ( fn29( 2, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar73 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst68, nodeConst63.z );
		let nodeConst69 = ( nodeConst63.xy + ( fn29( 3, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar74 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst69, nodeConst63.z );
		let nodeConst70 = ( nodeConst63.xy + ( fn29( 4, 5, nodeConst64 ) * vec2<f32>( nodeConst65 ) ) );
		nodeVar75 = textureSampleCompare( nodeUniform66, nodeUniform66_sampler, nodeConst70, nodeConst63.z );
		nodeVar101 = ( ( ( ( ( nodeVar71 + nodeVar72 ) + nodeVar73 ) + nodeVar74 ) + nodeVar75 ) * 0.2 );

	} else {

		nodeVar101 = 1.0;

	}

	nodeVar76 = mix( 1.0, nodeVar101, render.nodeUniform69 );
	let nodeConst112 = floor( ( fragCoord.xy / vec2<f32>( 32.0 ) ) );
	let nodeConst113 = i32( object.nodeUniform102.x );
	nodeVar90 = ( ( i32( nodeConst112.x ) + ( i32( nodeConst112.y ) * nodeConst113 ) ) + ( i32( clamp( floor( ( ( log( ( ( - v_positionView.z ) / render.clusteredCameraNear ) ) * ( 1.0 / log( ( render.clusteredCameraFar / render.clusteredCameraNear ) ) ) ) * 24.0 ) ), 0.0, 23.0 ) ) * ( nodeConst113 * i32( object.nodeUniform102.y ) ) ) );

	// result

	output.color = nodeConst129;

	return output;

}
