import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync, mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
const { PNG } = createRequire(resolve('package.json'))('pngjs');
const read = name => JSON.parse(readFileSync(resolve(root, name + '.json')));
const hash = text => createHash('sha256').update(text).digest('hex');
const median = values => [...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];
const sum = (rows, key) => rows.reduce((n,r)=>n+(r[key]??0),0);
const baseline = read('census-2').refreshCensus, candidate = read('shadow-color-census').refreshCensus;
for (const census of [baseline,candidate]) {
  assert.deepEqual(census.errors, []);
  assert.equal(census.frames.length, 1800);
  assert(census.frames.every(f=>!f.unknown && f.decisions===f.draws));
}
const censusSummary = c => ({
  frames:c.frames.length,
  totalDecisions:sum(c.rows,'calls'),
  refreshCounts:Object.fromEntries([0,1,2].map(type=>[type,c.rows.filter(r=>r.type===type).reduce((n,r)=>n+r.calls,0)])),
  p50:Object.fromEntries(['objects','renderObjects','draws','passCalls','writes','writeBytes'].map(key=>[key,median(c.frames.map(f=>f[key]))])),
  mean:Object.fromEntries(['groups','bindings','scopeChecks','writes','writeBytes'].map(key=>[key,sum(c.rows,key)/1800])),
  staticShadowVisits:c.rows.filter(r=>r.shadow&&r.category.startsWith('static-')).reduce((n,r)=>n+r.calls,0),
  staticShadowSourceMaterials:[...new Set(c.rows.filter(r=>r.shadow&&r.category.startsWith('static-')).map(r=>r.sourceMaterial.nativeId))],
  reasons:c.rows.reduce((out,r)=>{const key=[r.type,r.reason,r.nodeCause,r.exit,r.flags].join('|');out[key]=(out[key]??0)+r.calls;return out},{}),
});
mkdirSync(resolve(root,'shaders'),{recursive:true});
const specimens=baseline.specimens.map(a=>{
  const b=candidate.specimens.find(b=>b.key===a.key);assert(b);
  for(const [label,s]of [['base',a],['candidate',b]])for(const [stage,key]of [['vert','vertexShader'],['frag','fragmentShader']])writeFileSync(resolve(root,'shaders',`${label}-${a.key.replaceAll('/','-')}.${stage}.wgsl`),s[key]);
  return {key:a.key,baseBindings:sum(a.groups.map(g=>({count:g.bindings.length})),'count'),candidateBindings:sum(b.groups.map(g=>({count:g.bindings.length})),'count'),baseUpdateNodes:a.updateNodes.length,candidateUpdateNodes:b.updateNodes.length,
    vertexIdentical:a.vertexShader===b.vertexShader,fragmentIdentical:a.fragmentShader===b.fragmentShader,
    vertexSha256:[hash(a.vertexShader),hash(b.vertexShader)],fragmentSha256:[hash(a.fragmentShader),hash(b.fragmentShader)]};
});
const acceptance=[];
for(const res of [360,720,1080]){
  const runs=[];
  for(let pair=1;pair<=3;pair++)for(const variant of ['base','shadow-color']){
    const id=`natural-${res}-${variant}-${pair}`,a=read(id);
    assert.equal(a.failure,null);assert.equal(a.summary.nodeBuilders,0);assert.equal(a.samples.length,1800);assert.equal(a.submissionDiagnostic,false);assert.equal(a.refreshDiagnostic,false);
    runs.push({id,pair,variant,render:a.summary.cpuRenderSubmitMs.p50,callback:a.summary.callbackIntervalMs.p50,game:a.summary.cpuGameMs.p50,draws:median(a.samples.map(f=>f.draws)),aiShots:a.combat.aiShots,playerShots:a.combat.playerShots,impacts:a.combat.impacts,distance:a.combat.distance,renderP99:a.summary.cpuRenderSubmitMs.p99,renderMax:a.summary.cpuRenderSubmitMs.max});
  }
  const metrics={};for(const key of ['render','callback','game'])metrics[key]=['base','shadow-color'].map(v=>median(runs.filter(r=>r.variant===v).map(r=>r[key])));
  acceptance.push({res,metrics,runs});
}
const images=['base-validation','shadow-color-validation'].map(id=>PNG.sync.read(readFileSync(resolve(root,id+'.png'))));
assert.equal(images[0].width,images[1].width);assert.equal(images[0].height,images[1].height);
let changed=0,max=0;for(let i=0;i<images[0].data.length;i+=4){let delta=0;for(let j=0;j<3;j++)delta=Math.max(delta,Math.abs(images[0].data[i+j]-images[1].data[i+j]));if(delta)changed++;max=Math.max(max,delta)}
const manifests=readdirSync(root).filter(n=>n.endsWith('.manifest.json')).map(n=>JSON.parse(readFileSync(resolve(root,n))));
assert.equal(manifests.length,27);assert(manifests.every(m=>m.completed));
const gpu=['base','shadow-color'].map(v=>{const a=read('gpu-'+v);return{variant:v,samples:a.summary.gpuSampleCount,passSum:a.summary.gpuPassTimeMs}});
const result={successfulProfileRuns:manifests.length,measuredFrames:manifests.length*1800,baseline:censusSummary(baseline),candidate:censusSummary(candidate),specimens,acceptance,gpu,hero:{changedPixels:changed,maxDelta:max},runOrder:manifests.sort((a,b)=>a.started.localeCompare(b.started)).map(m=>({id:m.id,started:m.started,completed:m.completed,buildHtmlSha256:m.buildHtmlSha256}))};
writeFileSync(resolve(root,'summary.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({...result,acceptance:acceptance.map(({res,metrics})=>({res,metrics})),runOrder:undefined},null,2));
