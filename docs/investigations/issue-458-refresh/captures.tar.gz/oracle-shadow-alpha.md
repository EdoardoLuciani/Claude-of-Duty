# Oracle: source-color alpha dependency in opaque world shadows

## Updated recommendation after parent steering: prefer the app-only wrapper first

**Yes: the compile-time, zero-input TSL wrapper is the smaller first control. Prefer it to modifying `Renderer._getShadowNodes`.** At this checkout the function is named `createSurfaceNodeMaterial` in `src/materials/shader-tsl.ts` (not `createBuiltinSurfaceMaterial`). Replace only its color-node assignment in the disposable trial, with a JS build-time branch that returns `vec3(0)` for the narrowly eligible, non-alpha-mask surface in a shadow-material builder, and otherwise returns the original `channels.get('color')`.

Why this should work at this pin:

- `TSLCore.js:477–607` invokes a no-layout `Fn` body with the current builder. A two-argument callback receives `(inputs, builder)` even with zero inputs (`jsFunc.length > 1`). An explicit `'vec3'` return type is reasonable, not a function layout.
- `ShaderCallNodeInternal.getOutputNode` (`TSLCore.js:630–637`) caches the chosen stack through **builder.getNodeProperties(this)**. `NodeBuilder.js:516–526,2130–2184` starts with builder-local caches. Returning a node from a JS branch does not build the unchosen branch. Merely constructing the existing `channels = Fn(...)()` object is lazy.
- `NodeManager._createNodeBuilder:173–175` sets `builder.material` to the actual rendering material. For a shadow build this is the override shadow material, not the source surface; `builder.material.isShadowPassMaterial` is therefore the correct discriminator. Do not substitute `builder.context.material` or source-material flags.
- Beauty/prepass and shadow use different render material/context/build states; a shared node object does not imply one globally cached branch result. Nevertheless validate both build orders (shadow first and beauty first) and actual-graph prewarm, because final NodeBuilderState reuse is a separate cache from per-builder Fn expansion. Do not reuse a global named layout function, capture a builder in a closure, or mutate pass eligibility after compilation.

**Implementation restrictions:** keep `channels` in the closure, not a raw Fn argument; layout inputs can be eagerly built (`TSLCore.js:502–549`). Use a **JavaScript conditional**, not TSL `If`/`select`, which can register both branches. No `.once()` or layout is necessary. Apply the conservative eligibility exclusions below at material construction, capturing a stable diagnostic eligibility boolean; `!p.alphaMask` alone is not enough if `threeProps` supplies custom behaviors. If the test deliberately covers only the known ordinary world-material set, assert that set's eligibility rather than silently widening scope. A changing runtime eligibility flag would require a material-version rebuild, so keep this experiment fixed from initial creation.

This preserves the source material object and original full graph in beauty/prepass; only shadow specialization changes. It still changes the source color-node graph identity as a prototype, which is expected to rebuild shaders from boot, not alias native per-object buffers.

**Critical consequence:** the wrapper does **not** make `_getShadowNodes` return null. Three still creates a derived shadow color node containing `.a` of the wrapper. The graph now builds cheaply to constant alpha one, but it is **not the factory default literal identity**. Therefore the existing exact-default-shadow observer control will still miss it. Do not expect FULL→SHARED from this app-only control, and do not relax the observer identity guard merely to force that result. First measure the loss of bindings/update nodes with refresh policy unchanged. If a second refresh-policy experiment is worthwhile, it needs a separately justified exact-graph tag/control; the Renderer-pruning alternative below would naturally expose the factory default, but is no longer the first recommendation.

## Source verdict (unchanged)

**The new interpretation is source-supported and is a substantially better causal lead than the original “default constant shadow color forces FULL” explanation.** The unchanged controls mean that the tagged default literal was not the operative color graph for the dominant source-color cohort; they do not disprove excessive shadow dependencies.

Proceed with **one app-scoped offline dependency-removal control first**, keeping refresh policy unchanged. The app-only wrapper above supersedes the Renderer patch below as the preferred first control. Keep any later refresh-policy change as a separate condition so dependency pruning and refresh bypass are not conflated.

## Source chain checked

1. `Renderer._getShadowNodes`, `node_modules/three/src/renderers/common/Renderer.js:3757–3801`, checks `hasColorNode` independently of transparency/alpha testing. With no custom cast node it starts from RGB zero / alpha one, then multiplies alpha by `material.colorNode.a`. It constructs a derived `vec4`, replacing the default shadow literal during the draw. The function also independently preserves map alpha, masks, depth, and position nodes and caches the result by **material identity + version**.
2. `src/materials/shader-tsl.ts:47–54` declares `MaterialChannels.color` as **vec3**, separate from float `opacity`. At `:631–638`, the complete function returns color/opacity/normal/rough/metal/AO, assigns `channels.get('color')` to `mat.colorNode`, and assigns opacity separately only for `p.alphaMask`.
3. `MemberNode.generate`, `node_modules/three/src/nodes/utils/MemberNode.js:118–135`, builds the underlying struct before selecting its member. This is not a lazy extraction that builds only the selected RGB expression.
4. `SplitNode.generate`, `node_modules/three/src/nodes/utils/SplitNode.js:120–151`, expands a vec3 input to vec4 before accessing `.w`/`.a`, and **calls the source node's build**. `NodeBuilder.format`, `src/nodes/core/NodeBuilder.js:3789–3795`, fills the fourth component with **one**.

Therefore, for this known RGB-only output, the extracted alpha is semantically one, yet obtaining it builds the large source material graph. That can retain bindings and CPU update nodes even if a later native shader optimizer eliminates useless GPU arithmetic. **Do not claim all RGB/normal/ORM calculations execute on the GPU** from these source facts alone; inspect emitted WGSL and binding/update metadata separately. The reported 16/17 entries are consistent with the hypothesis but do not by themselves identify every entry's origin.

Also correct the scope of “always”: `hasColorNode` is true for this generated material cohort, not every source material in Three. An opaque flag alone would not justify removing an arbitrary graph.

## Alternative control, if exact factory-default exposure is subsequently needed

The following Renderer-local variant is still causally useful, but is more invasive than the app-only wrapper and should not be implemented first or silently combined with it.

### A — prune only the known redundant source-alpha dependency

In a source-hash-guarded offline transform:

- At the generator, tag the **exact returned RGB member-node identity** for this known implementation when `!p.alphaMask`. Prefer an ephemeral WeakSet/WeakMap, not a persistent `userData` claim or a material-name match. For maximum conservatism, register the material→original-color-node pair as well; replacements then automatically fall out of eligibility.
- In **only** `Renderer._getShadowNodes`, make its local `hasColorNode` false for that registered, still-identical, eligible source node/material. Keep the original predicate for everything else. Do not change `material.colorNode`, beauty/prepass shaders, or globally change `SplitNode`/vec3 `.a` semantics.
- Require current material eligibility at cache construction, not just at generator creation. For this first control, conservatively exclude maps/alpha maps, `alphaMask`, transparency/transmission, opacity other than one, opacity/alpha-test nodes, nonzero alphaTest, alphaHash/alphaToCoverage, castShadowNode, maskShadowNode/maskNode, custom depth/position/cast-shadow-position nodes, and custom fragment/output overrides. Excluding rather than optimizing these cases is entirely acceptable for a diagnostic.
- Preserve every other `_getShadowNodes` branch. Do **not** short-circuit the whole function or return an empty cache object. In the simplest eligible case, its color result becomes null, so normal override handling retains the genuine factory default literal; depth/position handling still executes normally.

Using `!p.alphaMask` alone is insufficient because `threeProps` can install additional material behavior (`shader-tsl.ts:224–226`). Also confirm the generator's supplied control nodes are the ordinary application uniforms/known helpers, not arbitrary side-effectful user graphs. The inspected function contains local assignments and loop breaks, and no explicit discard/storage/atomic effects; that is evidence for this pinned generator, not a universal property of `Fn`.

**Expected result for A:** eligible shadow binding layouts/update-node lists become much smaller; material:colorNode may still cause FULL because the factory default literal remains a node. A collapse in dependencies with FULL unchanged is a successful causal result, not a failed test. Record eligible material/visit counts and compare the same cohort, not only global totals.

### B — A plus existing exact-default-shadow policy

Only after A's dependency prediction holds, apply the already bounded observer policy: ignore the **exact factory literal identity**, and optionally the unused AO context only in that exact unlit default-shadow case. Keep animation, dynamic instancing, first initialization, velocity, target switching, equality, and resource invalidation checks unchanged.

**Expected result for B:** eligible unchanged static shadows move toward SHARED/NONE; moving/skinned/otherwise dynamic cases retain their normal checks. If another material/context property becomes the first cause, report that witness rather than broadening the bypass until it becomes fast.

## Guards and validation risks

- **Fresh build/prewarm per condition.** The shadow-node cache is material-version keyed. Enabling a tag or changing eligibility after cache population will not automatically rebuild it. Do not mutate a live warmed cache to manufacture the result.
- **No general upstream rule yet.** A vec3-producing `Fn` may execute discard, mutate shader properties/storage, or perform custom build-time callbacks. Removing its build can remove required effects despite its alpha value being one. `NodeMaterial.setupDiffuseColor:819–905` also handles mask/discard/alpha behavior before forcing opaque alpha to one. Neither “opaque” nor “output vec3” proves purity.
- **Prove what vanished.** For a few representative eligible shadow builders, report texture/buffer names, binding count, update-node types, and WGSL before/after. The source Fn should disappear from shadow dependencies while beauty/prepass retain it.
- **Negative guards:** source-node replacement, a masked generated material, RGBA custom color, map alpha, custom cast/mask, and untagged materials must retain the original route. Check the transform does not remove their `hasColorNode` dependency.
- **Correctness:** unchanged object/material identities and native-buffer isolation; exact draw/pass counts; native depth/shadow readbacks or shadowed-scene image comparisons; moving camera/light/cascade coverage. For B also test moving/scaled eligible objects and relevant content/version/disposal changes, plus the existing startup/prewarm/render suites. A single hero screenshot cannot establish shadow/cascade or invalidation correctness.
- **Claims:** this is an app-scoped causal test of redundant shadow graph construction. Count-only captures establish dependency/refresh changes, not throughput gains. Any performance claim needs separate fresh uninstrumented matched controls afterward. Do not weaken the original identity or visual contracts for the control.

No further authority question is needed. Parent retains implementation and acceptance decisions; no project/source files were changed by this consultation.
