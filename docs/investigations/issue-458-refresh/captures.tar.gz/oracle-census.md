# Census attachment points — focused oracle follow-up

## Recommendation

**Prefer one exact-source-guarded offline instrumentation module, with hooks in `NodeMaterialObserver.js`, over trying to infer causes by wrapping its public calls afterward.** Keep the browser collector in the same diagnostic module/runner. Do not add a runtime framework or a permanent renderer hook.

There is **no `builder.createNodeMaterialObserver` factory at this pin**. The actual factory is `NodeMaterial.setupObserver(builder)` (`src/materials/nodes/NodeMaterial.js:459–461`), called at the end of material setup (`:606`). `onNodeBuilderCreated` is earlier even than assignment of builder.scene/material/camera (`NodeManager.js:166–178`), so it cannot supply the final observer/context snapshot.

Wrapping `setupObserver` and calling the original once would capture a completed observer while temporary shadow override state is still active. However, enumerating the builder again only gives a second, observational scan of possible causes; it does not identify the precise original short-circuit witness and can repeat property getters. It is not the best seam for this first-match census. Instrument the **original evaluations** instead.

## 1. Creation-time causes: instrument `containsNode`, not a delayed snapshot

`NodeMaterialObserver.js:347–377` contains four positive exits and a negative exit:

1. First truthy material node property, in existing enumeration order.
2. First truthy context term in the existing OR expression: `modelViewMatrix`, `modelNormalViewMatrix`, `getAO`, `getShadow`, `getGI`.
3. Fog-node condition.
4. Scene environment-node condition.
5. No node trigger.

At each existing return, emit an optional diagnostic event with **observer reference, primitive reason code, and property name where applicable**. The collector can assign observer IDs with a WeakMap. For the context OR, preserve the expression order and short circuit: decorate each existing term with a truthy numeric reason assignment, not a second scan or extra getter invocation. The event can run immediately before the existing return; it must not supply the return value.

`containsNode` runs inside the constructor before `hasNode` and `hasAnimation` assignments finish. Emit a separate initialization-complete event just after constructor initialization (`:166`, after `this.renderId = 0`) containing observer/builder references and finalized flags. At that moment snapshot primitive builder object/material/scene IDs and the diagnostic property name; do **not** retain the mutable builder/material as later evidence of what was compiled. The collector may use transient references only to key WeakMaps.

This captures the compiled observer's actual first-match cause before the temporary override material is restored. A shared observer belongs to a NodeBuilderState and can serve several RenderObjects: **do not equate its original builder.object with every later object using it**. Join observer ID to each actual refresh event.

Report `nodeCause=material:colorNode` rather than “constant colorNode” unless constantness is separately proven. A shader node property alone does not prove that its graph is dynamic or constant.

## 2. Actual refresh decisions: decorate existing expressions/returns

Instrument `needsRefresh` (`:1027–1078`) itself. Never call it twice, and never rerun `firstInitialization`, `equals`, or `getRenderObjectData` to explain its result.

For the first OR-chain, add one local primitive `firstReason` and decorate each **original** operand in order:

- `hasNode`
- `hasAnimation`
- `hasDynamicInstancing(object)`
- `firstInitialization(renderObject)`
- `needsVelocity(renderer)`

Conceptually, each original predicate is `predicate && (firstReason = NONZERO_CODE)` within the same OR chain. The `if` still tests truthiness; each function remains evaluated exactly once, and only if earlier terms were false. Retain the same return value and branching order. Then emit one FULL event before that existing early return.

**Important:** when `hasNode` is true, initialization and velocity checks were not evaluated. Record **not evaluated**, not false, and do not claim velocity was independently the cause. This is a *first-match policy witness*, not an exhaustive causal census. On some observers, the early node branch means their per-RenderObject initialization map remains absent indefinitely; do not classify those as repeated first-initialization failures.

For the fallback path, maintain a primitive bitmask only in existing entered blocks:

- `newRenderEpoch` when `this.renderId !== renderId` sets SHARED.
- `outputTargetChanged` when its existing comparison sets FULL.
- `equalsFalse` inside the original `equals(...) === false` block.

At the existing static/bundle early return, emit the actual `refreshType`, accumulated flags, and exit category. At the final return, emit actual type/flags and normal-fallback exit category. Preserve both flags if a target change and `equalsFalse` occur; they are not mutually exclusive. Do not instrument individual `equals` internals yet: `equalsFalse` is a sufficient bounded first capture.

Exactly **one decision event per invocation**. Initialization events may be many; measured decisions should count only measured frames.

## 3. Pass identity: minimal combination, not `RenderContext.id` alone

For measured calls, wrap the existing renderer **`_renderScene`**, not just public `render`: QuadMesh paths also call `_renderScene` directly. Install this wrapper once after game boot and before warmup/measurement; call the original once with preserved `this`, arguments, result, and errors, and pop the diagnostic stack in `finally`.

The wrapper assigns a diagnostic invocation ID and parent invocation ID; it does not need timings. At refresh events capture actual:

- frame/sample index;
- invocation ID / parent invocation ID / nesting depth;
- `nodeFrame.renderId`;
- `renderObject.context.id`;
- `renderObject.camera.id`, `renderObject.scene.id`, `renderObject.lightsNode.id` if available;
- current target identity (WeakMap ID; null is screen), cube-face/array-layer and mip where relevant;
- actual render material ID and `renderer._currentSourceMaterial?.id`;
- current override-material ID and shadow-material flag;
- RenderObject ID, Object3D ID, observer ID, object category;
- actual refresh type, firstReason or fallback flags.

Do not use scene.name as identity: native shadow rendering temporarily changes it. Capture a label only for human interpretation. Do not use `context.stateKey` as unique identity: it deliberately merges attachment configurations across call depths (`RenderContext.js:29–39`). `RenderContext.id` alone also does not distinguish sequential camera/cascade uses. The invocation stack plus camera/target/context resolves that ambiguity. Use actual refresh-time context: `_renderScene` chooses framebuffer/target and assigns `_currentRenderContext` after entry (`Renderer.js:1894–1985`), so a wrapper's entry context is still the parent context.

**`passId` is not stored on RenderObject.** Smallest exact addition: instrument `RenderObjects.createRenderObject` immediately after `new RenderObject(...)` (`RenderObjects.js:228`) with an optional event carrying RenderObject and the existing `passId` argument. The collector stores it in a WeakMap, including explicit null versus undefined if desired. This avoids wrapping every lookup and captures prewarm-created objects. It is a second source file but still one small transform module. Do not infer passId from material.side after return; transparent double-side handling restores it.

Keep counts of decisions separate from backend.draw counts: a refresh decision does not guarantee a draw when a pipeline is not ready. The normal no-late-build fixture should reconcile them, but fail/report a mismatch rather than silently treating them as identical.

## 4. Boot, guards, and collector lifetime

- **Install collector with `page.addInitScript` before page navigation/game boot.** Otherwise the measured run will use prewarm-created observers with missing compiled causes and passId metadata.
- Retain creation metadata through boot/prewarm; begin per-frame aggregation only when the existing profiler enters measured frames. Clear/warmup counters, not WeakMap metadata. Hook `_renderScene` before measured rendering; a prewarm pass stack is unnecessary for this one measurement.
- The collector callback must be non-throwing. Catch diagnostic failures inside it, record a failure flag, and fail the report afterward rather than perturbing the original renderer's exception/control-flow semantics. Missing metadata must be explicit `unknown` and counted; never silently infer it from mutable current material state.
- Hash-check pristine files and enforce **one occurrence per replacement** before writing; restore sources, Vite cache, and production build using the existing trial runner's finally discipline.
- `tools/lib/source-mutation.mjs` is usable only with these extra guards: its `mutateSource` merely asserts at least one match and can replace multiple matches. Its page-route helper is a development response mutation and will not instrument Three code already bundled in a production build. Prefer the existing trial's build-time exact replacement pattern, then build once with diagnostics.
- No event objects or JSON serialization per binding are needed. Primitive codes plus transient object references into WeakMaps and aggregated counters suffice. Keep this diagnostic count-only; do not compare its throughput to uninstrumented runs.

## Minimal validation before the one capture

A small mocked observer test should prove: earlier truthy OR terms suppress later calls; firstInitialization and equals run once at most; every original return type is unchanged; exactly one decision event is emitted; static/bundle exits retain target/epoch flags; throwing renderer code still pops the pass wrapper stack. Verify transformed source hashes, positive known cause fixtures, and measured unknown-metadata counts.

No optimization handoff or authority question remains. Proceed with this bounded census only.
